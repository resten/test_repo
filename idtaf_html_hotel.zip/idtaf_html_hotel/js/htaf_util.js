function h_string(value1) {
    this.value_ = value1;

    this.get_value = function() {
        return this.value_;
    };

    this.to_h_string = function() {
        return this.value_;
    };
}

var make_htaf_log_element = function(idx, names, object, log_message) {
    var value = "", type = "", ele = "";
    ele = names[idx];
    try {
        value = object[ele];
        type = typeof value;
    } catch (e) {
        value = "<unknown value>";
        type = "unknown";
    }
    if (type === "function") {
        value = "{/*function*/}";
    } else if (type === "object") {
        value = make_htaf_log("", value);
    } else if (type === "string") {
        value = "\"" + value + "\"";
    }
    log_message += "\"" + ele + "\"" + " : " + value;
    if (idx < names.length - 1) {
        log_message += ", ";
    }
    return log_message;
}

var make_htaf_log = function(message, object) {
    var i = 0, name = "", names = [], log_message = "", value = "", type = "";
    for(name in object) {
        if (object.hasOwnProperty(name)) {
            names.push(name);
        }
    }
    names.sort();

    for (i = 0; i < names.length; i += 1) {
        log_message = make_htaf_log_element(i, names, object, log_message);
    }
    return message + " {" + log_message + "}";
};

var htaf_log = function(message) {
    update_result_field(message, true);
    console.log("\n[HTAF_LOG][" + new Date() + "] " + message + "\n");
}

function utils() {
    var hcap_const_value_map = new Array();
    var hcap_const_value_map_initialized = false;

    this.evaluate = function(value) {
        value = this.trims(value);
        if (value instanceof h_string) {
            return value.get_value();
        } else if (this.is_config_variable(value)) {
            var key = value;
            var predefined_value = variable_parser.get_global_config_value(key);
            return predefined_value;
        } else if (this.is_hdstl_string_value(value)) {
            return parse_hdstl_string_value(value);
        } else if (this.is_hcap_const_value(value)) {
            return parse_hcap_const_value(value);
        } else if (this.is_hex_number(value)) {
            return parse_hex_number(value);
        } else if (this.is_hdstl_boolean_value(value)) {
            return parse_hdstl_boolean_value(value);
        } else if (this.is_number_value(value)) {
            return parse_number_value(value);
        } else if (value === prefix.DONT_CARE) {
            return "?";
        } else {
            return value;
        }
        return undefined;
    };

    this.is_hcap_const_value = function(value) {
        if (this.starts_with(value, "hcap.")) {
            return true;
        } else {
            return false;
        }
    };

    function parse_hcap_const_value(value) {
        var const_value = eval(value);
        if (const_value === undefined) {
            console.log("\n[HCAP_LOG][ util ] " +  "invalid hcap const string : " + value + "\n");
        }
        return Number(const_value);
    };

    // -----------------------------------------------------------------------
    // hex number
    // -----------------------------------------------------------------------
    this.is_hex_number = function(value) {
        if (this.starts_with(
                value, "0x") ||
                this.starts_with(
                        value, "0X")) {
            return true;
        } else {
            return false;
        }
    };

    function parse_hex_number(value) {
        var hex_string = value;
        var hex_num;
        if (util.is_hex_number(value)) {
            hex_string = hex_string.substring(
                    2, hex_string.length);
            return parseInt(
                    hex_string, 16);
        } else {
            console.log("\n[HCAP_LOG][ util ] " + "not a hex string : " +
                    value + "\n");
            return undefined;
        }
    }
    ;

    // -----------------------------------------------------------------------
    // hdstl config variable
    // -----------------------------------------------------------------------
    this.is_config_variable = function(value) {
        if (this.starts_with(value, prefix.PREFIX_DEFINE)) {
            return true;
        } else {
            return false;
        }
    };

    // -----------------------------------------------------------------------
    // hdstl string value
    // -----------------------------------------------------------------------
    this.is_hdstl_string_value = function(value) {
        if (this.starts_with(value, "[") && ends_with(value, "]")) {
            return true;
        } else {
            return false;
        }
    };

    function parse_hdstl_string_value(value) {
        return trims_bracket(value);
    }

    // ----------------------------------------------------------------------
    // hdstl string value
    // ----------------------------------------------------------------------
    this.is_hdstl_boolean_value = function(value) {
        if (value === "TRUE" || value === "true" || value === "FALSE" || value === "false") {
            return true;
        } else {
            return false;
        }
    }

    function parse_hdstl_boolean_value(value) {
        if (value === "TRUE" || value === "true") {
            return true;
        } else if (value === "FALSE" || value === "false") {
            return false;
        } else {
            console.log("\n[HCAP_LOG][ util ] " + "not a boolean value : " + value + "\n");
            return undefined;
        }
    }

    // ----------------------------------------------------------------------
    // hdstl string value
    // -----------------------------------------------------------------------
    this.is_number_value = function(value) {
        return !isNaN(value);
    }

    function parse_number_value(value) {
        return Number(parseInt(value));
    }

    this.starts_with = function(in_str, str) {
        return !in_str.indexOf(str);
    };
    /*
     * function ends_with(in_str, str):Boolean {
     * return in_str.lastIndexOf(str) ==
     * in_str.length - str.length; }
     */
    this.trims = function(in_str) {
        var trim_value = in_str;
        if (trim_value === "") {
            return trim_value;
        }
        while (String(trim_value).charAt(0) === " " ||
                  String(trim_value).charAt(0) === "\n" ||
                  String(trim_value).charAt(0) === "\t" ||
                  String(trim_value).charAt(0) === "\r") {
            trim_value = trim_value.substring(
                    1, trim_value.length);
        }
        while (String(trim_value).charAt(trim_value.length - 1) === " " ||
                  String(trim_value).charAt(trim_value.length - 1) === "\n" ||
                  String(trim_value).charAt(trim_value.length - 1) === "\t" ||
                  String(trim_value).charAt(trim_value.length - 1) === "\r") {
            trim_value = trim_value.substring(
                    0, trim_value.length - 1);
        }
        return trim_value;
    };

    this.is_equal = function(expected, actual, message) {
        var result_obj = new GenericResult();
        if (expected === prefix.DONT_CARE ||
                actual === prefix.DONT_CARE || expected === undefined) {
            result_obj.result = true;
            return result_obj;
        }
        if (actual instanceof String) {
            result_obj.result = (String(expected) === String(actual));
        } else if (actual instanceof Number) {
            result_obj.result = (parseInt(expected) === parseInt(actual));
        } else {
            result_obj.result = (actual === expected);
        }
        if (!result_obj.result) {
            result_obj.fail_reason = message +
                " : expected = " + expected +
                ", but actual = " + actual;
        }

        if (result_obj.result) {
            console.log("\n[HCAP_LOG][ util ] " + message +
                    " was successful. : expected = " + expected +
                    ", and actual = " + actual + "\n");
        } else {
            console.log("\n[HCAP_LOG][ util ] " + "is_equal : " + message +
                    " has failed. : expected  = " + expected +
                    ", but actual = " + actual + "\n");
        }
        return result_obj;
    }

    this.is_equal_list_with_sort = function(expected, actual, message) {
        var result_obj = new GenericResult();
        if (expected === prefix.DONT_CARE ||
                actual === prefix.DONT_CARE) {
            result_obj.result = true;
            return result_obj;
        }

        var expected_list = expected.split(",").sort();
        var actual_list = actual.split(",").sort();
        result_obj.result = (expected_list.toString() === actual_list.toString());

        if (!result_obj.result) {
             result_obj.fail_reason = message +
                 " : expected = " + expected_list +
                 ", but actual = " + actual_list;
        }

        if (result_obj.result) {
            console.log("\n[HCAP_LOG][ util ] " + message +
                    " was successful. : expected = " + expected +
                    ", and actual = " + actual + "\n");
        } else {
            console.log("\n[HCAP_LOG][ util ] " + "is_equal : " + message +
                    " has failed. : expected  = " + expected +
                    ", but actual = " + actual + "\n");
        }
        return result_obj;
    }

    this.parse_csv_column = function(line) {
        var list = new Array();

        var begin = 0;
        var quote_start = false;
        for ( var i = 0; i < line.length; i++) {
            if (line.charAt(i) === "\"" &&
                    line.charAt(i + 1) === "\"" &&
                    line.charAt(i + 2) === "\"" &&
                    line.charAt(i + 3) === "\"" &&
                    line.charAt(i + 4) === "\"" &&
                    line.charAt(i + 5) === "\"") {
                //console.log("empty string!!");
                list[list.length] = new h_string("");
                begin = i + 7;
                i = i + 6;
                continue;
            }
            var character_0 = line.charAt(i);
            var character_1 = line.charAt(i + 1);
            var character_2 = line.charAt(i + 2);

            if (character_0 === "\"" &&
                    character_1 === "\"" && character_2 === "\"") {
                if (quote_start === false) {
                    quote_start = true;
                    i = i + 3;
                    begin = i;
                    continue;
                } else {
                    var cell_data = this.trims(line.substring(
                            begin, i));
                    if (cell_data.length != 0) {
                        list[list.length] = new h_string(
                                cell_data);
                    }
                    quote_start = false;
                    begin = i + 4;
                    i = i + 3;
                    continue;
                }
            } else if (character_0 === prefix.CELL_DELIMITER &&
                    quote_start === false) {
                var cell_data = this.trims(line.substring(
                        begin, i));
                if (this.starts_with(
                        cell_data, "//")) {
                    return list;
                }
                if (cell_data.length != 0) {
                    list[list.length] = cell_data;
                }
                begin = i + 1;
            }
        }
        var cell_data = this.trims(line.substring(begin));
        if (this.starts_with(
                cell_data, "//")) {
            return list;
        }
        if (cell_data.length != 0) {
            list[list.length] = cell_data;
        }
        return list;
    };

    this.get_channel_with_dontcare_from_array = function(channel_input) {

        var channel = new Object();
        if (channel_input === prefix.DONT_CARE ){
            return prefix.DONT_CARE;
        }
        channel.channelType = channel_input[0];

        if (channel.channelType === hcap.channel.ChannelType.RF) {
            // RF channel
            channel.logicalNumber = channel_input[1];
            channel.frequency = channel_input[2];
            channel.programNumber = channel_input[3];
            channel.majorNumber = channel_input[4];
            channel.minorNumber = channel_input[5];
            channel.rfBroadcastType = channel_input[6];
            channel.pcrPid = channel_input[7];
            channel.videoPid = channel_input[8];
            channel.videoStreamType = channel_input[9];
            channel.audioPid = channel_input[10];
            channel.audioStreamType = channel_input[11];
            channel.signalStrength = channel_input[12];
            channel.sessionId = String(channel_input[13]);
            channel.satelliteId = channel_input[14];
            channel.polarization = channel_input[15];
            channel.symbolRate = channel_input[16];
            channel.plpId = channel_input[17];
            channel.pmtPid = channel_input[18];
            channel.proidiomPid = channel_input[19];
        } else {
            // IP channel
            channel.logicalNumber = channel_input[1];
            channel.ip = channel_input[3];
            channel.port = channel_input[4];
            channel.ipBroadcastType = channel_input[5];
            channel.programNumber = channel_input[6];
            channel.pcrPid = channel_input[7];
            channel.videoPid = channel_input[8];
            channel.videoStreamType = channel_input[9];
            channel.audioPid = channel_input[10];
            channel.audioStreamType = channel_input[11];
            channel.signalStrength = channel_input[12];
            channel.sessionId = String(channel_input[13]);
            channel.sourceAddress = channel_input[14];
            channel.pmtPid = channel_input[15];
            channel.proidiomPid = channel_input[16];
        }
        return channel;
    }

    this.get_data_channel_with_dontcare_from_array = function(channel_input) {
        var channel = new Object();
        if (channel_input === prefix.DONT_CARE ){
            return prefix.DONT_CARE;
        }
        channel.channelType = channel_input[0];
        if (channel.channelType === hcap.channel.ChannelType.RF_DATA) {
            // RF channel
            channel.frequency = channel_input[2];
            channel.programNumber = channel_input[3];
            channel.majorNumber = channel_input[4];
            channel.minorNumber = channel_input[5];
            channel.rfBroadcastType = channel_input[6];
            channel.signalStrength = channel_input[12];

        } else if(channel.channelType === hcap.channel.ChannelType.IP_DATA){
            // IP channel
            channel.ip = channel_input[3];
            channel.port = channel_input[4];
        } else {
            return false;
        }
        return channel;
    }

    this.is_equal_channel =
        function(expected_channel, channel, message) {

        var result_obj = new GenericResult();
        result_obj.result = true;
        if (expected_channel === prefix.DONT_CARE ) {
            return result_obj;
        }
        if (hcap.channel.ChannelType.RF === expected_channel.channelType) {
            result_obj.add(this.is_equal(expected_channel.channelType, channel.channelType, "RF channel : channel type"));
            result_obj.add(this.is_equal(expected_channel.logicalNumber, channel.logicalNumber, "RF channel : logicalNumber"));
            result_obj.add(this.is_equal(expected_channel.frequency, channel.frequency, "RF channel : frequency"));
            result_obj.add(this.is_equal(expected_channel.programNumber, channel.programNumber, "RF channel : programNumber"));
            result_obj.add(this.is_equal(expected_channel.majorNumber, channel.majorNumber, "RF channel : majorNumber"));
            result_obj.add(this.is_equal(expected_channel.minorNumber, channel.minorNumber, "RF channel : minorNumber"));
            result_obj.add(this.is_equal(expected_channel.rfBroadcastType, channel.rfBroadcastType, "RF channel : rfBroadcastType"));
            result_obj.add(this.is_equal(expected_channel.pcrPid, channel.pcrPid, "RF channel : pcrPid"));
            result_obj.add(this.is_equal(expected_channel.videoPid, channel.videoPid, "RF channel : videoPid"));
            result_obj.add(this.is_equal(expected_channel.videoStreamType, channel.videoStreamType, "RF channel : videoStreamType"));
            result_obj.add(this.is_equal(expected_channel.audioPid, channel.audioPid, "RF channel : audioPid"));
            result_obj.add(this.is_equal(expected_channel.audioStreamType, channel.audioStreamType, "RF channel : audioStreamType"));
            result_obj.add(this.is_equal(expected_channel.signalStrength, channel.signalStrength, "RF channel : signalStrength"));
            result_obj.add(this.is_equal(expected_channel.sessionId, channel.sessionId, "RF channel : sessionId"));
            result_obj.add(this.is_equal(expected_channel.satelliteId, channel.satelliteId, "RF channel : satelliteId"));
            result_obj.add(this.is_equal(expected_channel.polarization, channel.polarization, "RF channel : polarization"));
            result_obj.add(this.is_equal(expected_channel.symbolRate, channel.symbolRate, "RF channel : symbolRate"));
            result_obj.add(this.is_equal(expected_channel.plpId, channel.plpId, "RF channel : plpId"));
            result_obj.add(this.is_equal(expected_channel.pmtPid, channel.pmtPid, "RF channel : pmtPid"));
            result_obj.add(this.is_equal(expected_channel.proidiomPid, channel.proidiomPid, "RF channel : proidiomPid"));
        } else {
            result_obj.add(this.is_equal(expected_channel.channelType, channel.channelType, "IP channel : channel type"));
            result_obj.add(this.is_equal(expected_channel.logicalNumber, channel.logicalNumber, "IP channel : logicalNumber"));
            result_obj.add(this.is_equal(expected_channel.ip, channel.ip, "IP channel : ip"));
            result_obj.add(this.is_equal(expected_channel.port, channel.port, "IP channel : port"));
            result_obj.add(this.is_equal(expected_channel.ipBroadcastType, channel.ipBroadcastType, "IP channel : ipBroadcastType"));
            result_obj.add(this.is_equal(expected_channel.programNumber, channel.programNumber, "IP channel : programNumber"));
            result_obj.add(this.is_equal(expected_channel.pcrPid, channel.pcrPid, "IP channel : pcrPid"));
            result_obj.add(this.is_equal(expected_channel.videoPid, channel.videoPid, "IP channel : videoPid"));
            result_obj.add(this.is_equal(expected_channel.videoStreamType, channel.videoStreamType, "IP channel : videoStreamType"));
            result_obj.add(this.is_equal(expected_channel.audioPid, channel.audioPid, "IP channel : audioPid"));
            result_obj.add(this.is_equal(expected_channel.signalStrength, channel.signalStrength, "IP channel : signalStrength"));
            result_obj.add(this.is_equal(expected_channel.sessionId, channel.sessionId, "IP channel : sessionId"));
            result_obj.add(this.is_equal(expected_channel.sourceAddress, channel.sourceAddress, "IP channel : sourceAddress"));
            result_obj.add(this.is_equal(expected_channel.pmtPid, channel.pmtPid, "IP channel : pmtPid"));
            result_obj.add(this.is_equal(expected_channel.proidiomPid, channel.proidiomPid, "IP channel : proidiomPid"));
        }

        return result_obj;
    };

    this.is_equal_data_channel =
        function(expected_channel, channel, message) {
        var result_obj = new GenericResult();
        // result.result = false;
        if (hcap.channel.ChannelType.RF_DATA === expected_channel.channelType) {
            result_obj.add(this.is_equal(expected_channel.channelType, channel.channelType, "RF channel : channel type"));
            result_obj.add(this.is_equal(expected_channel.logicalNumber, channel.logicalNumber, "RF channel : logicalNumber"));
            result_obj.add(this.is_equal(expected_channel.frequency, channel.frequency, "RF channel : frequency"));
            result_obj.add(this.is_equal(expected_channel.programNumber, channel.programNumber, "RF channel : programNumber"));
            result_obj.add(this.is_equal(expected_channel.majorNumber, channel.majorNumber, "RF channel : majorNumber"));
            result_obj.add(this.is_equal(expected_channel.minorNumber, channel.minorNumber, "RF channel : minorNumber"));
            result_obj.add(this.is_equal(expected_channel.rfBroadcastType, channel.rfBroadcastType, "RF channel : rfBroadcastType"));
        } else {
            result_obj.add(this.is_equal(expected_channel.channelType, channel.channelType, "IP channel : channel type"));
            result_obj.add(this.is_equal(expected_channel.logicalNumber, channel.logicalNumber, "IP channel : logicalNumber"));
            result_obj.add(this.is_equal(expected_channel.ip, channel.ip, "IP channel : ip"));
            result_obj.add(this.is_equal(expected_channel.port, channel.port, "IP channel : port"));
        }

        return result_obj;
    };

    this.get_channel_from_array =
        function(param, channel_input) {

        if (channel_input === prefix.DONT_CARE) {
        	param.channelType = "unknown";
        } else {
	        param.channelType = String(channel_input[0]);
        }
        if (param.channelType === "rf" || param.channelType === "rf_data") {
            // RF channel
            param.logicalNumber = (channel_input[1] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[1]);
            param.frequency = (channel_input[2] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[2]);
            param.programNumber = (channel_input[3] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[3]);
            param.majorNumber = (channel_input[4] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[4]);
            param.minorNumber = (channel_input[5] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[5]);
            param.rfBroadcastType = (channel_input[6] === prefix.DONT_CARE) ? String("") : String(channel_input[6]);
            param.pcrPid = (channel_input[7] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[7]);
            param.videoPid = (channel_input[8] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[8]);
            param.videoStreamType = (channel_input[9] === prefix.DONT_CARE) ? String("") : String(channel_input[9]);
            param.audioPid = (channel_input[10] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[10]);
            param.audioStreamType = (channel_input[11] === prefix.DONT_CARE) ? String("") : String(channel_input[11]);
            param.signalStrength  = (channel_input[12] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[12]);
            param.sessionId  = (channel_input[13] === prefix.DONT_CARE) ? String("") : String(channel_input[13]);
            param.satelliteId  = (channel_input[14] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[14]);
            param.polarization  = (channel_input[15] === prefix.DONT_CARE) ? String("") : String(channel_input[15]);
            param.symbolRate  = (channel_input[16] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[16]);
            param.plpId  = (channel_input[17] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[17]);
            param.pmtPid  = (channel_input[18] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[18]);
            param.proidiomPid  = (channel_input[19] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[19]);
        } else if (param.channelType === "ip" || param.channelType === "ip_data") {
            // IP channel
            param.logicalNumber = (channel_input[1] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[1]);
            param.isIpv4 = (channel_input[2] === prefix.DONT_CARE) ? true : channel_input[2];
            param.ip = (channel_input[3] === prefix.DONT_CARE) ? String("") : String(channel_input[3]);
            param.port = (channel_input[4] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[4]);
            param.ipBroadcastType = (channel_input[5] === prefix.DONT_CARE) ? String("") : String(channel_input[5]);
            param.programNumber = (channel_input[6] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[6]);
            param.pcrPid = (channel_input[7] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[7]);
            param.videoPid = (channel_input[8] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[8]);
            param.videoStreamType = (channel_input[9] === prefix.DONT_CARE) ? String("") : String(channel_input[9]);
            param.audioPid = (channel_input[10] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[10]);
            param.audioStreamType = (channel_input[11] === prefix.DONT_CARE) ? String("") : String(channel_input[11]);
            param.signalStrength = (channel_input[12] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[12]);
            param.sessionId  = (channel_input[13] === prefix.DONT_CARE) ? String("") : String(channel_input[13]);
            param.sourceAddress = (channel_input[14] === prefix.DONT_CARE) ? String("") : String(channel_input[14]);
            param.pmtPid  = (channel_input[15] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[15]);
            param.proidiomPid  = (channel_input[16] === prefix.DONT_CARE) ? 0 : parseInt(channel_input[16]);
        }
        return param;
    }

    this.is_equal_current_time = function(number_list) {
        var command_result = new GenericResult();
        var current_date = new Date();
        var year = current_date.getFullYear();
        var month = current_date.getMonth() + 1;
        var date = current_date.getDate();
        var hour = current_date.getHours();
        var minute = current_date.getMinutes();
        var second = current_date.getSeconds();

        command_result.add(util.is_equal(number_list['year'], year, "is_equal_current_time : year"));
        command_result.add(util.is_equal(number_list['month'], month, "is_equal_current_time : month"));
        command_result.add(util.is_equal(number_list['date'], date, "is_equal_current_time : date"));
        command_result.add(util.is_equal(number_list['hour'], hour, "is_equal_current_time : hour"));
        command_result.add(util.is_equal(number_list['minute'], minute, "is_equal_current_time : minute"));
        command_result.add(util.is_equal(number_list['second'], number_list['second'], "is_equal_current_time : second " + "(ignore second compare)"));
        return command_result;
    }

}
