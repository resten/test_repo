var prev_mode;
function addBackButtonToGotoBackPage() {
  function __keydown(e) {
    if (!e) e = event;
    var code = (e.keyCode ? e.keyCode : e.which);
    if (code === 0x009E || code === 8) {
        history.back();
    } else if (code === hcap.key.Code.GUIDE) {
        console.log("window.location.reload(true)");
        window.location.reload(true);
    } else if (code === hcap.key.Code.INFO) {
        console.log("hcap.system.launchHcapHtmlApplication({})");
        hcap.system.launchHcapHtmlApplication({});
    } else if (code === hcap.key.Code.PORTAL) {
        console.log("toggle hcap mode");
        hcap.mode.getHcapMode({
            "onSuccess":function(s) {
                console.log("prev_mode = " + prev_mode + ", current hcap mode = " + s.mode);
                if (s.mode === hcap.mode.HCAP_MODE_0) {
                    console.log("hcap.mode.HCAP_MODE_0[" + hcap.mode.HCAP_MODE_0 + "] -> " + prev_mode);
                    hcap.mode.setHcapMode({
                        "mode":prev_mode
                    });
                } else {
                    console.log(prev_mode + " -> hcap.mode.HCAP_MODE_0[" + hcap.mode.HCAP_MODE_0 + "]");
                    prev_mode = s.mode;
                    hcap.mode.setHcapMode({
                        "mode":hcap.mode.HCAP_MODE_0
                    });
                }
            }
        });
    }
  }
  if (document.addEventListener) {
        document.addEventListener("keydown",__keydown,false);
  } else if (document.attachEvent) {
        document.attachEvent("onkeydown", __keydown);
  }
}
addBackButtonToGotoBackPage();