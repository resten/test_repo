function command_result(input_command, input_result, input_fail_reason) {
    var command = input_command;
    var result = input_result;
    var fail_reason = input_fail_reason;

    this.command = function() {
        return command;
    }

    this.is_passed = function() {
        return result;
    }

    this.fail_reason = function() {
        return fail_reason;
    }
}

function GenericResult() {
    this.result = true;
    this.fail_reason = "";

    this.add = function(sub_result) {
        this.result = this.result && sub_result.result;
        if (sub_result.fail_reason != "") {
            this.fail_reason += sub_result.fail_reason + "\n";
        }
        return this;
    };
}

function TestcaseResult(tc_name) {
    var name = tc_name;
    var result = false;
    var fail_reason = "no command";
    var command_result_list = new Array();

    this.is_passed = function() {
        return result;
    }

    this.add_command_result = function(command_result) {
        command_result_list[command_result_list.length] = command_result;
        if (command_result.is_passed()) {
            result = true;
            fail_reason = "";
        } else {
            result = false;
            fail_reason = command_result.fail_reason();
        }
    }

    this.command_result_list = function() {
        return command_result_list;
    }

    this.get_name = function() {
        return name;
    }

    this.get_fail_reason = function() {
        return fail_reason;
    }
}