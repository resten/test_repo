//declare the HTAF version here
var VERSION = "BETA";