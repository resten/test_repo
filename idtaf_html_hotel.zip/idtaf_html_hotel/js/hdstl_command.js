var HDSTL = {};
var host_type;

HDSTL.CommandMap = [];
HDSTL.media = null;

var platform = "unknown";

idcap.request("idcap://system/platform/ get",{"onSuccess":function(s){
  platform = s.platform;
}});

HDSTL.Command = function(grammer_string, executeFn) {
    console.log("grammar_string = " + grammer_string);
    var command = {
        grammar:grammer_string,
        get_name : function() {
            var grammar_split = this.grammar.split("(");
    		var command_name = grammar_split[0].substring(1, grammar_split[0].length);
    		return command_name;
        },
        number_of_argument : function() {
            var grammar_split = this.grammar.split("(");
    		var grammar_comma_split = grammar_split[1].split(",");
    		return grammar_comma_split.length;
        },
        execute:executeFn
    };
    HDSTL.CommandMap[command.get_name()] = command;
}

HDSTL.getCommand = function(commandName) {
	return HDSTL.CommandMap[commandName];
}

HDSTL.setResult = function(result, fail_reason) {
    monitor_task_instance.get_current_testcase_task().get_current_command().set_command_result(result, fail_reason);
}

HDSTL.finish = function() {
    monitor_task_instance.get_current_testcase_task().get_current_command().
        set_status(TASK_TERMINATED);
}

HDSTL.checkSuccess = function(expected_result, check_logic) {
    if (check_logic === null) {
        return function() {
            htaf_log(make_htaf_log("onSuccess"));
            if (expected_result === "?") {
                HDSTL.setResult(true, "onSuccess is Called.");
            } else if (expected_result) {
                HDSTL.setResult(true, "onSuccess is Called.");
            } else {
                HDSTL.setResult(false, "Expected onFaliure, but onSuccess is Called.");
            }
            HDSTL.finish();
        };
    } else {
        return function(param) {
            htaf_log(make_htaf_log("onSuccess", param));
            if (expected_result === "?") {
                HDSTL.setResult(true, "onSuccess is Called.");
            } else if (expected_result) {
                var command_result = check_logic(param);
                HDSTL.setResult(command_result.result, command_result.fail_reason);
            } else {
                HDSTL.setResult(false, "Expected onFaliure, but onSuccess is Called.");
            }
            HDSTL.finish();
        };
    }
}

HDSTL.checkFailure = function(expected_result) {
    return function(param) {
        htaf_log(make_htaf_log("onFailure", param));
        if (expected_result === "?") {
            HDSTL.setResult(true, "onFailure is Called. : " + param.errorMessage);
        } else if (expected_result) {
            HDSTL.setResult(false, "Expected onSuccess, but onFailure is Called.");
        } else {
            HDSTL.setResult(true, "onFailure is Called. : " + param.errorMessage);
        }
        HDSTL.finish();
    };
}

HDSTL.checkSuccess2 = function(expected_result, check_logic, cleanup) {
    if (check_logic === null) {
        return function() {
            htaf_log(make_htaf_log("onSuccess"));
            if (expected_result === "?") {
                HDSTL.setResult(true, "onSuccess is Called.");
            } else if (expected_result) {
                HDSTL.setResult(true, "onSuccess is Called.");
            } else {
                HDSTL.setResult(false, "Expected onFaliure, but onSuccess is Called.");
            }
            cleanup();
            HDSTL.finish();
        };
    } else {
        return function(param) {
            htaf_log(make_htaf_log("onSuccess", param));
            if (expected_result === "?") {
                HDSTL.setResult(true, "onSuccess is Called.");
            } else if (expected_result) {
                var command_result = check_logic(param);
                HDSTL.setResult(command_result.result, command_result.fail_reason);
            } else {
                HDSTL.setResult(false, "Expected onFaliure, but onSuccess is Called.");
            }
            cleanup();
            HDSTL.finish();
        };
    }
}

HDSTL.checkFailure2 = function(expected_result, check_logic, cleanup) {
    return function(param) {
        htaf_log(make_htaf_log("onFailure", param));
        if (expected_result === "?") {
            HDSTL.setResult(true, "onFailure is Called.");
        } else if (expected_result) {
            HDSTL.setResult(false, "Expected onSuccess, but onFailure is Called.");
        } else {
            HDSTL.setResult(true, "onFailure is Called.");
        }
        cleanup();
        HDSTL.finish();
    };
}


HDSTL.addEvent = function(event, listener) {
    return function() {
        htaf_log("\nHDSTL.addEvent '"+  event + "'");
        document.addEventListener(event, listener, false);
    };
}
HDSTL.removeEvent = function(event, listener) {
    return function() {
        htaf_log("\nHDSTL.removeEvent '"+  event + "'");
        document.removeEventListener(event, listener, false);
    };
}

// -----------------------------------------------------------------------------------
//  Start of HDSTL COMMAND
// -----------------------------------------------------------------------------------
HDSTL.Command("@add_key_item(keycode, virtualKeycode:string, attribute, result)",
    function(args) {
        var expected_result = args[4];
        var param = {
            "keycode": args[1],
            "virtualKeycode": args[2],
            "attribute": args[3],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.key.addKeyItem(param);
    }
);

HDSTL.Command("@check_external_input(input_type, input_index, result, is_connected)",
    function(args) {
        var expected_result = args[3], expected_is_connected = args[4];
        var param = {
            "type": args[1],
            "index": args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_is_connected, param.isConnected, "isConnected");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.externalinput.isExternalInputConnected(param);
    }
);

HDSTL.Command("@clear_carousel_data(result)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.carousel.clearCarouselDataCache(param);
    }
);

HDSTL.Command("@clear_key_table( result )",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.key.clearKeyTable(param);
    }
);

HDSTL.Command("@get_current_channel(result, channel, channel_status)",
    function(args) {
        var expected_result = args[1],
            expected_channel = util.get_channel_with_dontcare_from_array(args[2]),
            expected_channel_status = args[3];

        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal_channel(expected_channel, param, "channel");
                    command_result.add(util.is_equal(expected_channel_status, param.channelStatus, "channelStatus"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.getCurrentChannel(param);
    }
);

HDSTL.Command("@get_current_channel_audio_language_index(result, index)",
    function(args) {
        var expected_result = args[1], expected_index = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_index, param.index, "index");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.getCurrentChannelAudioLanguageIndex(param);
    }
);

HDSTL.Command("@get_current_channel_audio_language_list(result, language_list)",
    function(args) {
        var expected_result = args[1], expected_list = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal_list_with_sort(expected_list, param.list, "list");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.getCurrentChannelAudioLanguageList(param);
    }
);

HDSTL.Command("@get_current_channel_subtitle_language_index(result, index)",
    function(args) {
        var expected_result = args[1], expected_index = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_index, param.index, "index");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.getCurrentChannelSubtitleIndex(param);
    }
);

HDSTL.Command("@get_current_channel_subtitle_language_list(result, language_list)",
    function(args) {
        var expected_result = args[1], expected_list = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal_list_with_sort(expected_list, param.list, "list");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.getCurrentChannelSubtitleList(param);
    }
);

HDSTL.Command("@get_data_channel(result, channel)",
    function(args) {
        var expected_result = args[1],
            expected_channel = util.get_data_channel_with_dontcare_from_array(args[2]);
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal_data_channel(expected_channel, param,"data_channel");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.getDataChannel(param);
    }
);

HDSTL.Command("@get_external_input(result, input_type, input_index)",
    function(args) {
        var expected_result = args[1], expected_source_type = args[2], expected_source_index = args[3];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_source_type, param.type , "type");
                    command_result.add(util.is_equal(expected_source_index, param.index, "index"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.externalinput.getCurrentExternalInput(param);
    }
);

HDSTL.Command("@get_mouse_visible(result, mouse_visible)",
    function(args) {
        var expected_result = args[1], expected_mouse_visible = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                     var command_result = util.is_equal(expected_mouse_visible, param.isVisible, "isVisible");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.mouse.isMouseVisible(param);
    }
);

HDSTL.Command("@get_mw_mode(result,hcap_mode)",
    function(args) {
        var expected_result = args[1], expected_mw_mode = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_mw_mode, param.mode, "mw_mode");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.mode.getHcapMode(param);
    }
);

HDSTL.Command("@get_network_device(index:number, result:number, network_mode:number, device_name:string, device_mac:string, device_dhcp:bool, device_ip:string, device_gateway:string, device_netmask:string, device_primary_dns:string, device_secondary_dns:string)",
    function(args) {
        var expected_result = args[2],
            expected_network_mode = args[3],
            expected_name = args[4],
            expected_mac = args[5],
            expected_dhcp = args[6],
            expected_ip = args[7],
            expected_gateway = args[8],
            expected_netmask = args[9],
            expected_primary_dns = args[10],
            expected_secondary_dns = args[11];

        htaf_log(make_htaf_log("[Test Args]", args));

        hcap.network.getNetworkDevice({
            "index": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_network_mode, param.networkMode, "networkMode");
                    command_result.add(util.is_equal(expected_name, param.name, "name"));
                    command_result.add(util.is_equal(expected_mac, param.mac, "mac"));
                    command_result.add(util.is_equal(expected_dhcp, param.dhcp, "dhcp"));
                    command_result.add(util.is_equal(expected_ip, param.ip, "ip"));
                    command_result.add(util.is_equal(expected_gateway, param.gateway, "gateway"));
                    command_result.add(util.is_equal(expected_netmask, param.netmask, "netmask"));
                    command_result.add(util.is_equal(expected_primary_dns, param.primaryDns, "primaryDns"));
                    command_result.add(util.is_equal(expected_secondary_dns, param.secondaryDns, "secondaryDns"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        });
    }
);

HDSTL.Command("@get_number_of_network_devices(result, number_of_network_devices)",
    function(args) {
        var expected_result = args[1],
            expected_count = args[2];

        var param = {
            "index": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                     var command_result = util.is_equal(expected_count, param.count, "count");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.network.getNumberOfNetworkDevices(param);
    }
);

HDSTL.Command("@get_osd_transparency_level(result, osd_transparency_level )",
    function(args) {
        var expected_result = args[1],
            expected_level  = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_level, param.level, "level");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.video.getOsdTransparencyLevel(param);
    }
);

HDSTL.Command("@get_power_mode(result, power_mode)",
    function(args) {
        var expected_result = args[1],
            expected_power_mode = args[2];
        var param = {
            "parameters" : {},
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_power_mode, param.mode, "mode");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.power.getPowerMode(param);
    }
);

HDSTL.Command("@is_power_warm_update(result:number, is_warm_update:boolean)",
    function(args) {
        var expected_result = args[1],
            expected_is_warm_update = args[2];
        var param = {
            "parameters" : {},
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_is_warm_update, param.isWarmUpdate, "isWarmUpdate");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.power.isWarmUpdate(param);
    }
);

HDSTL.Command("@get_power_off_timer(result, power_off_timer_in_minute)",
    function(args) {
        var expected_result = args[1], expected_minutes = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_minutes, param.minute, "minute");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.time.getPowerOffTimer(param);
    }
);

HDSTL.Command("@get_power_on_time(result, hour, minute)",
    function(args) {
        var expected_result = args[1], expected_hour = args[2], expected_minute = args[3];

        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_hour, param.hour , "hour");
                    command_result.add(util.is_equal(expected_minute, param.minute , "minute"))
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.time.getPowerOnTime(param);
    }
);

HDSTL.Command("@get_property(key, result, expected_value)",
    function(args) {
        var key = args[1], expected_result = args[2], expected_value = args[3];
        var param = {
            "key": key,
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_value, param.value, "value");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.property.getProperty(param);
    }
);

HDSTL.Command("@get_start_channel(result, channel)",
    function(args) {
        var expected_result = args[1],
            expected_channel = util.get_channel_with_dontcare_from_array(args[2]);
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal_channel(expected_channel, param, "channel");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[args]", args));
        hcap.channel.getStartChannel(param);
    }
);

HDSTL.Command("@get_video_layer_size(result, width, height)",
    function(args) {
        var expected_result = args[1], width = args[2], height = args[3],
            expected_value = width + "x" + height;
        var param = {
            "key": "display_resolution",
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_value, param.value, "check display_resolution");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.property.getProperty(param);
    }
);

HDSTL.Command("@get_video_mute(result, mute)",
    function(args) {
        var expected_result = args[1], expected_video_mute = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_video_mute, param.videoMute, "videoMute");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.video.isVideoMute(param);
    }
);

HDSTL.Command("@get_video_size(result, x, y, width, height)",
    function(args) {
        var expected_result = args[1], x = args[2], y = args[3], width = args[4], height =args[5];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(x, param.x, "x");
                    command_result.add(util.is_equal(y, param.y, "y"));
                    command_result.add(util.is_equal(width, param.width, "width"));
                    command_result.add(util.is_equal(height, param.height, "height"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.video.getVideoSize(param);
    }
);

HDSTL.Command("@get_volume(result,speakerType, level,muted)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.volume.getVolumeLevel(param);
    }
);

HDSTL.Command("@get_soundmode(result,soundMode)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://audio/soundmode/get",param);
    }
);

HDSTL.Command("@set_soundmode(soundMode,result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "parameters":{"soundMode":args[1]},
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://audio/soundmode/set",param);
    }
);
HDSTL.Command("@is_content_loaded(url, result, cache_path)",
    function(args) {
        var url = args[1], expected_result = args[2], expected_cache_path = args[3];

        var param = {
            "url": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_cache_path, param.cachePath, "cachePath");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.carousel.isCarouselDataCached(param);
    }
);

// HDSTL.Command("@ping(ip, result, round_trip_time_in_ms )",
//     function(args) {
//         var ip = args[1], expected_result = args[2], expected_round_trip_time = args[3];

//         var param = {
//             "ip": ip,
//             "onSuccess": HDSTL.checkSuccess(expected_result,
//                 function(param) {
//                     var command_result = util.is_equal(expected_round_trip_time, param.roundTripTimeInMs, "roundTripTimeInMs");
//                     return command_result;
//                 }),
//             "onFailure": HDSTL.checkFailure(expected_result)
//         };

//         htaf_log(make_htaf_log("[Test Args]", args));
//         hcap.network.ping(param);
//     }
// );

HDSTL.Command("@power_off(result)",
    function(args) {
        var expected_result = args[1];
        var param = {
           "powerCommand" : "powerOff",
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.power.powerOff(param);
    }
);

HDSTL.Command("@reboot(result)",
    function(args) {
        var expected_result = args[1];
        var param = {
          "powerCommand" : "reboot",
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.power.reboot(param);
        //idcap.request("idcap://power/command",param);
    }
);

HDSTL.Command("@remove_key_item(keycode, result )",
    function(args) {
        var expected_result = args[2];
        var param = {
            "keycode": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.key.removeKeyItem(param);
    }
);

HDSTL.Command("@replay_current_channel(result)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.replayCurrentChannel(param);
    }
);

HDSTL.Command("@channel_change(channel_info, result, callback_result)",
    function(args) {
        var channel_input = args[1],
            expected_result = args[2],
            expected_callback_result = args[3],
            event_name = "idcap::channel_changed",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));
                var command_result = util.is_equal(expected_callback_result, param.result, "result");
                HDSTL.setResult(command_result.result, command_result.fail_reason);
                HDSTL.finish();
            };

        var param = {
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };
        util.get_channel_from_array(param, channel_input);
        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.requestChangeCurrentChannel(param);
    }
);

HDSTL.Command("@request_carousel_contents(carousel_url, result, callback_result, callback_url, callback_loaded_path)",
    function(args) {
        var request_url = args[1],
            expected_result = args[2],
            expected_callback_result = args[3],
            expected_url = args[1],
            expected_cache_path = args[5],
            event_name = "carousel_data_cached",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));
                var command_result = util.is_equal(expected_callback_result, param.result, "result");
                command_result.add(util.is_equal(expected_url, param.url, "url"));
                command_result.add(util.is_equal(expected_cache_path, param.cachePath, "cachePath"));
                HDSTL.setResult(command_result.result, command_result.fail_reason);
                HDSTL.finish();
            };

        var param = {
            "url": request_url,
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };

        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.carousel.requestCacheCarouselData(param);
    }
);

HDSTL.Command("@send_and_receive_mpi_data(id, sequence, packet, expected_packet)",
    function(args) {
        var expected_result = args[4], expected_packet = args[5];
        var param = {
            id: args[1],
            sequence: args[2],
            packet: args[3],
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_packet, param.packet, "packet");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.mpi.sendAndReceiveMpiData(param);
    }
);

HDSTL.Command("@send_key(virtualKeycode, result )",
    function(args) {
        var expected_result = args[2];
        var param = {
            "virtualKeycode": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.key.sendKey(param);
    }
);

HDSTL.Command("@send_mpi_data(id, sequence, packet, result, callback_result, expected_id, expected_sequence, expected_packet)",
    function(args) {
        var expected_result = args[4],
            expected_callback_result = args[5],
            expected_id = args[6],
            expected_sequence = args[7],
            expected_packet = args[8],
            event_name = "mpi_data_received",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));

                var command_result = util.is_equal(expected_callback_result, param.result, "result");
                command_result.add(util.is_equal(expected_id, param.id, "id"));
                command_result.add(util.is_equal(expected_sequence,param.sequence, "sequence"));
                command_result.add(util.is_equal(expected_packet, param.packet, "packet"));
                HDSTL.setResult(command_result.result, command_result.fail_reason);
                HDSTL.finish();
            };

        var param = {
            id: args[1],
            sequence: args[2],
            packet: args[3],
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };

        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.mpi.sendMpiData(param);
    }
);

HDSTL.Command("@set_current_channel_audio_language_index(index, result)",
    function(args) {
        var expected_result = args[2],
            event_name = "current_channel_audio_language_changed",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));
                HDSTL.setResult(true, event_name + " event received");
                HDSTL.finish();
            };

        var param = {
            "index": args[1],
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };

        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.setCurrentChannelAudioLanguageIndex(param);
    }
);

HDSTL.Command("@set_current_channel_subtitle_language_index(index, result)",
    function(args) {
        var expected_result = args[2],
            event_name = "current_channel_subtitle_changed",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));
                HDSTL.setResult(true, event_name + " event received");
                HDSTL.finish();
            };

        var param = {
            "index": args[1],
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };

        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.setCurrentChannelSubtitleIndex(param);
    }
);

HDSTL.Command("@set_external_input(input_type, input_index, result)",
    function(args) {
        var expected_result = args[3],
            event_name = "idcap::external_input_changed",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));
                HDSTL.setResult(true, event_name + " event received");
                HDSTL.finish();
            },
            media_hub_event_name = "idcap::media_hub_event_received",
            media_hub_event_listener = function mediaHubEventListener(param) {
                HDSTL.removeEvent(media_hub_event_name, media_hub_event_listener)();
                htaf_log(make_htaf_log(media_hub_event_name, param));
                HDSTL.setResult(true, media_hub_event_name + " event received");
                HDSTL.finish();
            };

        var param = {
            "type": args[1],
            "index": args[2],
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };

        HDSTL.addEvent(event_name, event_listener)();
        HDSTL.addEvent(media_hub_event_name, media_hub_event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.externalinput.setCurrentExternalInput(param);
    }
);

HDSTL.Command("@set_mouse_visible(mouse_visible, result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "isVisible": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.mouse.setMouseVisible(param);
    }
);

HDSTL.Command("@set_mw_mode(hcap_mode, result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "mode": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.mode.setHcapMode(param);
    }
);

HDSTL.Command("@set_osd_transparency_level(osd_transparency_level, result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "level": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.video.setOsdTransparencyLevel(param);
    }
);

HDSTL.Command("@set_power_mode(power_mode, result)",
    function(args) {
        var expected_result = args[2],
            event_name = "idcappower_mode_changed",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));
                HDSTL.setResult(true, event_name + " event received");
                HDSTL.finish();
            };
        var param = {
            "mode": args[1],
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };

        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.power.setPowerMode(param);
    }
);

HDSTL.Command("@set_power_off_timer(power_off_timer_in_minute, result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "minute": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.time.setPowerOffTimer(param);
    }
);
HDSTL.Command("@set_power_on_time(hour, minute, result)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "hour": args[1],
            "minute": args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.time.setPowerOnTime(param);
    }
);

HDSTL.Command("@set_property(key, value, result, expected_key, expected_value)",
    function(args) {
        var expected_result = args[3],
            expected_key = args[4],
            event_name = "property_changed",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));
                var command_result = util.is_equal(expected_key, param.key, "key ");
                HDSTL.setResult(command_result.result, command_result.fail_reason);
                HDSTL.finish();
            };

        var param = {
            "key": args[1],
            "value": args[2],
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };

        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.property.setProperty(param);
    }
);

HDSTL.Command("@set_start_channel(channel, result)",
    function(args) {
        var channel_input = args[1],
            expected_result = args[2],
            event_name = "start_channel_changed",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));
                HDSTL.setResult(true, event_name + " event received");
                HDSTL.finish();
            };

        var param = {
            "key": args[1],
            "value": args[2],
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };
        util.get_channel_from_array(param, channel_input);

        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.setStartChannel(param);
    }
);

var is_number_list = function(number_list) {
    for ( var i = 0; i < number_list.length; i++) {
        var value = parseInt(number_list[i]);
        if (isNaN(value)) {
            return false;
        }
    }
    return true;
};
HDSTL.Command("@change_tv_local_time(time, gmt_offset_in_minute, daylight_saving, result, expected_time, expected_gmt_offset_in_minute, expected_daylight_saving)",
    function(args) {
        htaf_log("____ current time ____" + new Date());
        var event_count = 2,
            date_n_time_string = args[1],
            gmtOffsetInMinute = args[2],
            isDaylightSaving = args[3],
            expected_result = args[4],
            expected_date_n_time_string = args[5],
            expected_gmt = args[6],
            expected_daylight = args[7],
            event_name = "property_changed",
            parse_date_n_time_string = function(date_n_time_string) {
                // format ==> year.month.day hour:min:sec
                var number_list = new Array();
                var date_n_time = date_n_time_string.split(" ");
                if (date_n_time.length != 2) {
                    console.log("\n[HCAP_LOG][ change_tv_local_time ] " +
                            "invalid time string : " + time_string + "\n");
                    return null;
                }
                var date_string = date_n_time[0];
                var time_string = date_n_time[1];

                var date_elements = date_string.split(".");
                if (date_elements.length != 3 || !is_number_list(date_elements)) {
                    console.log("\n[HCAP_LOG][ change_tv_local_time ] " +
                            "invalid date string : " + date_string + "\n");
                    return null;
                }
                number_list['year'] = parseInt(date_elements[0]);
                number_list['month'] = parseInt(date_elements[1]);
                number_list['date'] = parseInt(date_elements[2]);

                var time_elements = time_string.split(":");
                if (time_elements.length != 3 ||
                        !is_number_list(time_elements)) {
                    console.log("\n[HCAP_LOG][ change_tv_local_time ] " +
                            "invalid time string : " + time_string + "\n");
                    return null;
                }
                number_list['hour'] = parseInt(time_elements[0]);
                number_list['minute'] = parseInt(time_elements[1]);
                number_list['second'] = parseInt(time_elements[2]);
                return number_list;
            },
            date_n_time = parse_date_n_time_string(date_n_time_string),
            event_listener = function eventListener(param) {
                restartTimer();
                htaf_log(make_htaf_log(event_name, param));
                if(param.key === "gmt_offset_in_minute" || param.key === "daylight_saving" ) {
                    event_count--;
                }
                if(event_count === 0) {
                    HDSTL.removeEvent(event_name, event_listener)();
                    htaf_log(make_htaf_log("property_changed", param));
                    var command_result = util.is_equal_current_time(date_n_time);
                    HDSTL.setResult(command_result.result, command_result.fail_reason);
                    htaf_log(make_htaf_log("is_equal_current_time", command_result));
                    HDSTL.finish();
                }
            };

        if (date_n_time === null) {
            HDSTL.setResult(false, "invalid date & time string : " + date_n_time_string);
            HDSTL.finish();
            return;
        }
        var param = {
            "year": date_n_time.year,
            "month": date_n_time.month,
            "day": date_n_time.date,
            "hour": date_n_time.hour,
            "minute": date_n_time.minute,
            "second": date_n_time.second,
            "gmtOffsetInMinute": gmtOffsetInMinute,
            "isDaylightSaving": isDaylightSaving,
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };

        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.time.setLocalTime(param);
        monitor_task_instance.start_monitor();

    }
);

HDSTL.Command("@get_tv_local_time(result, expected_year, expected_month, expected_day, expected_hour, expected_minute, expected_second, expected_gmt_offset_in_minute, expected_daylight_saving)",
    function(args) {
        var expected_result = args[1],
            expected_year = args[2],
            expected_month = args[3],
            expected_day = args[4],
            expected_hour = args[5],
            expected_minute = args[6],
            expected_second = args[7],
            expected_gmt = args[8],
            expected_dst = args[9];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_year, param.year, "year");
                    command_result.add(util.is_equal(expected_month, param.month, "month"));
                    command_result.add(util.is_equal(expected_day, param.day, "day"));
                    command_result.add(util.is_equal(expected_hour, param.hour, "hour"));
                    command_result.add(util.is_equal(expected_minute, param.minute, "minute"));
                    command_result.add(util.is_equal(expected_gmt, param.gmtOffsetInMinute, "gmtOffsetInMinute"));
                    command_result.add(util.is_equal(expected_dst, param.isDaylightSaving, "isDaylightSaving"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.time.getLocalTime(param);
    }
);

HDSTL.Command("@set_video_mute(mute, result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "videoMute": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.video.setVideoMute(param);
    }
);

HDSTL.Command("@set_video_size(x, y, width, height, result)",
    function(args) {
        var expected_result = args[5];
        var param = {
            "x": args[1],
            "y": args[2],
            "width": args[3],
            "height": args[4],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.video.setVideoSize(param);
    }
);

HDSTL.Command("@set_volume(speakerType,level,muted, result)",
    function(args) {
        var expected_result = args[2],
            event_name = "idcap::volume_level_changed",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));
                HDSTL.setResult(true, event_name + " event received");
                HDSTL.finish();
            };

        var param = {
            "speakerType":args[1],
            "level": args[2],
            "muted": args[3],
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };

        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.volume.setVolumeLevel(param);
    }
);

HDSTL.Command("@stop_current_channel(result)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.stopCurrentChannel(param);
    }
);

HDSTL.Command("@request_channel_up(expected_result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.requestChannelUp(param);
    }
);

HDSTL.Command("@request_channel_down(expected_result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.requestChannelDown(param);
    }
);

HDSTL.Command("@sleep(mili_second)",
    function(args) {
        var sleep_interval_id,
            sleep_interval_in_ms = args[1],
            processing_task = function() {
                clearInterval(sleep_interval_id);
                HDSTL.setResult(true, "");
                HDSTL.finish();
            };

        sleep_interval_id = setInterval(processing_task, sleep_interval_in_ms);
    }
);

var manual_message_text;
function set_result(result){
    enable_timeout_check();
    if (result === true){
        toggle();
        toggle_blanket();
        HDSTL.setResult(true, manual_message_text);
        HDSTL.finish();
    }
    else {
        HDSTL.setResult(false, manual_message_text);
        HDSTL.finish();
        toggle();
        toggle_blanket();
    }
    is_manual_window_on = false;
}
// MAnual window
function toggle(message) {
    var el = document.getElementById('popup_div');
    var message_area = document.getElementById('message');
    if ( el.style.display === 'none' ) {
        el.style.display = 'block';
        message_area.innerHTML = message;
    }
    else {el.style.display = 'none';}
}

function toggle_blanket() {
    var el = document.getElementById('blanket');
    if ( el.style.display === 'none' ) {
        el.style.display = 'block';
    }
    else {el.style.display = 'none';}
}

function blanket_size() {
    if (typeof window.innerWidth != 'undefined') {
        viewportheight = window.innerHeight;
    } else {
        viewportheight = document.documentElement.clientHeight;
    }
    if ((viewportheight > document.body.parentNode.scrollHeight) &&
            (viewportheight > document.body.parentNode.clientHeight)) {
        blanket_height = viewportheight;
    } else {
        if (document.body.parentNode.clientHeight >
            document.body.parentNode.scrollHeight) {
            blanket_height = document.body.parentNode.clientHeight;
        } else {
            blanket_height = document.body.parentNode.scrollHeight;
        }
    }
    var blanket = document.getElementById('blanket');
    blanket.style.height = blanket_height + 'px';
    var popup_div = document.getElementById('popup_div');
    popup_div_height = blanket_height/2-100;//150 is half popup's height
    popup_div.style.top = popup_div_height + 'px';
}

function window_pos() {
    if (typeof window.innerWidth != 'undefined') {
        viewportwidth = window.innerHeight;
    } else {
        viewportwidth = document.documentElement.clientHeight;
    }
    if ((viewportwidth > document.body.parentNode.scrollWidth) &&
        (viewportwidth > document.body.parentNode.clientWidth)) {
        window_width = viewportwidth;
    } else {
        if (document.body.parentNode.clientWidth >
            document.body.parentNode.scrollWidth) {
            window_width = document.body.parentNode.clientWidth;
        } else {
            window_width = document.body.parentNode.scrollWidth;
        }
    }
    var popup_div = document.getElementById('popup_div');
    window_width=window_width/2-150;//150 is half popup's width
    popup_div.style.left = window_width + 'px';
}

HDSTL.Command("@manual_check(message)",
    function(args) {
        disable_timeout_check();
        is_manual_window_on = true;
        manual_message_text = args[1];
        blanket_size();
        window_pos();
        toggle_blanket();
        toggle(manual_message_text);
    }
);

// -----------------------------------------------------------------------------------
//  End of HDSTL COMMAND
// -----------------------------------------------------------------------------------

// --------------------------------------------------------------
// IHcapMedia
// --------------------------------------------------------------
HDSTL.Command("@startup_media(result)",
    function(args) {
        var expected_result = args[1];

        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://tv/media/startUp",param);
    }
);

HDSTL.Command("@shutdown_media(result)",
    function(args) {
        var expected_result = args[1];

        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://tv/media/shutDown",param);
    }
);

HDSTL.Command("@create_media(url, mime_type, drm_type, sessionId, subtitleUrl, result)",
    function(args) {
        var expected_result = args[6];
        var param = {
            "parameters":{
                        "url": args[1],
                        "mimeType": args[2],
                        "drmType": args[3],
                        "sessionId": args[4],
                        "subtitleUrl": args[5]},

            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

     // to get the latest media object.
        if (args[1] === "0" && args[2] === "0" && args[3] === "0" && args[4] === "0" && args[5] === "0") {
            param = null;
        }

        idcap.request("idcap://tv/media/create",param);
    }
);

HDSTL.Command("@securemedia_initialize(companyName, result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "companyName": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.drm.securemedia.initialize(param);
    }
);

HDSTL.Command("@securemedia_unregister(companyName, result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "companyName": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.drm.securemedia.unregister(param);

    }
);

HDSTL.Command("@securemedia_isRegistration(result, isRegisteration)",
    function(args) {
        var expected_result = args[1], expected_isRegisteration = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, function(param) {
                    var command_result = util.is_equal(expected_isRegisteration, param.isRegisteration, "isRegisteration");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.drm.securemedia.isRegistration(param);

    }
);

HDSTL.Command("@securemedia_register(deviceInfo, appInfo, esamUrl, result)",
    function(args) {
        var expected_result = args[4];
        var param = {
            "deviceInfo": args[1],
            "appInfo": args[2],
            "esamUrl": args[3],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.drm.securemedia.register(param);

    }
);

HDSTL.Command("@securemedia_finalize(result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.drm.securemedia.finalize(param);

    }
);

HDSTL.Command("@set_subtitle_on(subtitle_on, result)",
    function(args) {
        var expected_result = args[2];
        var param = {
          "parameters":{"subtitleOn":args[1]},

            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };
        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://tv/media/subtitleon/set",param);
    }
);

HDSTL.Command("@get_subtitle_on(result, subtitle_on)",
    function(args) {
    	var expected_result_subtitle_on = args[2];
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, function(param) {
                    var command_result = util.is_equal(expected_result_subtitle_on, param.subtitleOn, "subtitleOn");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };
        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://tv/media/subtitleon/get",param);
    }
);

HDSTL.Command("@set_subtitle(type, index, result)",
    function(args) {
        var expected_result = args[3];
        var param = {
          "parameters":{"type":args[1],
                  	"index":args[2]},

            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };
        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://tv/media/subtitle/set",param);
    }
);

HDSTL.Command("@get_subtitle(result, type, index, list)",
    function(args) {
        var expected_result = args[1],
            expected_type = args[2],
            expected_index = args[3],
            expected_list = args[4];

        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_type, param.type, "type");
                    command_result.add(util.is_equal(expected_index, param.index, "index"));
                    command_result.add(util.is_equal(expected_list, param.list, "list"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        idcap.request("idcap://tv/media/subtitle/get",param);
    }
);

HDSTL.Command("@set_subtitle_url(url, result)",
    function(args) {
        var expected_result = args[2];
        var param = {
          "parameters":{"subtitleUrl":args[1]},

            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };
        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://tv/media/subtitleurl/set",param);
    }
);

HDSTL.Command("@play(repeat_count, result)",
    function(args) {
        var repeat_count = args[1],
            expected_result = args[2],
            event_name = "idcap::media_event_received",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));
                var command_result = util.is_equal("play_start", param.eventType, "result");
                HDSTL.setResult(command_result.result, command_result.fail_reason);
                HDSTL.finish();
            };

        htaf_log(make_htaf_log("[Test Args]", args));


        HDSTL.addEvent(event_name, event_listener)();

        var param = {
            "parameters":{"command":"play","repeatCount": repeat_count},

            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };
        idcap.request("idcap://tv/media/control",param);

    }
);

HDSTL.Command("@pause(result)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "parameters":{"command":"pause"},
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };
        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://tv/media/control",param);
    }
);

HDSTL.Command("@resume(result)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "parameters":{"command":"resume"},
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };
        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://tv/media/control",param);
    }
);

HDSTL.Command("@stop(result)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "parameters":{"command":"stop"},
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };
        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://tv/media/control",param);
    }
);

HDSTL.Command("@destroy(result)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        idcap.request("idcap://tv/media/destroy",param);
    }
);

HDSTL.Command("@get_play_speed(result, speed)",
    function(args) {
        var expected_result = args[1], expected_speed = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_speed, param.speed, "speed");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };
        idcap.request("idcap://tv/media/playspeed/get",param);
    }
);

HDSTL.Command("@set_play_speed(speed, result)",
    function(args) {
        var expected_result = args[2];
        var param = {
          "parameters":{"speed": args[1]},

            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://tv/media/playspeed/set",param);
    }
);

HDSTL.Command("@get_play_position(result, position_in_ms)",
    function(args) {
        var expected_result = args[1], expected_position = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_position, param.positionInMs, "positionInMs");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };
        idcap.request("idcap://tv/media/playposition/get",param);
    }
);

HDSTL.Command("@set_play_position(position_in_ms, result)",
    function(args) {
        var expected_result = args[2];

        /*
        var param = {
            "positionInMs": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };
        */

        var event_name = "idcap::media_event_received",
        event_listener = function eventListener(param) {
            HDSTL.removeEvent(event_name, event_listener)();
            htaf_log(make_htaf_log(event_name, param));
            var command_result = util.is_equal("seek_done", param.eventType, "result");
            HDSTL.setResult(command_result.result, command_result.fail_reason);
            HDSTL.finish();
        };

        HDSTL.addEvent(event_name, event_listener)();

        var param = {
          "parameters":{"positionInMs": args[1]},

            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://tv/media/playposition/set",param);
    }
);

HDSTL.Command("@get_state(result, state)",
    function(args) {
        var expected_result = args[1], expected_state = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_state, param.state, "state");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        idcap.request("idcap://tv/media/state/get",param);
    }
);

HDSTL.Command("@get_information(result, video_available, title, content_length_in_ms)",
    function(args) {
        var expected_result = args[1],
            expected_video_available = args[2],
            expected_title = args[3],
            expected_content_length = args[4];

        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_video_available, param.videoAvailable, "videoAvailable");
                    command_result.add(util.is_equal(expected_title, param.title, "title"));
                    command_result.add(util.is_equal(expected_content_length, param.contentLengthInMs, "contentLengthInMs"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        idcap.request("idcap://tv/media/information/get",param);


    }
);

HDSTL.Command("@get_alarm_information(result:number, hour:number, minute:number, channel:list, volume_level:number)",
    function(args) {
        var expected_result = args[1],
        		expected_hour = args[2],
        		expected_minute = args[3],
        		expected_channel = util.get_channel_with_dontcare_from_array(args[4]),
        		expected_volume_level = args[5];

        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                	var command_result = util.is_equal(expected_hour, param.hour, "hour");
                	command_result.add(util.is_equal(expected_minute, param.minute, "minute"));
                	command_result.add(util.is_equal_channel(expected_channel, param, "channel"));
                	command_result.add(util.is_equal(expected_volume_level, param.volumeLevel, "volume level"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.time.getAlarmInformation(param);
    }
);

HDSTL.Command("@set_alarm_information(hour:number, minute:number, channel:list, volume_level:number, result:number)",
    function(args) {
        var expected_result = args[5],
        		channel_input =  util.get_channel_with_dontcare_from_array(args[3]);

        var param = {
        	"hour":args[1],
            "minute":args[2],
            "channelType": channel_input,
        	"volumeLevel":args[4],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        util.get_channel_from_array(param, channel_input);

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.time.setAlarmInformation(param);
    }
);

HDSTL.Command("@get_media_audio_language(result, index)",
    function(args) {
        var expected_result = args[1],

            expected_index = args[2];

        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = (util.is_equal(expected_index, param.index, "index"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        if (HDSTL.media) {
            HDSTL.media.getAudioLanguage(param);
        } else {
            HDSTL.setResult(false, "HDSTL.media is null.");
            HDSTL.finish();
        }
    }
);

HDSTL.Command("@set_media_audio_language(index, result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "index": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        if (HDSTL.media) {
            HDSTL.media.setAudioLanguage(param);
        } else {
            HDSTL.setResult(false, "HDSTL.media is null.");
            HDSTL.finish();
        }
    }
);


HDSTL.Command("@get_program_info(result:number, cur_title:string, cur_year:number, cur_month:number, cur_day:number, cur_hour:number, cur_minute:number, cur_second:number, cur_length:string, next_title:string, next_year:number, next_month:number, next_day:number, next_hour:number, next_minute:number, next_second:number, next_length:string)",
    function(args) {
        var expected_result = args[1],
        		expected_cur_title = args[2],
        		expected_cur_year = args[3],
        		expected_cur_month = args[4],
        		expected_cur_day = args[5],
        		expected_cur_hour = args[6],
        		expected_cur_minute = args[7],
        		expected_cur_second = args[8],
        		expected_cur_length = args[9],
        		expected_next_title = args[10],
        		expected_next_year = args[11],
        		expected_next_month = args[12],
        		expected_next_day = args[13],
        		expected_next_hour = args[14],
        		expected_next_minute = args[15],
        		expected_next_second = args[16],
        		expected_next_length = args[17];

        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                	var command_result = util.is_equal(expected_cur_title, param.currentProgram.title, "current program : title");
                	command_result.add(util.is_equal(expected_cur_year, param.currentProgram.startTime.year, "current program : start time - year"));
                	command_result.add(util.is_equal(expected_cur_month, param.currentProgram.startTime.month, "current program : start time - month"));
                	command_result.add(util.is_equal(expected_cur_day, param.currentProgram.startTime.day, "current program : start time - day"));
                	command_result.add(util.is_equal(expected_cur_hour, param.currentProgram.startTime.hour, "current program : start time - hour"));
                	command_result.add(util.is_equal(expected_cur_minute, param.currentProgram.startTime.minute, "current program : start time - minute"));
                	command_result.add(util.is_equal(expected_cur_second, param.currentProgram.startTime.second, "current program : start time - second"));
                	command_result.add(util.is_equal(expected_cur_length, param.currentProgram.lengthInSeconds, "current program : length in seconds"));
                    command_result.add(util.is_equal(expected_next_title, param.nextProgram.title, "next program : title"));
                	command_result.add(util.is_equal(expected_next_year, param.nextProgram.startTime.year, "next program : start time - year"));
                	command_result.add(util.is_equal(expected_next_month, param.nextProgram.startTime.month, "next program : start time - month"));
                	command_result.add(util.is_equal(expected_next_day, param.nextProgram.startTime.day, "next program : start time - day"));
                	command_result.add(util.is_equal(expected_next_hour, param.nextProgram.startTime.hour, "next program : start time - hour"));
                	command_result.add(util.is_equal(expected_next_minute, param.nextProgram.startTime.minute, "next program : start time - minute"));
                	command_result.add(util.is_equal(expected_next_second, param.nextProgram.startTime.second, "next program : start time - second"));
                	command_result.add(util.is_equal(expected_next_length, param.nextProgram.lengthInSeconds, "next program : length in seconds"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.getProgramInfo(param);
    }
);

HDSTL.Command("@get_preloaded_application_list(result:number, list_length:number, id_0:string, title_0:string, icon_file_path_0:string)",
    function(args) {
        var expected_result = args[1],
        		expected_list_length = args[2],
        		expected_id_0 = args[3],
        		expected_title_0 = args[4],
        		expected_icon_file_path_0 = args[5];

        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    if (param.list) {
                        for (var i = 0; i < param.list.length; i++) {
                            print_msg("list[" + i + "] id = " + param.list[i].appId + ", title = " + param.list[i].title + ", iconFilePath = " + param.list[i].iconFilePath + " <img src='" + param.list[i].iconFilePath + "' height=32 width=32/>");
                        }
                    }
                	var command_result = util.is_equal(expected_list_length, param.list.length, "list length");
                	command_result.add(util.is_equal(expected_id_0, param.list[0].appId, "list[0].id"));
                	command_result.add(util.is_equal(expected_title_0, param.list[0].title, "list[0].title"));
                	command_result.add(util.is_equal(expected_icon_file_path_0, param.list[0].iconFilePath, "list[0].iconFilePath"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.preloadedApplication.getPreloadedApplicationList(param);
    }
);

HDSTL.Command("@launch_preloaded_application(id:string, result:number)",
    function(args) {
        var expected_result = args[2];

        var param = {
        	"id":args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.preloadedApplication.launchPreloadedApplication(param);
    }
);

HDSTL.Command("@launch_preloaded_application_with_parameters(id:string, parameters:string, result:number)",
    function(args) {
        var expected_result = args[3];

        var param = {
            "id":args[1],
            "parameters":args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.preloadedApplication.launchPreloadedApplication(param);
    }
);

HDSTL.Command("@destroy_preloaded_application(id:string, result:number)",
    function(args) {
        var expected_result = args[2];

        var param = {
            "id":args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.preloadedApplication.destroyPreloadedApplication(param);
    }
);

HDSTL.Command("@request_rms(message:string, expected_result:number, response:string, callback_response:string)",
    function(args) {
        var message = args[1],
            expected_result = args[2],
            expected_response = args[3],
            expected_callback_response = args[4],
            event_name = "idcap::rms_response_received",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));
                var command_result = util.is_equal(expected_callback_response, param.response, "callback_response");
                HDSTL.setResult(command_result.result, command_result.fail_reason);
                HDSTL.finish();
            };

        var param = {
            "message":message,
            "onSuccess":HDSTL.checkSuccess2(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_response, param.response, "response");
                    return command_result;
                },
                HDSTL.removeEvent(event_name, event_listener)),
            "onFailure":HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };
        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.rms.requestRms(param);
    }
);

HDSTL.Command("@get_network_information(result,isInternetConnectionAvailable,wired,wifi)",
    function(args) {
        var expected_result = args[1];
/*
                event_name = "idcap::network_event_received",
                event_listener = function eventListener(param) {
                    //HDSTL.removeEvent(event_name, event_listener)();
                    htaf_log(make_htaf_log(event_name, param));
                    //var command_result = util.is_equal("?", param.event, "network event");
                    //HDSTL.setResult(command_result.result, command_result.fail_reason);
                    //HDSTL.finish();
                };
*/
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
/*            HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_network_mode, param.network_mode, "network_mode");
                    command_result.add(util.is_equal(expected_ssid, param.ssid, "ssid"));
                    command_result.add(util.is_equal(expected_eth_speed, param.eth_speed, "eth_speed"));
                    command_result.add(util.is_equal(expected_eth_duplex, param.eth_duplex, "eth_duplex"));
                    command_result.add(util.is_equal(expected_local_network_available, param.local_network_available, "local_network_available"));
                    command_result.add(util.is_equal(expected_internet_available, param.internet_available, "internet_available"));
                    command_result.add(util.is_equal(expected_wifi_mode, param.wifi_mode, "wifi_mode"));
                    command_result.add(util.is_equal(expected_wireless_security_type, param.wireless_security_type, "wireless_security_type"));
                    command_result.add(util.is_equal(expected_wifi_pass_key, param.wifi_pass_key, "wifi_pass_key"));
                    command_result.add(util.is_equal(expected_using_dhcp, param.using_dhcp, "using_dhcp"));
                    command_result.add(util.is_equal(expected_ip_address, param.ip_address, "ip_address"));
                    command_result.add(util.is_equal(expected_subnet_mask, param.subnet_mask, "subnet_mask"));
                    command_result.add(util.is_equal(expected_gateway, param.gateway, "gateway"));
                    command_result.add(util.is_equal(expected_dns1_address, param.dns1_address, "dns1_address"));
                    command_result.add(util.is_equal(expected_dns2_address, param.dns2_address, "dns2_address"));
                    command_result.add(util.is_equal(expected_dns_dhcp, param.dns_dhcp, "dns_dhcp"));
                    command_result.add(util.is_equal(expected_ethernet_plugged, param.ethernet_plugged, "ethernet_plugged"));
                    command_result.add(util.is_equal(expected_wifi_plugged, param.wifi_plugged, "wifi_plugged"));
                    command_result.add(util.is_equal(expected_dhcp_state, param.dhcp_state, "dhcp_state"));
                    return command_result;
                }),*/
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        //HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.network.getNetworkInformation(param);
    }
);

HDSTL.Command("@open_udp_daemon(port:number, expected_result:number)",
    function(args) {
        var port = args[1],
            expected_result = args[2];


        var _params = {
            "parameters" : {
                "port":port
            },
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };
        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request( "idcap://network/udpdaemon/open" , _params);

    }
);

HDSTL.Command("@close_udp_daemon(port:number, expected_result:number)",
    function(args) {
        var port = args[1],
            expected_result = args[2];
        var _params = {
            "parameters" : {
                "port":port
            },
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };
        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request( "idcap://network/udpdaemon/close" , _params);
    }
);

HDSTL.Command("@open_tcp_daemon(port:number, expected_result:number)",
    function(args) {
        var port = args[1],
            expected_result = args[2];
        var _params = {
            "parameters" : {
                "port":port
            },
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };
        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request( "idcap://network/tcpdaemon/open" , _params);
    }
);

HDSTL.Command("@close_tcp_daemon(port:number, expected_result:number)",
    function(args) {
        var port = args[1],
            expected_result = args[2];
        var _params = {
            "parameters" : {
                "port":port
            },
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };
        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request( "idcap://network/tcpdaemon/close" , _params);
    }
);

HDSTL.Command("@send_udp_data(ip:string, port:number, udp_data:string, expected_result:number)",
    function(args) {
        var ip = args[1],
            port = args[2],
            udp_data = args[3],
            expected_result = args[4];

        var _params = {
            "parameters" : {
                "ip":ip,
                "port":port,
                "udpData":udp_data
            },
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };
        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request( "idcap://network/udpdata/send" , _params);
    }
);

HDSTL.Command("@get_picture_property(key:number, expected_result:number, expected_value:number)",
    function(args) {
        var property_key = args[1],
            expected_result = args[2],
            expected_value = args[3];

        var param = {
            "key":property_key,
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_value, param.value, "property_value");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.property.getPictureProperty(param);
    }
);

HDSTL.Command("@set_picture_property(key:number, value:number, expected_result:number)",
    function(args) {
        var property_key = args[1],
            property_value = args[2],
            expected_result = args[3];

        var param = {
            "key":property_key,
            "value":property_value,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.property.setPictureProperty(param);
    }
);

HDSTL.Command("@launch_inband_data_service(inband_data_service_type:number, expected_result:number)",
    function(args) {
        var inband_data_service_type = args[1],
            expected_result = args[2];

        var param = {
            "inband_data_service_type":inband_data_service_type,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.launchInbandDataService(param);
    }
);

HDSTL.Command("@get_ready_inband_data_service(expected_result:number, expected_available_data_service_type:number)",
    function(args) {
        var expected_result = args[1],
            expected_available_data_service_type = args[2];

        htaf_log(make_htaf_log("[Test Args]", args));

        hcap.channel.getReadyInbandDataService({
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_available_data_service_type, param.availableDataServiceType, "availableDataServiceType");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        });
    }
);

HDSTL.Command("@request_checkout(expected_result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.checkout.requestCheckout(param);
    }
);

HDSTL.Command("@take_checkout_snapshot(expected_result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.checkout.takeCheckoutSnapshot(param);
    }
);

HDSTL.Command("@cruise_activate_rcu_staff_mode(expected_result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.cruise.activateRcuStaffMode(param);
    }
);

HDSTL.Command("@cruise_activate_rcu_tagging_mode(expected_result:number)",
	    function(args) {
	        var expected_result = args[1];
	        var param = {
	            "onSuccess": HDSTL.checkSuccess(expected_result, null),
	            "onFailure": HDSTL.checkFailure(expected_result)
	        };

	        htaf_log(make_htaf_log("[Test Args]", args));
	        hcap.cruise.activateRcuTaggingMode(param);
	    }
	);

HDSTL.Command("@cruise_get_battery_level(expected_result:number, expected_level:number)",
    function(args) {
        var expected_result = args[1], expected_level = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_level, param.level, "level");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.cruise.getRcuBatteryLevel(param);
    }
);

HDSTL.Command("@cruise_get_stream_mode(expected_result:number, expected_stream_mode:string)",
    function(args) {
        var expected_result = args[1], expected_stream_mode = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_stream_mode, param.mode, "stream_mode");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.cruise.getStreamMode(param);
    }
);

HDSTL.Command("@cruise_register_cradle(expected_result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.cruise.registerCradle(param);
    }
);

HDSTL.Command("@cruise_set_stream_mode(stream_mode:string, expected_result:number)",
    function(args) {
        var expected_result = args[2],
            event_name = "cruise_stream_mode_changed",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));
                HDSTL.setResult(true, event_name + " event received");
                HDSTL.finish();
            };

        var param = {
            "mode": args[1],
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };

        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.cruise.setStreamMode(param);
    }
);

HDSTL.Command("@cruise_unpair_rcu(expected_result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.cruise.unpairRcu(param);
    }
);

HDSTL.Command("@is_pointer_on(expected_result:number, expected_is_on:boolean)",
    function(args) {
        var expected_result = args[1], expected_is_on = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_is_on, param.isOn, "is_on");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.mouse.isPointerOn(param);
    }
);

HDSTL.Command("@set_pointer_on(is_on:boolean, expected_result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "isOn": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.mouse.setPointerOn(param);
    }
);

HDSTL.Command("@set_pointer_size(size:number, expected_result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "size": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.mouse.setPointerSize(param);
    }
);

HDSTL.Command("@get_pointer_position(expected_result:number, expected_x:number, expected_y:number)",
    function(args) {
        var expected_result = args[1],
            expected_x = args[2],
            expected_y = args[3];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_x, param.x, "x");
                    command_result.add(util.is_equal(expected_y, param.y, "y"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.mouse.getPointerPosition(param);
    }
);

HDSTL.Command("@set_pointer_position(x:number, y:number, expected_result:number)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "x": args[1],
            "y": args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.mouse.setPointerPosition(param);
    }
);

HDSTL.Command("@click_pointer(expected_result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.mouse.clickPointer(param);
    }
);

HDSTL.Command("@get_soft_ap_info(expected_result:number, expected_ip:string, expected_mac:string, expected_connected_device_number:number)",
    function(args) {
        var expected_result = args[1],
                expected_ip = args[2],
                expected_mac = args[3],
                expected_connected_device_number = args[4];

        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_ip, param.ip, "AP_IP");
                    command_result.add(util.is_equal(expected_mac, param.mac, "AP_MAC"));
                    command_result.add(util.is_equal(expected_connected_device_number, param.connectedDeviceNumber, "AP_connected_device_number"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.network.getSoftApInfo(param);
    }
);

HDSTL.Command("@get_cpu_usage(expected_result:number, expected_percentage:number)",
    function(args) {
        var expected_result = args[1], expected_percentage = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_percentage, param.percentage, "CPU_percentage");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.getCpuUsage(param);
    }
);

HDSTL.Command("@get_memory_usage(expected_result:number, expected_percentage:number)",
    function(args) {
        var expected_result = args[1], expected_percentage = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_percentage, param.percentage, "MEMORY_percentage");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.getMemoryUsage(param);
    }
);

HDSTL.Command("@request_focus(expected_result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.requestFocus(param);
    }
);

HDSTL.Command("@get_focused(expected_result:number, expected_focused:boolean)",
    function(args) {
        var expected_result = args[1], expected_focused = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_focused, param.focused, "HCAP gets focused");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.getFocused(param);
    }
);

HDSTL.Command("@request_cloning(xml:string, expected_result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "xml": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        //htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.requestCloning(param);
    }
);

HDSTL.Command("@launch_hcap_html_application(expected_result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.launchHcapHtmlApplication(param);
    }
);

HDSTL.Command("@get_usb_storage_list(expected_result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": function(s) {
            	HDSTL.checkSuccess(expected_result, null)();
            	if (s.list) {
	            	htaf_log("list length = " + s.list.length);
	            	for (var i = 0; i < s.list.length; i++) {
	            		htaf_log("[" + i + "] " + s.list[i].name + " : " + s.list[i].displayName + " : " + s.list[i].mountPoint + " : " + s.list[i].status + " : " + s.list[i].filesystemStatus + " : " + s.list[i].totalSize + " : " + s.list[i].freeSize);
	            	}
            	} else {
	            	htaf_log("list is null");
            	}
            },
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.file.getUsbStorageList(param);
    }
);

HDSTL.Command("@get_usb_storage_file_list(path:string,expected_result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "path": args[1],
            "onSuccess": function(s) {
                HDSTL.checkSuccess(expected_result, null)();
            },
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.file.getUsbStorageFileList(param);
    }
);

HDSTL.Command("@download_file_to_usb(action,source,destination,ticket,ftpOption,httpOption,expected_result)",
    function(args) {
        var expected_result = args[7];
        var param = {
            "action": args[1],
            "source": args[2],
            "destination": args[3],
            "ticket": args[4],
            "ftpOption": args[5],
            "httpOption": args[6],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.file.downloadFileToUsb(param);
    }
);

HDSTL.Command("@delete_usb_file(path:string, expected_result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "path": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.file.deleteUsbFile(param);
    }
);
HDSTL.Command("@delete_file(path:string, recursive ,expected_result:number)",
    function(args) {
        var expected_result = args[3];
        var parameters = {
            "path":args[1],
            "recursive":args[2],
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://storage/file/remove",param);
    }
);


HDSTL.Command("@rs232c_get_configuration(expected_result:number,expected_port,expected_baudrate,expected_bit,expected_parity,expected_stop,expected_flow,expected_timeout)",
    function(args) {
        var expected_result = args[1];
        var expected_port = args[2];
        var expected_baudrate = args[3];
        var expected_bit = args[4];
        var expected_parity = args[5];
        var expected_stop = args[6];
        var expected_flow = args[7];
        var expected_timeout = args[8];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_port, param.port, "port");
                    command_result.add(util.is_equal(expected_baudrate, param.baudRate, "baudRate"));
                    command_result.add(util.is_equal(expected_bit, param.dataBit, "dataBit"));
                    command_result.add(util.is_equal(expected_parity, param.parity, "parity"));
                    command_result.add(util.is_equal(expected_stop, param.stopBit, "stopBit"));
                    command_result.add(util.is_equal(expected_flow, param.flowControl, "flowControl"));
                    command_result.add(util.is_equal(expected_timeout, param.rxTimeoutInMs, "rxTimeoutInMs"));

                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.rs232c.getConfiguration(param);
    }
);

HDSTL.Command("@rs232c_set_configuration(port:number,baud_rate:number,data_bit:number,parity:number,stop_bit:number,flow_control:number,rx_timeout_in_ms:number,reserved:number,expected_result:number)",
    function(args) {
        var expected_result = args[9];
        var param = {
            "port":args[1],
            "baudRate":args[2],
            "dataBit":args[3],
            "parity":args[4],
            "stopBit":args[5],
            "flowControl":args[6],
            "rxTimeoutInMs":args[7],
            "reserved":args[8],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.rs232c.setConfiguration(param);
    }
);


HDSTL.Command("@rs232c_send_data(data:string,data_length:number,expected_result:number)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "data":args[1],
            "dataLength":args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.rs232c.sendData(param);
    }
);

HDSTL.Command("@rs232c_set_teaching_data(data:string,data_length:number,expected_result:number)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "data":args[1],
            "dataLength":args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.rs232c.setStartupData(param);
    }
);

HDSTL.Command("@rs232c_clear_teaching_data(expected_result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.rs232c.clearStartupData(param);
    }
);

HDSTL.Command("@request_channel_map_item(channel_type:number,frequency:number,program_number:number,satellite_id:number,polarization:number,plp_id:number,physical_number:number,symbol_rate:number,rf_broadcast_type:number,is_ipv4:boolean,ip:string,port:number,source_address:string,ip_broadcast_type:number,expected_result:number)",
    function(args) {
        var expected_result = args[14];
        var param = {
            "channelType":args[1],
            "frequency":args[2],
            "programNumber":args[3],
            "satelliteId":args[4],
            "polarization":args[5],
            "plpId":args[6],
            "physicalNumber":args[7],
            "symbolRate":args[8],
            "rfBroadcastType":args[9],
            "isIpv4":args[10],
            "ip":args[11],
            "port":args[12],
            "sourceAddress":args[13],
            "ipBroadcastType":args[14],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.requestChannelMapItem(param);
    }
);

HDSTL.Command("@add_channel_map_item(id:string,display_channel_number:string,radio_channel:boolean,channel_type:number,frequency:number,program_number:number,physical_number:number,major_number:number,minor_number:number,satellite_id:number,polarization:number,plp_id:number,rf_broadcast_type:number,is_ipv4:boolean,ip:string,port:number,source_address:string,ip_broadcast_type:number,symbol_rate:number,pcr_pid:number,video_pid:number,video_stream_type:number,audio_pid:number,audio_stream_type:number,pmt_pid:number,proidiom_pid:number,logical_channel_number:number,hidden:boolean,display_logo_index:number,display_channel_name:string,session_id:string,expected_result:number)",
    function(args) {
        var expected_result = args[32];
        var param = {
            "systemItem": {
                "id":args[1],
                "displayChannelNumber":args[2],
                "radioChannel":args[3],
                "channelType":args[4],
                "frequency":args[5],
                "programNumber":args[6],
                "physicalNumber":args[7],
                "majorNumber":args[8],
                "minorNumber":args[9],
                "satelliteId":args[10],
                "polarization":args[11],
                "plpId":args[12],
                "rfBroadcastType":args[13],
                "isIpv4":args[14],
                "ip":args[15],
                "port":args[16],
                "sourceAddress":args[17],
                "ipBroadcastType":args[18],
                "symbolRate":args[19],
                "pcrPid":args[20],
                "videoPid":args[21],
                "videoStreamType":args[22],
                "audioPid":args[23],
                "audioStreamType":args[24],
                "pmtPid":args[25],
                "proidiomPid":args[26],
            },
            "userItem": {
                "logicalChannelNumber":args[27],
                "hidden":args[28],
                "displayLogoIndex":args[29],
                "displayChannelName":args[30],
                "sessionId":args[31],
            },
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.addChannelMapItem(param);
    }
);

HDSTL.Command("@remove_channel_map_item(id:string,expected_result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "id":args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.removeChannelMapItem(param);
    }
);

HDSTL.Command("@get_channel_map_item_count(expected_result:number, expected_count:number)",
    function(args) {
        var expected_result = args[1], expected_count = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_count, param.count, "count");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.getChannelMapItemCount(param);
    }
);

HDSTL.Command("@get_channel_map_item_by_index(index:number,expected_result:number,id:string,display_channel_number:string,radio_channel:boolean,channel_type:number,frequency:number,program_number:number,physical_number:number,major_number:number,minor_number:number,satellite_id:number,polarization:number,plp_id:number,rf_broadcast_type:number,is_ipv4:boolean,ip:string,port:number,source_address:string,ip_broadcast_type:number,symbol_rate:number,pcr_pid:number,video_pid:number,video_stream_type:number,audio_pid:number,audio_stream_type:number,pmt_pid:number,proidiom_pid:number,logical_channel_number:number,hidden:boolean,display_logo_index:number,display_channel_name:string,session_id:string)",
    function(args) {
        var expected_result = args[2],
            expected_id = args[3],
            expected_display_channel_number = args[4],
            expected_radio_channel = args[5],
            expected_channel_type = args[6],
            expected_frequency = args[7],
            expected_program_number = args[8],
            expected_physical_number = args[9],
            expected_major_number = args[10],
            expected_minor_number = args[11],
            expected_satellite_id = args[12],
            expected_polarization = args[13],
            expected_plp_id = args[14],
            expected_rf_broadcast_type = args[15],
            expected_is_ipv4 = args[16],
            expected_ip = args[17],
            expected_port = args[18],
            expected_source_address = args[19],
            expected_ip_broadcast_type = args[20],
            expected_symbol_rate = args[21],
            expected_pcr_pid = args[22],
            expected_video_pid = args[23],
            expected_video_stream_type = args[24],
            expected_audio_pid = args[25],
            expected_audio_stream_type = args[26],
            expected_pmt_pid = args[27],
            expected_proidiom_pid = args[28],
            expected_logical_channel_number = args[29],
            expected_hidden = args[30],
            expected_display_logo_index = args[31],
            expected_display_channel_name = args[32],
            expected_session_id = args[33];

        var param = {
            "index":args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    htaf_log("id = " + param.systemItem.id + ", display channel number = " + param.systemItem.displayChannelNumber + ", display channel name = " + param.userItem.displayChannelName);
                    var command_result = util.is_equal(expected_id, param.id, "id");
                    command_result.add(util.is_equal(expected_display_channel_number, param.displayChannelNumber, "displayChannelNumber"));
                    command_result.add(util.is_equal(expected_radio_channel, param.radioChannel, "radioChannel"));
                    command_result.add(util.is_equal(expected_channel_type, param.channelType, "channelType"));
                    command_result.add(util.is_equal(expected_frequency, param.frequency, "frequency"));
                    command_result.add(util.is_equal(expected_program_number, param.programNumber, "programNumber"));
                    command_result.add(util.is_equal(expected_physical_number, param.physicalNumber, "physicalNumber"));
                    command_result.add(util.is_equal(expected_major_number, param.majorNumber, "majorNumber"));
                    command_result.add(util.is_equal(expected_minor_number, param.minorNumber, "minorNumber"));
                    command_result.add(util.is_equal(expected_satellite_id, param.satelliteId, "satelliteId"));
                    command_result.add(util.is_equal(expected_polarization, param.polarization, "polarization"));
                    command_result.add(util.is_equal(expected_plp_id, param.plpId, "plpId"));
                    command_result.add(util.is_equal(expected_rf_broadcast_type, param.rfBroadCastType, "rfBroadCastType"));
                    command_result.add(util.is_equal(expected_is_ipv4, param.isIpv4, "isIpv4"));
                    command_result.add(util.is_equal(expected_ip, param.ip, "ip"));
                    command_result.add(util.is_equal(expected_port, param.port, "port"));
                    command_result.add(util.is_equal(expected_source_address, param.sourceAddress, "sourceAddress"));
                    command_result.add(util.is_equal(expected_ip_broadcast_type, param.ipBroadcastType, "ipBroadcastType"));
                    command_result.add(util.is_equal(expected_symbol_rate, param.symbolRate, "symbolRate"));
                    command_result.add(util.is_equal(expected_pcr_pid, param.pcrPid, "pcrPid"));
                    command_result.add(util.is_equal(expected_video_pid, param.videoPid, "videoPid"));
                    command_result.add(util.is_equal(expected_video_stream_type, param.videoStreamType, "videoStreamType"));
                    command_result.add(util.is_equal(expected_audio_pid, param.audioPid, "audioPid"));
                    command_result.add(util.is_equal(expected_audio_stream_type, param.audioStreamType, "audioStreamType"));
                    command_result.add(util.is_equal(expected_pmt_pid, param.pmtPid, "pmtPid"));
                    command_result.add(util.is_equal(expected_proidiom_pid, param.proidiomPid, "proidiomPid"));
                    command_result.add(util.is_equal(expected_logical_channel_number, param.logicalChannelNumber, "logicalChannelNumber"));
                    command_result.add(util.is_equal(expected_hidden, param.hidden, "hidden"));
                    command_result.add(util.is_equal(expected_display_logo_index, param.displayLogoIndex, "displayLogoIndex"));
                    command_result.add(util.is_equal(expected_display_channel_name, param.displayChannelName, "displayChannelName"));
                    command_result.add(util.is_equal(expected_session_id, param.sessionId, "sessionId"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.getChannelMapItemByIndex(param);
    }
);

HDSTL.Command("@get_channel_map_item_by_channel_id(channel_id:string,expected_result:number,id:string,display_channel_number:string,radio_channel:boolean,channel_type:number,frequency:number,program_number:number,physical_number:number,major_number:number,minor_number:number,satellite_id:number,polarization:number,plp_id:number,rf_broadcast_type:number,is_ipv4:boolean,ip:string,port:number,source_address:string,ip_broadcast_type:number,symbol_rate:number,pcr_pid:number,video_pid:number,video_stream_type:number,audio_pid:number,audio_stream_type:number,pmt_pid:number,proidiom_pid:number,logical_channel_number:number,hidden:boolean,display_logo_index:number,display_channel_name:string,session_id:string)",
    function(args) {
        var expected_result = args[2],
            expected_id = args[3],
            expected_display_channel_number = args[4],
            expected_radio_channel = args[5],
            expected_channel_type = args[6],
            expected_frequency = args[7],
            expected_program_number = args[8],
            expected_physical_number = args[9],
            expected_major_number = args[10],
            expected_minor_number = args[11],
            expected_satellite_id = args[12],
            expected_polarization = args[13],
            expected_plp_id = args[14],
            expected_rf_broadcast_type = args[15],
            expected_is_ipv4 = args[16],
            expected_ip = args[17],
            expected_port = args[18],
            expected_source_address = args[19],
            expected_ip_broadcast_type = args[20],
            expected_symbol_rate = args[21],
            expected_pcr_pid = args[22],
            expected_video_pid = args[23],
            expected_video_stream_type = args[24],
            expected_audio_pid = args[25],
            expected_audio_stream_type = args[26],
            expected_pmt_pid = args[27],
            expected_proidiom_pid = args[28],
            expected_logical_channel_number = args[29],
            expected_hidden = args[30],
            expected_display_logo_index = args[31],
            expected_display_channel_name = args[32],
            expected_session_id = args[33];

        var param = {
            "id":args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    htaf_log("id = " + param.systemItem.id + ", display channel number = " + param.systemItem.displayChannelNumber + ", display channel name = " + param.userItem.displayChannelName);
                    var command_result = util.is_equal(expected_id, param.systemItem.id, "id");
                    command_result.add(util.is_equal(expected_display_channel_number, param.systemItem.displayChannelNumber, "displayChannelNumber"));
                    command_result.add(util.is_equal(expected_radio_channel, param.systemItem.radioChannel, "radioChannel"));
                    command_result.add(util.is_equal(expected_channel_type, param.systemItem.channelType, "channelType"));
                    command_result.add(util.is_equal(expected_frequency, param.systemItem.frequency, "frequency"));
                    command_result.add(util.is_equal(expected_program_number, param.systemItem.programNumber, "programNumber"));
                    command_result.add(util.is_equal(expected_physical_number, param.systemItem.physicalNumber, "physicalNumber"));
                    command_result.add(util.is_equal(expected_major_number, param.systemItem.majorNumber, "majorNumber"));
                    command_result.add(util.is_equal(expected_minor_number, param.systemItem.minorNumber, "minorNumber"));
                    command_result.add(util.is_equal(expected_satellite_id, param.systemItem.satelliteId, "satelliteId"));
                    command_result.add(util.is_equal(expected_polarization, param.systemItem.polarization, "polarization"));
                    command_result.add(util.is_equal(expected_plp_id, param.systemItem.plpId, "plpId"));
                    command_result.add(util.is_equal(expected_rf_broadcast_type, param.systemItem.rfBroadCastType, "rfBroadCastType"));
                    command_result.add(util.is_equal(expected_is_ipv4, param.systemItem.isIpv4, "isIpv4"));
                    command_result.add(util.is_equal(expected_ip, param.systemItem.ip, "ip"));
                    command_result.add(util.is_equal(expected_port, param.systemItem.port, "port"));
                    command_result.add(util.is_equal(expected_source_address, param.systemItem.sourceAddress, "sourceAddress"));
                    command_result.add(util.is_equal(expected_ip_broadcast_type, param.systemItem.ipBroadcastType, "ipBroadcastType"));
                    command_result.add(util.is_equal(expected_symbol_rate, param.systemItem.symbolRate, "symbolRate"));
                    command_result.add(util.is_equal(expected_pcr_pid, param.systemItem.pcrPid, "pcrPid"));
                    command_result.add(util.is_equal(expected_video_pid, param.systemItem.videoPid, "videoPid"));
                    command_result.add(util.is_equal(expected_video_stream_type, param.systemItem.videoStreamType, "videoStreamType"));
                    command_result.add(util.is_equal(expected_audio_pid, param.systemItem.audioPid, "audioPid"));
                    command_result.add(util.is_equal(expected_audio_stream_type, param.systemItem.audioStreamType, "audioStreamType"));
                    command_result.add(util.is_equal(expected_pmt_pid, param.systemItem.pmtPid, "pmtPid"));
                    command_result.add(util.is_equal(expected_proidiom_pid, param.systemItem.proidiomPid, "proidiomPid"));
                    command_result.add(util.is_equal(expected_logical_channel_number, param.userItem.logicalChannelNumber, "logicalChannelNumber"));
                    command_result.add(util.is_equal(expected_hidden, param.userItem.hidden, "hidden"));
                    command_result.add(util.is_equal(expected_display_logo_index, param.userItem.displayLogoIndex, "displayLogoIndex"));
                    command_result.add(util.is_equal(expected_display_channel_name, param.userItem.displayChannelName, "displayChannelName"));
                    command_result.add(util.is_equal(expected_session_id, param.userItem.sessionId, "sessionId"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.getChannelMapItemByChannelId(param);
    }
);

HDSTL.Command("@clear_channel_map(expected_result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.channel.clearChannelMap(param);
    }
);

HDSTL.Command("@get_locale_list(result:number, specifier:string, language:string, country:string)",
    function(args) {
        var expected_result = args[1],
        		expected_specifier = args[2],
        		expected_language = args[3],
        		expected_country = args[4];

        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
            		if (param.list.length > 0) {
            			htaf_log("list[0] : specifier = " + param.list[0].specifier + ", language = " + param.list[0].language + ", country = " + param.list[0].country);
            		}
                	var command_result = util.is_equal(expected_specifier, param.list[0].specifier, "list[0].specifier");
                	command_result.add(util.is_equal(expected_language, param.list[0].language, "list[0].language"));
                	command_result.add(util.is_equal(expected_country, param.list[0].country, "list[0].country"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.getLocaleList(param);
    }
);

HDSTL.Command("@get_locale(result:number, specifier:string, language:string, country:string)",
    function(args) {
        var expected_result = args[1],
        		expected_specifier = args[2],
        		expected_language = args[3],
        		expected_country = args[4];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_specifier, param.specifier, "specifier");
                	command_result.add(util.is_equal(expected_language, param.language, "language"));
                	command_result.add(util.is_equal(expected_country, param.country, "country"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.getLocale(param);
    }
);

HDSTL.Command("@request_locale_change(specifier:string, result:number, event_specifier:string, event_result:number)",
    function(args) {
		var command_result = true;
        var expected_result = args[2],
        		event_specifier = args[3],
        		event_result = args[4],
	            event_name = "idcap::locale_changed",
	            event_listener = function eventListener(param) {
	                HDSTL.removeEvent(event_name, event_listener)();
	                htaf_log(make_htaf_log(event_name, param));
	                command_result.add(util.is_equal(event_specifier, param.specifier, "specifier"));
                	command_result.add(util.is_equal(event_result, param.result, "change_result"));
	                HDSTL.setResult(command_result.result, command_result.fail_reason);
	                HDSTL.finish();
	            };
        var param = {
            "specifier": args[1],
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };

        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.requestLocaleChange(param);
    }
);

HDSTL.Command("@set_network_device(wired,wifi,result:number)",
    function(args) {
        var expected_result = args[8];
        var param = null;
        if (args[2] === true) {
            // DHCP on
            param = {
                "index": args[1],
                "dhcp": true,
                "onSuccess": HDSTL.checkSuccess(expected_result, null),
                "onFailure": HDSTL.checkFailure(expected_result)
            };
        } else {
            // DHCP off
            param = {
                "index": args[1],
                "dhcp": false,
                "ip": args[3],
                "gateway": args[4],
                "netmask": args[5],
                "primaryDns": args[6],
                "secondaryDns": args[7],
                "onSuccess": HDSTL.checkSuccess(expected_result, null),
                "onFailure": HDSTL.checkFailure(expected_result)
            };
        }

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.network.setNetworkDevice(param);
    }
);

HDSTL.Command("@get_procentric_server(result:number, mode:string, media:string, rf_type:string, rf_data_channel_number:number, rf_frequency:number, ip_address_type:string, ip:string, domain_name:string, ip_port:number)",
    function(args) {
        var expected_result = args[1],
                expected_mode = args[2],
                expected_media = args[3],
                expected_rf_type = args[4],
                expected_rf_data_channel_number = args[5],
                expected_rf_frequency = args[6],
                expected_ip_address_type = args[7],
                expected_ip = args[8],
                expected_ip_domain_name = args[9],
                expected_ip_port = args[10];

        htaf_log(make_htaf_log("[Test Args]", args));

        hcap.system.getProcentricServer({
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_mode, param.mode, "mode");
                    command_result.add(util.is_equal(expected_media, param.media, "media"));
                    if (param.media === "rf") {
                        command_result.add(util.is_equal(expected_rf_type, param.rfServer.type, "rf_type"));
                        command_result.add(util.is_equal(expected_rf_data_channel_number, param.rfServer.dataChannelNumber, "rf_data_channel_number"));
                        command_result.add(util.is_equal(expected_rf_frequency, param.rfServer.frequency, "rf_frequency"));
                    } else if (param.media === "ip") {
                        command_result.add(util.is_equal(expected_ip_address_type, param.ipServer.type, "ip_address_type"));
                        command_result.add(util.is_equal(expected_ip, param.ipServer.ip, "ip"));
                        command_result.add(util.is_equal(expected_ip_domain_name, param.ipServer.domainName, "ip_domain_name"));
                        command_result.add(util.is_equal(expected_ip_port, param.ipServer.port, "ip_port"));
                    }
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        });
    }
);

HDSTL.Command("@set_procentric_server(mode:string, media:string, rf_type:string, rf_data_channel_number:number, rf_frequency:number, ip_address_type:string, ip:string, ip_domain_name:string, ip_port:number, result:number)",
    function(args) {
        var expected_result = args[10],
                param = null;

        htaf_log(make_htaf_log("[Test Args]", args));

        if (args[2] === "rf") {
            param = {
                "mode": args[1],
                "media": args[2],
                "rfServer": {
                    "type": args[3],
                    "dataChannelNumber": args[4],
                    "frequency": args[5]
                },
                "onSuccess": HDSTL.checkSuccess(expected_result, null),
                "onFailure": HDSTL.checkFailure(expected_result)
            };
            hcap.system.setProcentricServer(param);
        } else if (args[2] === "ip") {
            param = {
                "mode": args[1],
                "media": args[2],
                "ipServer": {
                    "type": args[6],
                    "ip":args[7],
                    "domainName":args[8],
                    "port": args[9]
                },
                "onSuccess": HDSTL.checkSuccess(expected_result, null),
                "onFailure": HDSTL.checkFailure(expected_result)
            };
            hcap.system.setProcentricServer(param);
        } else {
            HDSTL.setResult(false, "Unknown media type : " + args[2]);
            HDSTL.finish();
        }
    }
);

HDSTL.Command("@get_soft_ap(result:number, ip:string, mac:string, connected_device_number:number, channel:number, signal_strength:number, vlan_id:number, vlan_ip:string, vlan_subnet:string, vlan_gateway:string)",
    function(args) {
        var expected_result = args[1],
                expected_ip = args[2],
                expected_mac = args[3],
                expected_connected_device_number = args[4],
                expected_channel = args[5],
                expected_signal_strength = args[6],
                expected_vlan_id = args[7],
                expected_vlan_ip = args[8],
                expected_vlan_subnet = args[9],
                expected_vlan_gateway = args[10];

        htaf_log(make_htaf_log("[Test Args]", args));

        var _params = {
            "parameters" : {},
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_ip, param.ip, "ip");
                    command_result.add(util.is_equal(expected_mac, param.mac, "mac"));
                    command_result.add(util.is_equal(expected_connected_device_number, param.connectedDeviceNumber, "connected_device_number"));
                    command_result.add(util.is_equal(expected_channel, param.channel, "channel"));
                    command_result.add(util.is_equal(expected_signal_strength, param.signalStrength, "signal_strength"));
                    command_result.add(util.is_equal(expected_vlan_id, param.vlanId, "vlan_id"));
                    command_result.add(util.is_equal(expected_vlan_ip, param.vlanIp, "vlan_ip"));
                    command_result.add(util.is_equal(expected_vlan_subnet, param.vlanSubnet, "vlan_subnet"));
                    command_result.add(util.is_equal(expected_vlan_gateway, param.vlanGateway, "vlan_gateway"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        idcap.request( "idcap://network/softap/advanced/get" , _params);
    }
);

HDSTL.Command("@set_soft_ap(channel:number, signal_strength:number, vlan_id:number, vlan_ip:string, vlan_subnet:string, vlan_gateway:string, mode:string, security_type:string, radius_server_ip:string, radius_server_ip:string, radius_server_key:string, result:number)",
    // function(args) {
    //     var expected_result = args[12];
    //     // var param = {
    //     //     "channel": args[1],
    //     //     "signalStrength": args[2],
    //     //     "vlanId": args[3],
    //     //     "vlanIp": args[4],
    //     //     "vlanSubnet": args[5],
    //     //     "vlanGateway": args[6],
    //     //     "mode": args[7],
    //     //     "securityType": args[8],
    //     //     "radiusServerIp": args[9],
    //     //     "radiusServerPort": args[10],
    //     //     "radiusServerKey": args[11],
    //     //     "onSuccess": HDSTL.checkSuccess(expected_result, null),
    //     //     "onFailure": HDSTL.checkFailure(expected_result)
    //     // };

    //     htaf_log(make_htaf_log("[Test Args]", args));
    //     // hcap.network.setSoftAP(param);
    //     idcap.request( "idcap://network/softap/advanced/set" , {
    //         "parameters": {
    //             "channel" : args[1],
    //             "signalStrength" : args[2],
    //             "vlanId" : args[3],
    //             "vlanIp" : args[4],
    //             "vlanSubnet" : args[5],
    //             "vlanGateway" : args[6],
    //         },
    //         "onSuccess": function () {
    //             console.log("onSuccess");
    //         },
    //         "onFailure": function (err) {
    //             console.log("onFailure : errorMessage = " + err.errorMessage);
    //         }
    //     });
    // }

    function(args) {
        var expected_result = args[12];
        var parameters = {
            "channel" : args[1],
            "signalStrength" : args[2],
            "vlanId" : args[3],
            "vlanIp" : args[4],
            "vlanSubnet" : args[5],
            "vlanGateway" : args[6],
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://network/softap/advanced/set",param);
    }

);

HDSTL.Command("@set_3d_on_by_pattern(user_3d_pattern:string, user_pattern_mode:boolean, result:number)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "user3dPattern": args[1],
            "userPatternMode": args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.control3D.set3dOnByPattern(param);
    }
);

HDSTL.Command("@set_3d_on(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.control3D.set3dOn(param);
    }
);

HDSTL.Command("@set_3d_off(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.control3D.set3dOff(param);
    }
);

HDSTL.Command("@set_3d_enable_on_signal(enable_2d_to_3d:boolean, enable_3d:boolean, result:number)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "enable2dTo3d": args[1],
            "enable3d": args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.control3D.set3dEnableOnSignal(param);
    }
);

HDSTL.Command("@get_3d_status(result:number, _3d_on:boolean, _3d_pattern:string)",
    function(args) {
        var expected_result = args[1],
                expected_3d_on = args[2],
                expected_3d_pattern = args[3];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_3d_on, param._3dOn, "_3dOn");
                    command_result.add(util.is_equal(expected_3d_pattern, param._3dPattern, "_3dPattern"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.control3D.get3dStatus(param);
    }
);

HDSTL.Command("@get_3d_pattern_list(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    for (var i = 0; i < param.list.length; i++) {
                        print_msg("list[" + i + "] = " + param.list[i]);
                    }
                    var command_result = util.is_equal(true, true, "true");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.control3D.get3dPatternList(param);
    }
);

HDSTL.Command("@get_3d_enable_on_signal(result:number, enable_2d_to_3d:boolean, enable_3d:boolean)",
    function(args) {
        var expected_result = args[1],
                expected_enable_2d_to_3d = args[2],
                expected_enable_3d = args[3];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_enable_2d_to_3d, param.enable2dTo3d, "enable2dTo3d");
                    command_result.add(util.is_equal(expected_enable_3d, param.enable3d, "enable3d"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.control3D.get3dEnableOnSignal(param);
    }
);

HDSTL.Command("@disable_3d_status_change_on_signal(disable_change:boolean, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "disableChange":args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.control3D.disable3dStatusChangeOnSignal(param);
    }
);

HDSTL.Command("@reset_3d_status(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.control3D.reset3dStatus(param);
    }
);

HDSTL.Command("@bt_audio_change_to_tv_speaker(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.audio.changeToTvSpeaker(param);
    }
);

HDSTL.Command("@bt_audio_enable_sound_out_redirect(enable:boolean, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "enable": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.audio.enableSoundOutRedirect(param);
    }
);

HDSTL.Command("@bt_audio_disconnect_headset_reconnection(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.audio.disconnectHeadsetReconnection(param);
    }
);

HDSTL.Command("@bt_audio_pause(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.audio.pause(param);
    }
);

HDSTL.Command("@bt_audio_play(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.audio.play(param);
    }
);

HDSTL.Command("@bt_audio_forward(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.audio.forward(param);
    }
);

HDSTL.Command("@bt_audio_backward(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.audio.backward(param);
    }
);

HDSTL.Command("@bt_audio_retry_connection(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.audio.reconnectDevice(param);
    }
);

HDSTL.Command("@bt_audio_retry_discovery(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.audio.retryDiscovery(param);
    }
);

HDSTL.Command("@bt_audio_set_volume(volume:number, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "volume": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.audio.setVolume(param);
    }
);

HDSTL.Command("@bt_audio_stop(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.audio.stop(param);
    }
);

HDSTL.Command("@bt_audio_yes_reconnection(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.audio.autoStartStreaming(param);
    }
);

HDSTL.Command("@bt_gap_request_find_devices(device_class:number, scan_time:number, result:number)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "class": args[1],
            "scanTime": args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.gap.requestFindDevices(param);
    }
);

HDSTL.Command("@bt_gap_get_local_device_version(result:number, fw_version:string, device_class:string, mac:string, bsa_version:string, name:string)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(args[2], param.fwVersion, "fw_version");
                    command_result.add(util.is_equal(args[3], param.class, "class"));
                    command_result.add(util.is_equal(args[4], param.address, "mac"));
                    command_result.add(util.is_equal(args[5], param.bsaVersion, "bsa_version"));
                    command_result.add(util.is_equal(args[6], param.name, "name"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.gap.getLocalBluetoothModule(param);
    }
);

HDSTL.Command("@bt_gap_get_trusted_devices(profile:string, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "service": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    for (var i = 0; i < param.list.length; i++) {
                        print_msg("list[" + i + "] : class = " + param.list[i].class + ", address = " + param.list[i].address + ", state = " + param.list[i].state + ", name = " + param.list[i].name);
                    }
                    var command_result = util.is_equal(true, true, "true");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.gap.getTrustedDevices(param);
    }
);

HDSTL.Command("@bt_gap_is_radio_on(result:number, radio_on:boolean)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(args[2], param.isRadioOn, "radio_on");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.gap.isRadioOn(param);
    }
);

HDSTL.Command("@bt_gap_is_visible(result:number, is_visible:boolean)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(args[2], param.isVisible, "is_visible");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.gap.isVisible(param);
    }
);

HDSTL.Command("@bt_gap_remove_trusted_device(mac:string, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "address": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.removeTrustedDevice(param);
    }
);

HDSTL.Command("@bt_gap_send_vendor_command(userCommand:number, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "userCommand": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.gap.sendVendorCommand(param);
    }
);

HDSTL.Command("@bt_gap_set_scan_state(visible:boolean, connectable:boolean, result:number)",
    function(args) {
        var expected_result = args[4];
        var param = {
            "parameters" : {
                "visible": args[1],
                "connectable": args[2],
                "displayName" : args[3]
            },
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://network/bluetooth/scanstate/set" , param);
    }
);

HDSTL.Command("@bt_gap_set_lg_configuration(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.gap.setLGConfiguration(param);
    }
);

HDSTL.Command("@bt_service_request_connect(profile:string, mac:string, result:number)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "service": args[1],
            "address": args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.service.requestConnect(param);
    }
);

HDSTL.Command("@bt_service_disconnect(profile:string, mac:string,result:number)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "parameters" : {},
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://network/bluetooth/disconnect",param);
    }
);

HDSTL.Command("@bt_service_get_state(profile:string, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "service": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    for (var i = 0; i < param.list.length; i++) {
                        print_msg("list[" + i + "] : class = " + param.list[i].class + ", address = " + param.list[i].address + ", state = " + param.list[i].state + ", name = " + param.list[i].name);
                    }
                    var command_result = util.is_equal(true, true, "true");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.service.getState(param);
    }
);

HDSTL.Command("@bt_service_start(profile:string, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "service": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.service.start(param);
    }
);

HDSTL.Command("@bt_service_stop(profile:string, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "service": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.service.stop(param);
    }
);

HDSTL.Command("@webrtc_start_preview_video(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.webrtc.startPreviewVideo(param);
    }
);

HDSTL.Command("@webrtc_stop_preview_video(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.webrtc.stopPreviewVideo(param);
    }
);

HDSTL.Command("@webrtc_outgoing_call(local_id:number, remote_id:number, result:number)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "localId":args[1],
            "remoteId":args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.webrtc.outgoingCall(param);
    }
);

HDSTL.Command("@webrtc_incoming_call(local_id:number, remote_id:number, remote_sdp:string, result:number)",
    function(args) {
        var expected_result = args[4];
        var param = {
            "localId":args[1],
            "remoteId":args[2],
            "remoteSDP":args[3],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.webrtc.incomingCall(param);
    }
);

HDSTL.Command("@webrtc_end_call(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.webrtc.endCall(param);
    }
);

HDSTL.Command("@webrtc_accept_message(remote_id:number, rtc_msg:string, result:number)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "remoteId":args[1],
            "rtcMsg":args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.webrtc.acceptMessage(param);
    }
);

HDSTL.Command("@webrtc_start_check_audio(type:string, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
        	"type":args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.webrtc.startCheckAudio(param);
    }
);

HDSTL.Command("@webrtc_stop_check_audio(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.webrtc.stopCheckAudio(param);
    }
);

HDSTL.Command("@webrtc_set_configuration(key:string, value:string, result:number)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "key":args[1],
            "value":args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.webrtc.setConfiguration(param);
    }
);

HDSTL.Command("@webrtc_get_configuration(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(prefix.DONT_CARE, param.configurations, "configurations");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.webrtc.getConfiguration(param);
    }
);

HDSTL.Command("@webrtc_show_diagnostics(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.webrtc.showDiagnostics(param);
    }
);

HDSTL.getExternalInputString = function(type) {
    if (type == hcap.externalinput.ExternalInputType.TV) {
        return "TV";
    }
    if (type == hcap.externalinput.ExternalInputType.COMPOSITE) {
        return "COMPOSITE";
    }
    if (type == hcap.externalinput.ExternalInputType.SVIDEO) {
        return "SVIDEO";
    }
    if (type == hcap.externalinput.ExternalInputType.COMPONENT) {
        return "COMPONENT";
    }
    if (type == hcap.externalinput.ExternalInputType.RGB) {
        return "RGB";
    }
    if (type == hcap.externalinput.ExternalInputType.HDMI) {
        return "HDMI";
    }
    if (type == hcap.externalinput.ExternalInputType.SCART) {
        return "SCART";
    }
    if (type == hcap.externalinput.ExternalInputType.USB) {
        return "USB";
    }
    if (type == hcap.externalinput.ExternalInputType.OTHERS) {
        return "OTHERS";
    }
    return "Unknown";
}


HDSTL.Command("@get_external_input_list(result)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(prefix.DONT_CARE, param.inputSourceList.length, "list");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.externalinput.getExternalInputList(param);
    }
);
/*
HDSTL.Command("@get_external_input_list(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess":HDSTL.checkSuccess(expected_result,
                function(param) {
                    if (param.list) {
                        print_msg("length :" + param.list.length );
                        for (var i = 0; i < param.list.length; i++) {
                            print_msg("inputPort :" + param.list[i].inputPort +
                            "signalDetection : " + param.list[i].signalDetection +
                            "type : " + param.list[i].type  +
                            "index :" + param.list[i].index );
                        }
                    }
                    print_msg("Total Count :" + param.count );
                    print_msg("CurrentInputPort :" + param.currentInputPort );
                    var command_result = util.is_equal(prefix.DONT_CARE, param.list.length, "list");
                    print_msg("command_result :" + command_result );
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.externalinput.getExternalInputList(param);
    }
);
*/
HDSTL.Command("@get_picture_mode(result:number,picture_mode:string)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(args[2], param.mode, "pictureMode");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.property.getPictureMode(param);
    }
);

HDSTL.Command("@set_picture_mode(picture_mode:string,result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "mode": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.property.setPictureMode(param);
    }
);

HDSTL.Command("@get_sound_output(result:number,speakerType:string)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(args[2], param.speakerType, "speakerType");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.getSoundOutput(param);
    }
);

HDSTL.Command("@get_default_sound_output(result:number,sound_output:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(args[2], param.defaultSoundOutput, "defaultSoundOutput");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.getDefaultSoundOutput(param);
    }
);

HDSTL.Command("@set_sound_output(speakerType:string,result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "speakerType": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.setSoundOutput(param);
    }
);

HDSTL.Command("@set_default_sound_output(default_sound_output,result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "speakerType": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.setDefaultSoundOutput(param);
    }
);

HDSTL.Command("@get_hotel_mode(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(prefix.DONT_CARE, param.hotelMode, "hotelMode");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.property.getHotelMode(param);
    }
);

HDSTL.Command("@set_hotel_mode(hotelMode, result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "hotelMode":args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.property.setHotelMode(param);
    }
);

HDSTL.Command("@register_server_certificate(nickname:string, certificate:string, enableVerifyHost:boolean, isSelfSigned:boolean, accessCode:string, result:number)",
    function(args) {
        var expected_result = args[5];
        var cert = args[2];
        var res = cert.replace(/\\n/g, "\n");
        var param = {
            "nickname":args[1],
            "certificate":res,
            "enableVerifyHost":args[3],
            "isSelfSigned":args[4],
            "accessCode":args[5],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.security.registerServerCertificate(param);
    }
);

HDSTL.Command("@register_client_certificate(nickname:string, certificate:string, key:string, keypasswd:string, cacert:string, urlPattern:string, issuerCN:string, isSelfSigned:boolean, accessCode:string, result:number)",
    function(args) {
        var expected_result = args[10];
        var cert = args[2];
        var res_cert = cert.replace(/\\n/g, "\n");
        var key = args[3];
        var res_key = key.replace(/\\n/g, "\n");
        var cacert = args[5];
        var res_cacert = cacert.replace(/\\n/g, "\n");
        var param = {
            "nickname":args[1],
            "certificate":res_cert,
            "key":res_key,
            "keyPassword":args[4],
            "cacert":res_cacert,
            "urlPattern":args[6],
            "issuerCN":args[7],
            "isSelfSigned":args[8],
            "accessCode":args[9],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.security.registerClientCertificate(param);
    }
);

HDSTL.Command("@unregister_server_certificate(nickname:string, accessCode:string, result:number)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "nickname":args[1],
            "accessCode":args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.security.unregisterServerCertificate(param);
    }
);

HDSTL.Command("@unregister_client_certificate(nickname:string, accessCode:string, result:number)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "nickname":args[1],
            "accessCode":args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.security.unregisterClientCertificate(param);
    }
);

HDSTL.Command("@exist_server_certificate(nickname:string, accessCode:string, result:number, expected_exist:boolean)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "nickname":args[1],
            "accessCode":args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(args[4], param.exist, "exist");
                    command_result.add(util.is_equal(args[1], param.nickname, "nickname"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.security.existServerCertificate(param);
    }
);

HDSTL.Command("@exist_client_certificate(nickname:string, accessCode:string, result:number, expected_exist:boolean)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "nickname":args[1],
            "accessCode":args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(args[4], param.exist, "exist");
                    command_result.add(util.is_equal(args[1], param.nickname, "nickname"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.security.existClientCertificate(param);
    }
);

HDSTL.Command("@get_service_xml(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(prefix.DONT_CARE, param.contents, "contents");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.application.getServiceXml(param);
    }
);

HDSTL.Command("@get_default_service_xml(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(prefix.DONT_CARE, param.contents, "contents");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.application.getDefaultServiceXml(param);
    }
);

HDSTL.Command("@get_application_list(result:number, list_length:number, valid_0:boolean, title_0:string, id_0:string, deleted_0:boolean, visible_0:boolean, version_0:string, path_0:string, reason_0 = args[10])",
    function(args) {
        var expected_result = args[1],
        		expected_list_length = args[2],
        		expected_valid_0 = args[3],
        		expected_title_0 = args[4],
        		expected_id_0 = args[5];
        		expected_deleted_0 = args[6];
        		expected_visible_0 = args[7];
        		expected_version_0 = args[8];
        		expected_path_0 = args[9];
        		expected_reason_0 = args[10];

        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    if (param.list) {
                        for (var i = 0; i < param.list.length; i++) {
                            print_msg("list[" + i + "] vailid = " + param.list[i].valid + ", title = " + param.list[i].title + ", id = " + param.list[i].appId, ", deleted = " + param.list[i].deleted, ", visible = " + param.list[i].visible, ", version = " + param.list[i].version, ", iconPath = " + param.list[i].iconPath, ", reason = " + param.list[i].reason);
                        }
                    }
                	var command_result = util.is_equal(expected_list_length, param.list.length, "list length");
                	command_result.add(util.is_equal(expected_valid_0, param.list[0].valid, "list[0].valid"));
                	command_result.add(util.is_equal(expected_title_0, param.list[0].title, "list[0].title"));
                	command_result.add(util.is_equal(expected_id_0, param.list[0].id, "list[0].id"));
                	command_result.add(util.is_equal(expected_deleted_0, param.list[0].deleted, "list[0].deleted"));
                	command_result.add(util.is_equal(expected_visible_0, param.list[0].visible, "list[0].visible"));
                	command_result.add(util.is_equal(expected_version_0, param.list[0].version, "list[0].version"));
                	command_result.add(util.is_equal(expected_path_0, param.list[0].path, "list[0].path"));
                	command_result.add(util.is_equal(expected_reason_0, param.list[0].reason, "list[0].reason"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.application.getApplicationList(param);
    }
);

HDSTL.Command("@launch_application(id:string, result:number)",
    function(args) {
        var expected_result = args[2];

        var param = {
        	"id":args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.application.launchApplication(param);
    }
);

HDSTL.Command("@launch_application_with_parameters(id:string, parameters:string, result:number)",
    function(args) {
        var expected_result = args[3];

        var param = {
            "id":args[1],
            "parameters":args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.application.launchApplication(param);
    }
);

HDSTL.Command("@destroy_application(id:string, result:number)",
    function(args) {
        var expected_result = args[2];

        var param = {
            "id":args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.application.destroyApplication(param);
    }
);

HDSTL.Command("@get_bt_sound_sync(result:number, enable:bool)",
    function(args) {
        var expected_result = args[1], expected_enable = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_enable, param.enable, "enable");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.getBluetoothSoundSync(param);
    }
);

HDSTL.Command("@set_bt_sound_sync(enable:bool, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "enable": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.bluetooth.setBluetoothSoundSync(param);
    }
);

HDSTL.Command("@get_audio_pts_offset(result:number, audioPtsOffset:number)",
    function(args) {
        var expected_result = args[1], expected_audio_pts_offset = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_audio_pts_offset, param.audioPtsOffset, "audioPtsOffset");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.getAudioPtsOffset(param);
    }
);

HDSTL.Command("@set_audio_pts_offset(audioPtsOffset:number, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "audioPtsOffset":args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.setAudioPtsOffset(param);
    }
);

HDSTL.Command("@get_video_pts_offset(result:number, videoPtsOffset:number)",
    function(args) {
        var expected_result = args[1], expected_video_pts_offset = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_video_pts_offset, param.videoPtsOffset, "videoPtsOffset");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.getVideoPtsOffset(param);
    }
);

HDSTL.Command("@set_video_pts_offset(videoPtsOffset:number, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "videoPtsOffset":args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.setVideoPtsOffset(param);
    }
);

HDSTL.Command("@get_cpu_time(expected_result:number, expected_cpu_time:number)",
    function(args) {
        var expected_result = args[1], expected_cpu_time = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_cpu_time, param.cpuTime, "cpuTime");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.time.getCpuTime(param);
    }
);

// HDSTL.Command("@get_proxy_server(result:number, enabled:bool, ip:string, port:number)",
//     function(args) {
//         var expected_result = args[1],
//                 expected_ip = args[3],
//                 expected_port = args[4];

//         htaf_log(make_htaf_log("[Test Args]", args));

//         hcap.system.getProxyServer({
//             "onSuccess": HDSTL.checkSuccess(expected_result,
//                 function(param) {
//                     var command_result = util.is_equal(expected_ip, param.ipAddress, "ipAddress");
//                     command_result.add(util.is_equal(expected_port, param.port, "port"));
//                     return command_result;
//                 }),
//             "onFailure": HDSTL.checkFailure(expected_result)
//         });
//     }
// );

// HDSTL.Command("@set_proxy_server(enabled:bool, ipAddress:string, port:number, userName, password, result:number)",
//     function(args) {
//         var expected_result = args[6];
//         var param = {
//             "enabled":args[1],
//             "ipAddress":args[2],
//             "port":args[3],
//             "userName":args[4],
//             "password":args[5],
//             "onSuccess": HDSTL.checkSuccess(expected_result,null),
//             "onFailure": HDSTL.checkFailure(expected_result)
//         };

//         htaf_log(make_htaf_log("[Test Args]", args));
//         hcap.system.setProxyServer(param);
//     }
// );

HDSTL.Command("@expire_proxy_server(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.expireProxyServer(param);
    }
);

HDSTL.Command("@get_browser_debug_mode(result:number, debugMode:bool)",
    function(args) {
        var expected_result = args[1], expected_debug_mode = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_debug_mode, param.debugMode, "debugMode");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.getBrowserDebugMode(param);
    }
);

HDSTL.Command("@set_browser_debug_mode(debugMode:bool, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "debugMode": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.setBrowserDebugMode(param);
    }
);

HDSTL.Command("@get_no_signal_image(result:number, noSignalImage:bool)",
    function(args) {
        var expected_result = args[1], expected_no_signal_image = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_no_signal_image, param.noSignalImage, "noSignalImage");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.getNoSignalImage(param);
    }
);

HDSTL.Command("@set_no_signal_image(noSignalImage:bool, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "mode": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.setNoSignalImage(param);
    }
);

HDSTL.Command("@get_wifi_diagnostics(result:number, version:string, country_code_revision:number, country_code:string, channel:number, mcs:number, mimo:string, rate:string, rssi:string, noise:string, transimission_power:string, band_width:string)",
    function(args) {
        var expected_result = args[1],
            expected_version = args[2],
            expected_country_code_revision = args[3],
            expected_country_code = args[4],
            expected_channel = args[5],
            expected_mcs = args[6],
            expected_mimo = args[7],
            expected_rate = args[8],
            expected_rssi = args[9],
            expected_noise = args[10],
            expected_transimission_power = args[11];
            expected_band_width = args[12];

        htaf_log(make_htaf_log("[Test Args]", args));

        hcap.network.getWifiDiagnostics({
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_version, param.version, "version");
                    command_result.add(util.is_equal(expected_country_code_revision, param.countryCodeRevision, "countryCodeRevision"));
                    command_result.add(util.is_equal(expected_country_code, param.countryCode, "countryCode"));
                    command_result.add(util.is_equal(expected_channel, param.channel, "channel"));
                    command_result.add(util.is_equal(expected_mcs, param.mcs, "mcs"));
                    command_result.add(util.is_equal(expected_mimo, param.mimo, "mimo"));
                    command_result.add(util.is_equal(expected_rate, param.rate, "rate"));
                    command_result.add(util.is_equal(expected_rssi, param.rssi, "rssi"));
                    command_result.add(util.is_equal(expected_noise, param.noise, "noise"));
                    command_result.add(util.is_equal(expected_transimission_power, param.transimissionPower, "transimissionPower"));
                    command_result.add(util.is_equal(expected_band_width, param.bandWidth, "bandWidth"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        });
    }
);

HDSTL.Command("@get_channel_signal_status(result:number, snr_value:number, frequency:number, signal_level:number, modulation_mode:string, lock_status:bool)",
    function(args) {
        var expected_result = args[1],
        	expected_snr_value = args[2],
        	expected_frequency = args[3],
        	expected_signal_level = args[4],
        	expected_modulation_mode = args[5],
        	expected_lock_status = args[6];

        htaf_log(make_htaf_log("[Test Args]", args));

        hcap.channel.getChannelSignalStatus({
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_snr_value, param.snrValue, "snrValue");
                    command_result.add(util.is_equal(expected_frequency, param.frequency, "frequency"));
                    command_result.add(util.is_equal(expected_signal_level, param.signalLevel, "signalLevel"));
                    command_result.add(util.is_equal(expected_modulation_mode, param.modulationMode, "modulationMode"));
                    command_result.add(util.is_equal(expected_lock_status, param.lockStatus, "lockStatus"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        });
    }
);

HDSTL.Command("@async_ping(ip, result)",
    function(args) {
        var ip = args[1], expected_result = args[2];

        var param = {
            "ip": ip,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.network.asyncPing(param);
    }
);

HDSTL.Command("@get_screen_keyboard_language_list(result, language_list)",
    function(args) {
        var expected_result = args[1], expected_list = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.getScreenKeyboardLanguageList(param);
    }
);

HDSTL.Command("@set_screen_keyboard_language(keyboard_language, result)",
	function(args) {
        var expected_result = args[2];
        var parameters = {
            "keyboardLanguage":args[1],
        };
	    var param = {
	    	"parameters": parameters,
	        "onSuccess": HDSTL.checkSuccess(expected_result, null),
	        "onFailure": HDSTL.checkFailure(expected_result)
	    };

	    htaf_log(make_htaf_log("[Test Args]", args));
	    hcap.system.setScreenKeyboardLanguage(param);
	}
);

HDSTL.Command("@set_screen_keyboard_language_list(keyboard_language, result)",
	function(args) {
		var expected_result = args[2];
        var parameters = {
                "keyboardLanguage":args[1]
        };
	    var param = {
	    	"parameters": parameters,
	        "onSuccess": HDSTL.checkSuccess(expected_result, null),
	        "onFailure": HDSTL.checkFailure(expected_result)
	    };

	    htaf_log(make_htaf_log("[Test Args]", args));
	    idcap.request("idcap://system/screenkeyboardlanguagelist/set",param)
	}
);

HDSTL.Command("@get_healthcare_headphone_mode(result:number, enable:bool)",
    function(args) {
        var expected_result = args[1], expected_enable = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_enable, param.enable, "enable");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.volume.getHealthcareHeadphoneMode(param);
    }
);

HDSTL.Command("@set_healthcare_headphone_mode(enable:bool, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "enable": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.volume.setHealthcareHeadphoneMode(param);
    }
);

HDSTL.Command("@get_headphone_volume_level(result, volume_level)",
    function(args) {
        var expected_result = args[1], expected_level = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_level, param.level, "level");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.volume.getHeadphoneVolumeLevel(param);
    }
);

HDSTL.Command("@set_headphone_volume_level(volume_level, result)",
    function(args) {
        var expected_result = args[2],
            event_name = "volume_level_changed",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));
                HDSTL.setResult(true, event_name + " event received");
                HDSTL.finish();
            };

        var param = {
            "level": args[1],
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };

        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.volume.setHeadphoneVolumeLevel(param);
    }
);

HDSTL.Command("@set_beacon_mode(enable:bool, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "enable": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.beacon.setBeaconMode(param);
    }
);

HDSTL.Command("@get_beacon_information(result:number, beacon_mode:bool, beacon_type:string, iBeacon_uuid:string, iBeacon_major:number, iBeacon_minor:number, eddystone_uuid:string, eddystone_frame:string, eddystone_prefix:string, eddystone_excode:string, eddystone_url:string)",
	function(args) {
        var expected_result = args[1],
        	expected_beacon_mode = args[2],
        	expected_beacon_type = args[3],
        	expected_iBeacon_uuid = args[4],
        	expected_iBeacon_major = args[5],
        	expected_iBeacon_minor = args[6],
        	expected_eddystone_uuid = args[7],
        	expected_eddystone_frame = args[8],
        	expected_eddystone_prefix = args[9],
        	expected_eddystone_excode = args[10],
        	expected_eddystone_url = args[11];

        htaf_log(make_htaf_log("[Test Args]", args));

        hcap.beacon.getBeaconInformation({
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_beacon_mode, param.beaconMode, "beaconMode");
                    command_result.add(util.is_equal(expected_beacon_type, param.beaconType, "beaconType"));
                    command_result.add(util.is_equal(expected_iBeacon_uuid, param.iBeaconUuid, "iBeaconUuid"));
                    command_result.add(util.is_equal(expected_iBeacon_major, param.iBeaconMajor, "iBeaconMajor"));
                    command_result.add(util.is_equal(expected_iBeacon_minor, param.iBeaconMinor, "iBeaconMinor"));
                    command_result.add(util.is_equal(expected_eddystone_uuid, param.eddyStoneUuid, "eddyStoneUuid"));
                    command_result.add(util.is_equal(expected_eddystone_frame, param.eddyStoneFrame, "eddyStoneFrame"));
                    command_result.add(util.is_equal(expected_eddystone_prefix, param.eddyStoneUrlPrefix, "eddyStoneUrlPrefix"));
                    command_result.add(util.is_equal(expected_eddystone_excode, param.eddyStoneUrlExCode, "eddyStoneUrlExCode"));
                    command_result.add(util.is_equal(expected_eddystone_url, param.eddyStoneUrl, "eddyStoneUrl"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        });
    }
);

HDSTL.Command("@request_iBeacon(uuid:string, major:number, minor:number, result:number)",
    function(args) {
        var expected_result = args[4];
        var param = {
            "uuid":args[1],
            "major":args[2],
            "minor":args[3],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.beacon.requestiBeacon(param);
    }
);

HDSTL.Command("@request_eddystone_uid(uuid:string, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "uuid":args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.beacon.requestEddystoneUid(param);
    }
);

HDSTL.Command("@request_eddystone_url(prefix:string, excode:string, url:string, result:number)",
    function(args) {
        var expected_result = args[4];
        var param = {
            "prefix":args[1],
            "excode":args[2],
            "url":args[3],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.beacon.requestEddystoneUrl(param);
    }
);

HDSTL.Command("@get_vlan_id_mode(result:number, enable:bool)",
    function(args) {
        var expected_result = args[1], expected_enable = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_enable, param.enable, "enable");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.network.getVlanIdMode(param);
    }
);

HDSTL.Command("@set_vlan_id_mode(enable:bool, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "enable": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.network.setVlanIdMode(param);
    }
);

HDSTL.Command("@get_lan_id(result, lan_id)",
    function(args) {
        var expected_result = args[1], expected_lan_id = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_lan_id, param.lanId, "lanId");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.network.getLanId(param);
    }
);

HDSTL.Command("@set_lan_id(lan_id, result)",
	function(args) {
		var expected_result = args[2];
	    var param = {
	        "lanId":args[1],
	        "onSuccess": HDSTL.checkSuccess(expected_result,null),
	        "onFailure": HDSTL.checkFailure(expected_result)
	    };

	    htaf_log(make_htaf_log("[Test Args]", args));
	    hcap.network.setLanId(param);
	}
);

HDSTL.Command("@get_aux_lan_id(result, aux_lan_id)",
    function(args) {
        var expected_result = args[1], expected_aux_lan_id = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_aux_lan_id, param.auxLanId, "auxLanId");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.network.getAuxLanId(param);
    }
);

HDSTL.Command("@set_aux_lan_id(aux_lan_id, result)",
	function(args) {
		var expected_result = args[2];
	    var param = {
	        "auxLanId":args[1],
	        "onSuccess": HDSTL.checkSuccess(expected_result,null),
	        "onFailure": HDSTL.checkFailure(expected_result)
	    };

	    htaf_log(make_htaf_log("[Test Args]", args));
	    hcap.network.setAuxLanId(param);
	}
);

HDSTL.Command("@get_idcap_installer_menu_item(key:string, expected_result:number, expected_value:number)",
    function(args) {
        var property_key = args[1],
            expected_result = args[2],
            expected_value = args[3];

        var param = {
            "key":property_key,
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_value, param.value, "property_value");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.property.getInstallerMenuItem(param);
    }
);

HDSTL.Command("@set_installer_menu_item(key:number, value:number, expected_result:number)",
    function(args) {
        var property_key = args[1],
            property_value = args[2],
            expected_result = args[3];

        var param = {
            "key":property_key,
            "value":property_value,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.property.setInstallerMenuItem(param);
    }
);

HDSTL.Command("@get_speech_recognition(result:number, enable:bool)",
    function(args) {
        var expected_result = args[1], expected_enable = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_enable, param.enable, "enable");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.speech.getSpeechRecognition(param);
    }
);

HDSTL.Command("@set_speech_recognition(enable:bool, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "enable": args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.speech.setSpeechRecognition(param);
    }
);

HDSTL.Command("@decide_host(service_type:string, action_type:string, host_type:number, result:number)",
    function(args) {
        var expected_result = args[4];
        var param = {
            "serviceType":args[1],
            "actionType":args[2],
            "hostType":args[3],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.speech.decideHost(param);
        host_type = args[3];
    }
);

HDSTL.Command("@get_usb_power_control(port_number:number, result:number, status:bool)",
    function(args) {
        var port_number = args[1],
            expected_result = args[2],
            expected_status = args[3];

        var param = {
            "portNumber":port_number,
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_status, param.status, "status");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.getUsbPowerControl(param);
    }
);

HDSTL.Command("@set_usb_power_control(port_number:number, status:bool, result:number)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "portNumber":args[1],
            "status":args[2],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.setUsbPowerControl(param);
    }
);

HDSTL.Command("@get_external_speaker_volume_level(result, volume_level)",
    function(args) {
        var expected_result = args[1], expected_level = args[2];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_level, param.level, "level");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.volume.getExternalSpeakerVolumeLevel(param);
    }
);

HDSTL.Command("@set_external_speaker_volume_level(volume_level, result)",
    function(args) {
        var expected_result = args[2],
            event_name = "volume_level_changed",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));
                HDSTL.setResult(true, event_name + " event received");
                HDSTL.finish();
            };

        var param = {
            "level": args[1],
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };

        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.volume.setExternalSpeakerVolumeLevel(param);
    }
);

HDSTL.Command("@show_toast_message(message:string, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "msg":args[1],
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        hcap.system.showToastMessage(param);
    }
);

// HDSTL.Command("@get_blocked_port_list(result:number)",
//     function(args) {
//         var expected_result = args[1];
//         var param = {
//             "onSuccess": HDSTL.checkSuccess(expected_result,
//                 function(param) {
//                     var command_result = util.is_equal(prefix.DONT_CARE, param.blockedPortList, "blockedPortList");
//                     return command_result;
//                 }),
//             "onFailure": HDSTL.checkFailure(expected_result)
//         };

//         htaf_log(make_htaf_log("[Test Args]", args));
//         hcap.network.getBlockedPortList(param);
//     }
// );

// HDSTL.Command("@set_blocked_port_list(port:number, result:number)",
//     function(args) {
//         var expected_result = args[2];
//         var num = args[1];

//         if(num == "0") {
//             var param = {
//                 "blockedPortList":[],
//                 "onSuccess": HDSTL.checkSuccess(expected_result, null),
//                 "onFailure": HDSTL.checkFailure(expected_result)
//             };

//             htaf_log(make_htaf_log("[Test Args]", args));
//             hcap.network.setBlockedPortList(param);
//         }
//         else {
//             var param = {
//                 "blockedPortList":[{"blockedPort":"33252", "protocol":"tcp", "direction":"all"},{"blockedPort":"33322", "protocol":"tcp", "direction":"in"},{"blockedPort":"53422", "protocol":"udp", "direction":"out"}],
//                 "onSuccess": HDSTL.checkSuccess(expected_result, null),
//                 "onFailure": HDSTL.checkFailure(expected_result)
//             };

//             htaf_log(make_htaf_log("[Test Args]", args));
//             hcap.network.setBlockedPortList(param);
//         }
//     }
// );

HDSTL.Command("@stop_wps(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://network/wifi/wps/stop",param);
    }
);

HDSTL.Command("@set_display_mute(displaymode, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "displaymode" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://system/display/mute/set",param);
    }
);

HDSTL.Command("@get_usage(keys, result)",
    function(args) {
        var expected_result = args[2];

        if(args[1]=="cpu" || args[1]=="memory"){
            var parameters = {
                "keys" : [ args[1] ]
            };
            var param = {
                "parameters" : parameters,
                "onSuccess": HDSTL.checkSuccess(expected_result, null),
                "onFailure": HDSTL.checkFailure(expected_result)
            };

            htaf_log(make_htaf_log("[Test Args]", args));
            idcap.request("idcap://system/usage/get",param);
        }
        else {
            var parameters = {
                "keys" : ["cpu","memory"]
            };
            var param = {
                "parameters" : parameters,
                "onSuccess": HDSTL.checkSuccess(expected_result, null),
                "onFailure": HDSTL.checkFailure(expected_result)
            };

            htaf_log(make_htaf_log("[Test Args]", args));
            idcap.request("idcap://system/usage/get",param);
        }
    }
);

HDSTL.Command("@file_download(action, source, destination, ticket, ftpOption, httpOption, result)",
    function(args) {
        event_name = "idcap:::file_downloaded",
        event_listener = function eventListener(param) {
            HDSTL.removeEvent(event_name, event_listener)();
            htaf_log(make_htaf_log(event_name, param));
            HDSTL.setResult(true, event_name + " event received");
            HDSTL.finish();
        };
        var expected_result = args[7];
        var parameters = {
            "action" : args[1],
            "source" : args[2],
            "destination" : args[3],
            "ticket" : args[4],
            "ftpOption" : args[5],
            "httpOption" : args[6]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess2(expected_result, null,HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null,HDSTL.removeEvent(event_name, event_listener))
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        HDSTL.addEvent(event_name, event_listener)();
        idcap.request("idcap://storage/file/download",param);
    }
);
HDSTL.Command("@file_download_hotel(uri, path,result)",
    function(args) {
        var expected_result = args[3];
        var parameters = {
            "uri" : args[1],
            "path" : args[2]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://storage/file/download",param);
    }
);

HDSTL.Command("@get_download_status(ticket, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "ticket" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://storage/file/downloadstatus",param);
    }
);

HDSTL.Command("@file_exist(path, result, expected_file_exist)",
    function(args) {
        var expected_result = args[2], expected_file_exist = args[3];
        var parameters = {
            "path" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_file_exist, param.exists, "exists");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://storage/file/exist",param);
    }
);

HDSTL.Command("@move_file(from, to, result)",
    function(args) {
        var expected_result = args[3];
        var parameters = {
            "from" : args[1],
            "to" : args[2]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://storage/file/move",param);
    }
);

HDSTL.Command("@copy_file(from, to, result)",
    function(args) {
        var expected_result = args[3];
        var parameters = {
            "from" : args[1],
            "to" : args[2]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://storage/file/copy",param);
    }
);

HDSTL.Command("@make_directory(path, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "path" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://storage/file/mkdir",param);
    }
);

HDSTL.Command("@file_info(path, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "path" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://storage/file/stat",param);
    }
);

HDSTL.Command("@set_soft_ap_signage(enabled, ssid, securityKey, result)",
    function(args) {
        var expected_result = args[4];
        var parameters = {
            "enabled" : args[1],
            "ssid" : args[2],
            "securityKey" : args[3],
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://network/softap/set",param);
    }
);

HDSTL.Command("@get_soft_ap_signage(result, enabled, ssid, securityKey)",
    function(args) {
        var expected_result = args[1];
        var expected_enable = args[2];
        var expected_ssid = args[3];
        var expected_securityKey = args[4];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": (param) => {
                if (args[2] !== undefined){
                    if (param.enabled){
                        HDSTL.checkSuccess(expected_result,
                            function(param) {
                                var command_result = util.is_equal(expected_enable, param.enabled, "enabled");
                                command_result.add(util.is_equal(expected_ssid, param.ssid, "ssid"));
                                command_result.add(util.is_equal(expected_securityKey, param.securityKey, "securityKey"));
                                return command_result;
                            });
                    } else {
                        HDSTL.checkSuccess(expected_result,
                            function(param) {
                                var command_result = util.is_equal(expected_enable, param.enabled, "enabled");
                                return command_result;
                            });
                    }
                } else {
                    HDSTL.checkSuccess(expected_result, null);
                }
            },
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://network/softap/get",param);
    }
);

HDSTL.Command("@get_wifi_aplist(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://network/wifi/aplist/get",param);
    }
);

HDSTL.Command("@wifi_connect(ssid, password, hidden, result)",
    function(args) {
        var expected_result = args[4];
        var parameters = {
            "ssid" : args[1],
            "password" : args[2],
            "hidden" : args[3],
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://network/wifi/connect",param);
    }
);

HDSTL.Command("@start_wps(method, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "method" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://network/wifi/wps/start",param);
    }
);

HDSTL.Command("@unzip_file(zipPath, targetPath, result)",
    function(args) {
        var expected_result = args[3];
        var parameters = {
            "zipPath" : args[1],
            "targetPath" : args[2]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://storage/file/unzip",param);
    }
);

HDSTL.Command("@file_write(path, data, mode, position, length, offset, result)",
    function(args) {
        var expected_result = args[7];
        var parameters = {
            "path" : args[1],
            "data" : args[2],
            "mode" : args[3],
            "position" : args[4],
            "length" : args[5],
            "offset" : args[6]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://storage/file/write",param);
    }
);

HDSTL.Command("@file_read(path,expected_value ,result)",
    function(args) {
        var expected_result = args[3];
        var expected_value =args[2];
        var parameters = {
            "path" : args[1],
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, function(param) {
                var command_result = util.is_equal(expected_value, param.data, "data");
                return command_result;
            }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://storage/file/read",param);
    }
);

HDSTL.Command("@reset_onofftimer(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://time/onofftimer/reset",param);
    }
);

HDSTL.Command("@get_onofftimer_list(result, type:string, hour:number, minute:number, week:number)",
    function(args) {
        var expected_result = args[1];
        var expected_type = args[2] === undefined ? "?" : args[2];
        var expected_hour = args[3] === undefined ? "?" : args[3];
        var expected_minute = args[4] === undefined ? "?" : args[4];
        var expected_week = args[5] === undefined ? "?" : args[5];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_type, param[0].type, "type");
                        command_result.add(util.is_equal(expected_hour, param.hour, "hour"));
                        command_result.add(util.is_equal(expected_minute, param.minute, "minute"));
                        command_result.add(util.is_equal(expected_week, param.week, "week"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://time/onofftimer/list",param);
    }
);

HDSTL.Command("@cancel_onofftimer(id, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "id" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://time/onofftimer/cancel",param);
    }
);

HDSTL.Command("@add_onofftimer(type, hour, minute, week, result)",
    function(args) {
        var expected_result = args[5];
        var parameters = {
            "type" : args[1],
            "hour" : args[2],
            "minute" : args[3],
            "week" : args[4]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://time/onofftimer/add",param);
    }
);

HDSTL.Command("@get_power_onoffhistory(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://power/onoffhistory/get",param);
    }
);

HDSTL.Command("@clear_browsing_data(type, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "type" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://system/browsingdata/clear",param);
    }
);

HDSTL.Command("@get_avsync(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://system/avsync/get",param);
    }
);

HDSTL.Command("@set_avsync(avSync, avSyncBypass, avSyncSpeaker, result)",
    function(args) {
        var expected_result = args[4];
        var parameters = {
            "avSync" : args[1],
            "avSyncBypass" : args[2],
            "avSyncSpeaker" : args[3],
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://system/avsync/set",param);
    }
);

HDSTL.Command("@get_whitebalance(result ,rGain:number,gGain:number,bGain:number)",
    function(args) {
        var expected_result = args[1];
        var expected_rGain = args[2] === undefined ? "?" : args[2];
        var expected_gGain = args[3] === undefined ? "?" : args[3];
        var expected_bGain = args[4] === undefined ? "?" : args[4];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_rGain, param.rGain, "rGain");
                        command_result.add(util.is_equal(expected_gGain, param.gGain, "gGain"));
                        command_result.add(util.is_equal(expected_bGain, param.bGain, "bGain"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://signage/whitebalance/get",param);
    }
);

HDSTL.Command("@set_whitebalance(result, rGain:number,gGain:number,bGain:number)",
    function(args) {
        var expected_result = args[1];
        var parameters = {
            "rGain" : args[2],
            "gGain" : args[3],
            "bGain" : args[4],
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://signage/whitebalance/set",param);
    }
);

HDSTL.Command("@set_enterprisecode(enterpriseCode, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "enterpriseCode" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://signage/enterprisecode/set",param);
    }
);

HDSTL.Command("@get_app_info(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://application/info/get",param);
    }
);

HDSTL.Command("@launch_signage_app(type, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "app" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://application/signage/launch",param);
    }
);

HDSTL.Command("@set_master_video(ip, port, result)",
    function(args) {
        var expected_result = args[3];
        var parameters = {
            "ip" : args[1],
            "port" : args[2]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://video/master/set",param);
    }
);

HDSTL.Command("@set_slave_video(ip, port, basetime, result)",
    function(args) {
        var expected_result = args[4];
        var parameters = {
            "ip" : args[1],
            "port" : args[2],
            "basetime" : args[3]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://video/slave/set",param);
    }
);


HDSTL.Command("@remove_application(appMode, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "appMode" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://application/remove",param);
    }
);

HDSTL.Command("@upgrade_signage_application(from, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "from" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://application/upgrade",param);
    }
);

HDSTL.Command("@set_digitalAudioInputMode(digitalAudioInput, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "digitalAudioInput" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://audio/digitalaudioinputmode/set",param);
    }
);

HDSTL.Command("@get_ism_method(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://configuration/ismmethod/get",param);
    }
);

HDSTL.Command("@set_ism_method(ismMethod, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "ismMethod" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://configuration/ismmethod/set",param);
    }
);

HDSTL.Command("@get_dpm_info(result, dpmMode(string), dpmSignalType(string))",
    function(args) {
        var expected_result = args[1];
        var expected_dpmMode = args[2] === undefined ? "?" : args[2];
        var expected_dpmSignalType = args[3] === undefined ? "?" : args[3];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_dpmMode, param.dpmMode, "dpmMode");
                        command_result.add(util.is_equal(expected_dpmSignalType, param.dpmSignalType, "dpmSignalType"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://power/dpm/get",param);
    }
);

HDSTL.Command("@set_dpm_info(dpmMode, dpmSignalType, result)",
    function(args) {
        var expected_result = args[3];
        var parameters = {
            "dpmMode" : args[1],
            "dpmSignalType" : args[2]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://power/dpm/set",param);
    }
);

HDSTL.Command("@get_certificate_list(result, badssl, lg1, lg2, lge)",
    function(args) {
        var expected_result = args[1];
        console.log('arg length = ', args.length);
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function (param){
                    console.log('param- ', JSON.stringify(param));
                    console.log('param-serverCertificateList - typeof is Array? - ', Array.isArray(param.serverCertificateList));
                    console.log('param-serverCertificateList - length  ', param.serverCertificateList.length);
                    if (Array.isArray(param.serverCertificateList) && param.serverCertificateList.length !== 0){
                        var command_result;
                        for(var i=0; i<param.serverCertificateList.length; i++){
                            if (i === 0 ){
                                command_result = util.is_equal(args[2+i], param.serverCertificateList[i].domainName, param.serverCertificateList[i].domainName);
                            } else {
                                command_result.util.is_equal(args[2+i], param.serverCertificateList[i].domainName, param.serverCertificateList[i].domainName);
                            }
                        }
                        // var command_result = util.is_equal(args[1], param[0].domainName, "badssl");
                        // command_result = command_result && util.is_equal(args[2], param[1].domainName, "lg1");
                        // command_result = command_result && util.is_equal(args[3], param[2].domainName, "lg2");
                        // command_result = command_result && util.is_equal(args[4], param[3].domainName, "lge");
                        return command_result;
                    } else if (Array.isArray(param.serverCertificateList) && param.serverCertificateList.length === 0 && args.length > 2){
                        HDSTL.setResult(false, "Array has no return value.");
                        HDSTL.finish();
                    } else {
                        HDSTL.setResult(true, "CertificateList returned.");
                        HDSTL.finish();
                    }
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://security/certificatelist/get",param);
    }
);

HDSTL.Command("@reset_certificate_list(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://security/certificatelist/reset",param);
    }
);

HDSTL.Command("@register_certificate_list(serverCertificateList, result)",
    function(args) {
        var param_cert_list = args[1];
        var x = JSON.parse(param_cert_list);
        var expected_result = args[2];
        var parameters = {
            "serverCertificateList" : x
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://security/certificatelist/register",param);
    }
);

HDSTL.Command("@unregister_certificate_list(domainNameList, result)",
    function(args) {
        var param_cert_list = args[1];
        var x = JSON.parse(param_cert_list);
        var expected_result = args[2];
        var parameters = {
            "domainNameList" : x
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://security/certificatelist/unregister",param);
    }
);

HDSTL.Command("@decrypt_file(cipher_mode, password, inputPath, outputFileName, result)",
    function(args) {
        var expected_result = args[5];
        var parameters = {
            "cipher_mode" : args[1],
            "password" : args[2],
            "inputPath" : args[3],
            "outputFileName" : args[4]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://security/decrypt",param);
    }
);

HDSTL.Command("@get_md5hash(path, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "path" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://security/md5hash/get",param);
    }
);

HDSTL.Command("@get_failover_mode(result, mode:string, prioirty1:string, prioirty2:string, prioirty3:string, prioirty4:string,)",
    function(args) {
        var expected_result = args[1];
        var expected_mode = args[2] === undefined ? "?" : args[2];
        var expected_p1 = args[3] === undefined ? "?" : args[3];
        var expected_p2 = args[4] === undefined ? "?" : args[4];
        var expected_p3 = args[5] === undefined ? "?" : args[5];
        var expected_p4 = args[5] === undefined ? "?" : args[5];

        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_mode, param.mode, "mode");
                    if (expected_mode === "manual"){
                        if (args[3] !== undefined) {
                            command_result.add(util.is_equal(expected_p1, param.priority[0], "prioirty1"));
                        }
                        if (args[4] !== undefined) {
                            command_result.add(util.is_equal(expected_p2, param.priority[1], "prioirty2"));
                        }
                        if (args[5] !== undefined) {
                            command_result.add(util.is_equal(expected_p3, param.priority[2], "prioirty3"));
                        }
                        if (args[6] !== undefined) {
                            command_result.add(util.is_equal(expected_p4, param.priority[3], "prioirty4"));
                        }
                    }
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://signage/failovermode/get",param);
    }
);

HDSTL.Command("@set_failover_mode(result, mode, priority)",
    function(args) {
        var expected_result = args[1];
        var parameters = {
            "mode" : args[2],
            "priority" : args[3]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://signage/failovermode/set",param);
    }
);

HDSTL.Command("@upgrade_signage_firmware(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://signage/firmware/upgrade",param);
    }
);

HDSTL.Command("@get_upgrade_signage_firmware_status(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://signage/firmware/progress/get",param);
    }
);

HDSTL.Command("@download_signage_firmware(uri, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "uri" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://signage/firmware/download",param);
    }
);

HDSTL.Command("@get_signage_si_server(result, serverip:string, serverport:number, secureConnection:string, applaunchmode:string, apptype:string, fqdnmode:string, fqdnaddr:string, autoset:string)",
    function(args) {
        var expected_result = args[1];
        var expected_serverIp = args[2] === undefined ? "?" : args[2];
        var expected_serverPort = args[3] === undefined ? "?" : args[3];
        var expected_secureConnection = args[4] === undefined ? "?" : args[4];
        var expected_appLaunchMode = args[5] === undefined ? "?" : args[5];
        var expected_appType = args[6] === undefined ? "?" : args[6];
        var expected_fqdnMode = args[7] === undefined ? "?" : args[7];
        var expected_fqdnAddr = args[8] === undefined ? "?" : args[8];
        var expected_autoSet = args[9] === undefined ? "?" : args[9];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_serverIp, param.serverIp, "serverIp");
                    command_result.add(util.is_equal(expected_serverPort, param.serverPort, "serverPort"));
                    command_result.add(util.is_equal(expected_secureConnection, param.secureConnection, "secureConnection"));
                    command_result.add(util.is_equal(expected_appLaunchMode, param.appLaunchMode, "appLaunchMode"));
                    command_result.add(util.is_equal(expected_appType, param.appType, "appType"));
                    command_result.add(util.is_equal(expected_fqdnMode, param.fqdnMode, "fqdnMode"));
                    command_result.add(util.is_equal(expected_fqdnAddr, param.fqdnAddr, "fqdnAddr"));
                    command_result.add(util.is_equal(expected_autoSet, param.autoSet, "autoSet"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://signage/server/get",param);
    }
);

HDSTL.Command("@set_signage_si_server(result, serverIp, serverPort, secureConnection, appLaunchMode, appType, fqdnMode, fqdnAddr, autoSet)",
    function(args) {
        var expected_result = args[9];
        var parameters = {
            "serverIp" : args[1],
            "serverPort" : args[2],
            "secureConnection" : args[3],
            "appLaunchMode" : args[4],
            "appType" : args[5],
            "fqdnMode" : args[6],
            "fqdnAddr" : args[7],
            "autoSet" : args[8]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://signage/server/set",param);
    }
);

HDSTL.Command("@get_tile_mode(result, enabled:bool, row:number, col:number, tileId:number, naturalMode:bool)",
    function(args) {
        var expected_result = args[1];
        var expected_enabled = args[2] === undefined ? "?" : args[2];
        var expected_row = args[3] === undefined ? "?" : args[3];
        var expected_column = args[4] === undefined ? "?" : args[4];
        var expected_tileId = args[5] === undefined ? "?" : args[5];
        var expected_naturalMode = args[6] === undefined ? "?" : args[6];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_enabled, param.enabled, "enabled");
                    command_result.add(util.is_equal(expected_row, param.row, "row"));
                    command_result.add(util.is_equal(expected_column, param.column, "column"));
                    command_result.add(util.is_equal(expected_tileId, param.appType, "tileId"));
                    command_result.add(util.is_equal(expected_naturalMode, param.fqdnMode, "expected_naturalMode"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://signage/tileinfo/get",param);
    }
);

HDSTL.Command("@set_tile_mode(result, enabled, row, column, tileId, naturalMode,)",
    function(args) {
        var expected_result = args[1];
        var parameters = {
            "enabled" : args[2],
            "row" : args[3],
            "column" : args[4],
            "tileId" : args[5],
            "naturalMode" : args[6]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://signage/tileinfo/set",param);
    }
);

HDSTL.Command("@get_storage_info(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://storage/info/get",param);
    }
);

HDSTL.Command("@format_usb(usbName, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "usbName" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://storage/usb/format",param);
    }
);

HDSTL.Command("@set_logo_image(uri, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "uri" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://system/logoimage/set",param);
    }
);

HDSTL.Command("@get_sensor_values(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://system/sensorvalues/get",param);
    }
);

HDSTL.Command("@get_currenttime(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://time/currenttime/get",param);
    }
);

HDSTL.Command("@set_currenttime(ntp, ntpServer, year, month, day, hour, minute, sec, result)",
    function(args) {
        var expected_result = args[9];
        var parameters = {
            "ntp" : args[1],
            "ntpServer" : args[2],
            "year" : args[3],
            "month" : args[4],
            "day" : args[5],
            "hour" : args[6],
            "minute" : args[7],
            "second" : args[8]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://time/currenttime/set",param);
    }
);

HDSTL.Command("@get_holidayschedule(result, name:string, year:number, month:number, date:number, days:number, repeat:string, repeatby:string)",
// does not take array.
    function(args) {
        var expected_result = args[1];
        var expected_name = args[2] === undefined ? "?" : args[2];
        var expected_year = args[3] === undefined ? "?" : args[3];
        var expected_month = args[4] === undefined ? "?" : args[4];
        var expected_date = args[5] === undefined ? "?" : args[5];
        var expected_days = args[6] === undefined ? "?" : args[6];
        var expected_repeat = args[7] === undefined ? "?" : args[7];
        var expected_repeatby = args[8] === undefined ? "?" : args[8];

        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_name, param[0].name, "[0].name");
                        command_result.add(util.is_equal(expected_year, param[0].year, "[0].year"));
                        command_result.add(util.is_equal(expected_month, param[0].month, "[0].month"));
                        command_result.add(util.is_equal(expected_date, param[0].date, "[0].date"));
                        command_result.add(util.is_equal(expected_days, param[0].days, "[0].days"));
                        command_result.add(util.is_equal(expected_repeat, param[0].repeat, "[0].repeat"));
                        command_result.add(util.is_equal(expected_repeatby, param[0].repeatby, "[0].repeatby"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://time/holidayschedule/get",param);
    }
);

HDSTL.Command("@reset_holidayschedule(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://time/holidayschedule/reset",param);
    }
);


HDSTL.Command("@set_holidayschedule(result, holidayScheduleList)",
    function(args) {
        var expected_result = args[1];
        var parameters = {
            "holidayScheduleList" : args[2]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://time/holidayschedule/set",param);
    }
);

HDSTL.Command("@get_timezone(result, continent:string, country:string, city:string)",
    function(args) {
        var expected_result = args[1];
        var expected_continent = args[2] === undefined ? "?" : args[2];
        var expected_country = args[3] === undefined ? "?" : args[3];
        var expected_city = args[4] === undefined ? "?" : args[4];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_continent, param.continent, "continent");
                        command_result.add(util.is_equal(expected_country, param.country, "country"));
                        command_result.add(util.is_equal(expected_city, param.city, "city"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://time/timezone/get",param);
    }
);

HDSTL.Command("@get_timezone_list(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://time/timezone/list",param);
    }
);

HDSTL.Command("@set_timezone(continent, counry, city, result)",
    function(args) {
        var expected_result = args[4];
        var parameters = {
            "continent" : args[1],
            "country" : args[2],
            "city" : args[3]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://time/timezone/set",param);
    }
);

HDSTL.Command("@set_mute(muted, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "muted" : args[1],
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://audio/mute/set",param);
    }
);

HDSTL.Command("@bt_audio_control(command, result)",
    function(args) {
        var expected_result = args[2];
        var parameters = {
            "command" : args[1]
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://network/bluetooth/control",param);
    }
);

HDSTL.Command("@get_usage_time(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = { };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://system/usagetime/get",param);
    }
);

HDSTL.Command("@get_pm_mode_info(result, mode(string))",
    function(args) {
        var expected_result = args[1];
        var expected_mode = args[2] === undefined ? "?" : args[2];
        var parameters = { };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_mode, param.blockedPortList, "mode");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://power/pmmode/get",param);
    }
);


HDSTL.Command("@id_reboot(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {
            "powerCommand" : "reboot",
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://power/command",param);
    }
);

HDSTL.Command("@id_powerOff(result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {
            "powerCommand" : "powerOff",
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://power/command",param);
    }
);

HDSTL.Command("@set_pm_mode_info(mode,result)",
    function(args) {
        var expected_result = args[1];
        var parameters = {
            "mode" : args[1],
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://power/pmmode/set",param);
    }
);




//IDTAF TC  Command

/*
---------------------------
IDCAP Test Command Space
---------------------------

*/



HDSTL.Command("@idcap_soundmode_get(result,soundMode,audioBalance)",
    function(args) {
        var expected_result = args[1],expected_soundMode=args[2],expected_audioBalance=args[3];
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
            function(param){
              var command_result= util.is_equal(expected_soundMode,param.soundMode,"soundMode");
              command_result.add(util.is_equal(expected_audioBalance,param.audioBalance,"audioBalance"));
              HDSTL.setResult(command_result.result, command_result.fail_reason);
              HDSTL.finish();
            }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://audio/soundmode/get",param);
    }
);


HDSTL.Command("@idcap_soundmode_set(soundMode,audioBalance,result)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "parameters":{"soundMode":args[1],"audioBalance":args[2]},
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://audio/soundmode/set",param);
    }
);



HDSTL.Command("@idcap_defaultsoundout_get(result,speakerType)",
    function(args) {
        var expected_result = args[1],expected_speakerType=args[2]
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
            function(param){
              var command_result= util.is_equal(expected_speakerType,param.speakerType,"speakerType");
              return command_result;
            }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://audio/defaultsoundout/get",param);
    }
);


HDSTL.Command("@idcap_defaultsoundout_set(speakerType,result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "parameters":{"speakerType":args[1]},
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://audio/defaultsoundout/set",param);
    }
);

HDSTL.Command("@idcap_soundout_get(result,speakerType)",
    function(args) {
        var expected_result = args[1],expected_speakerType=args[2]
        var param = {
            "onSuccess": HDSTL.checkSuccess(expected_result,
            function(param){
              var command_result= util.is_equal(expected_speakerType,param.speakerType,"speakerType");
              return command_result;
            }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://audio/soundout/get",param);
    }
);


HDSTL.Command("@idcap_soundout_set(speakerType,result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "parameters":{"speakerType":args[1]},
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://audio/soundout/set",param);
    }
);


HDSTL.Command("@idcap_volumelevel_get(result,speakerType,level,muted)",
    function(args) {
        var expected_result = args[1],expected_level=args[3],expected_muted=args[4];
        var param = {
            "parameters":{
              "speakerType":args[2]
            },
            "onSuccess": HDSTL.checkSuccess(expected_result,
            function(param){
              var command_result= util.is_equal(expected_level,param.level,"level");
              command_result.add( util.is_equal(expected_muted,param.muted,"muted"))
              return command_result;
            }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://audio/volumelevel/get",param);
    }
);


HDSTL.Command("@idcap_volumelevel_set(speakerType,level,result,vol)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "parameters":{"speakerType":args[1],"level":args[2],"volOsdEnable":args[4]},
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://audio/volumelevel/set",param);
    }
);

HDSTL.Command("@idcap_mute_set(muted,result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "parameters":{"muted":args[1]},
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://audio/mute/set",param);
    }
);



HDSTL.Command("@idcap_digitalaudioinputmode_set(speakerType,result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "parameters":{"digitalAudioInput":args[1]},
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result,null)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://digitalaudioinputmode/set",param);
    }
);


HDSTL.Command("@screen_capture",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://utility/screen/capture",param);
    }
);

//byeongho
//-----------------------------------//
HDSTL.Command("@tts_speak(text,langauge,result)",
    function(args) {
        var text = args[1];
        var lang = args[2];
        var expected_result = args[3];
        var parameters = {
            "text":text,
            "language":lang
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://system/speech/tts/speak",param);
    }
);

HDSTL.Command("@tts_availablelist(result)",
    function(args) {

        var expected_result = args[1];
        var parameters = {
        };
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://system/speech/tts/availablelist/get",param);
    }
);


//-----------------------------------bh_end//


//hw.cho
//-----------------------------------//
HDSTL.Command("@get_beacon_info(result:number, beacon_mode:bool, beacon_type:string, iBeacon_uuid:string, iBeacon_major:number, iBeacon_minor:number, eddystone_uuid:string, eddystone_frame:string, eddystone_prefix:string, eddystone_excode:string, eddystone_url:string)",
	function(args) {
        var expected_result = args[1],
        	expected_beacon_mode = args[2],
        	expected_beacon_type = args[3],
        	expected_iBeacon_uuid = args[4],
        	expected_iBeacon_major = args[5],
        	expected_iBeacon_minor = args[6],
        	expected_eddystone_uuid = args[7],
        	expected_eddystone_frame = args[8],
        	expected_eddystone_prefix = args[9],
        	expected_eddystone_excode = args[10],
        	expected_eddystone_url = args[11];
        var _params = {
            "parameters" : {},
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_beacon_mode, param.beaconMode, "beaconMode");
                    command_result.add(util.is_equal(expected_beacon_type, param.beaconType, "beaconType"));
                    command_result.add(util.is_equal(expected_iBeacon_uuid, param.iBeaconUuid, "iBeaconUuid"));
                    command_result.add(util.is_equal(expected_iBeacon_major, param.iBeaconMajor, "iBeaconMajor"));
                    command_result.add(util.is_equal(expected_iBeacon_minor, param.iBeaconMinor, "iBeaconMinor"));
                    command_result.add(util.is_equal(expected_eddystone_uuid, param.eddyStoneUuid, "eddyStoneUuid"));
                    command_result.add(util.is_equal(expected_eddystone_frame, param.eddyStoneFrame, "eddyStoneFrame"));
                    command_result.add(util.is_equal(expected_eddystone_prefix, param.eddyStoneUrlPrefix, "eddyStoneUrlPrefix"));
                    command_result.add(util.is_equal(expected_eddystone_excode, param.eddyStoneUrlExCode, "eddyStoneUrlExCode"));
                    command_result.add(util.is_equal(expected_eddystone_url, param.eddyStoneUrl, "eddyStoneUrl"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        }
        htaf_log(make_htaf_log("[Test Args - beacon/get]", args));
        idcap.request("idcap://network/beacon/get",_params);
    }
);
HDSTL.Command("@set_beacon_info_ibeacon(result:number, beacon_mode:bool, beacon_type:string, iBeacon_uuid:string, iBeacon_major:number, iBeacon_minor:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "beaconMode": args[2],
            "beaconType": args[3],
            "iBeaconUuid": args[4],
            "iBeaconMajor": args[5],
            "iBeaconMinor": args[6]
        };
        var _params = {
            "parameters" : param,
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        }

        htaf_log(make_htaf_log("[Test Args - beacon/set-ibeacon]", args));
        idcap.request("idcap://network/beacon/set",_params);
    }
);
HDSTL.Command("@get_beacon_info_ibeacon(result:number, beacon_mode:bool, beacon_type:string, iBeacon_uuid:string, iBeacon_major:number, iBeacon_minor:number)",
	function(args) {
        var expected_result = args[1],
        	expected_beacon_mode = args[2],
        	expected_beacon_type = args[3],
        	expected_iBeacon_uuid = args[4],
        	expected_iBeacon_major = args[5],
        	expected_iBeacon_minor = args[6]
        var _params = {
            "parameters" : {},
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_beacon_mode, param.beaconMode, "beaconMode");
                    command_result.add(util.is_equal(expected_beacon_type, param.beaconType, "beaconType"));
                    command_result.add(util.is_equal(expected_iBeacon_uuid, param.iBeaconUuid, "iBeaconUuid"));
                    command_result.add(util.is_equal(expected_iBeacon_major, param.iBeaconMajor, "iBeaconMajor"));
                    command_result.add(util.is_equal(expected_iBeacon_minor, param.iBeaconMinor, "iBeaconMinor"))
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        }
        htaf_log(make_htaf_log("[Test Args - beacon/get-ibeacon]", args));
        idcap.request("idcap://network/beacon/get",_params);
    }
);

HDSTL.Command("@set_beacon_info_eddystone(result:number, beacon_mode:bool, beacon_type:string, iBeacon_uuid:string, iBeacon_major:number, iBeacon_minor:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "beaconMode": args[2],
            "beaconType": args[3],
            "eddyStoneFrame": args[4],
            "eddyStoneUrlPrefix": args[4] === "url" ? args[5] : undefined,
            "eddyStoneUrlExCode": args[4] === "url" ? args[6] : undefined,
            "eddyStoneUrl": args[4] === "url" ? args[7] : undefined,
            "eddyStoneUuid": args[4] === "uid" ? args[8] : undefined
        };
        var _params = {
            "parameters" : param,
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        }

        htaf_log(make_htaf_log("[Test Args - beacon/set-eddystone]", args));
        idcap.request("idcap://network/beacon/set",_params);
    }
);
HDSTL.Command("@get_beacon_info_eddystone(result:number, beacon_mode:bool, beacon_type:string, eddystoneFrame:string, iBeacon_major:number, iBeacon_minor:number)",
	function(args) {
        var expected_result = args[1],
        	expected_beacon_mode = args[2],
            expected_beacon_type = args[3],
            expected_eddystone_frame = args[4],
        	expected_eddystone_uuid = args[5],
        	expected_eddystone_prefix = args[6],
        	expected_eddystone_excode = args[7],
            expected_eddystone_url = args[8];

        var _params = {
            "parameters" : {},
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_beacon_mode, param.beaconMode, "beaconMode");
                    command_result.add(util.is_equal(expected_beacon_type, param.beaconType, "beaconType"));
                    command_result.add(util.is_equal(expected_eddystone_frame, param.eddyStoneFrame, "eddyStoneFrame"));
                    if (expected_eddystone_frame === "uid") {
                        command_result.add(util.is_equal(expected_eddystone_uuid, param.eddyStoneUuid, "eddyStoneUuid"));
                    } else {
                        command_result.add(util.is_equal(expected_eddystone_prefix, param.eddyStoneUrlPrefix, "eddyStoneUrlPrefix"));
                        command_result.add(util.is_equal(expected_eddystone_excode, param.eddyStoneUrlExCode, "eddyStoneUrlExCode"));
                        command_result.add(util.is_equal(expected_eddystone_url, param.eddyStoneUrl, "eddyStoneUrl"));
                    }

                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        }
        htaf_log(make_htaf_log("[Test Args - beacon/-eddystone]", args));
        idcap.request("idcap://network/beacon/get",_params);
    }
);


HDSTL.Command("@set_network_config(wired_enable:bool, wired_dhcp:bool, wifi_enable:bool, wifi_dhcp:bool, result:number , wired_ip, wired_sbnmask, wired_gtw, wired_dns1,wired_dns2,wifi_ip,wifi_sbnmask, ,wifi_gtw, ,wifi_dns1, ,wifi_dns2)",
// wired_enable , wired_dhcp , wifi_enable, wifi_dhcp, expected_RESULT, ----args[1~5]
// wired_ip, wired_sbnmask, wired_gtw, wired_dns1,wired_dns2, ----args[6~10]
// wifi_ip,wifi_sbnmask, ,wifi_gtw, ,wifi_dns1, ,wifi_dns2 ----args[11~15]
    function(args) {
        var expected_result = args[8];
        var param = null;
        if (args[1] === true && args[3] === true) {

            if (args[2] === true && args[4] === true){
                // wired on / wifi on / both DHCP on
                param = {
                    "wired": {
                        "enabled": args[1],
                        "dhcp": args[2]
                    },
                    "wifi": {
                        "enabled": args[3],
                        "dhcp": args[4]
                    }
                };
            } else if (args[2] === true && args[4] === false){
                // wired on / wifi on / wired_dhcp on / wifi-manual setup
                param = {
                    "wired": {
                        "enabled": args[1],
                        "dhcp": args[2]
                    },
                    "wifi": {
                        "enabled": args[3],
                        "dhcp": args[4],
                        "ipAddress": args[11],
                        "netmask": args[12],
                        "gateway": args[13],
                        "dns1": args[14],
                        "dns2": args[15],
                    }
                };
            } else if (args[2] === false && args[4] === true){
                // wired on / wifi on / wired-manual setup / wifi_dhcp_on
                param = {
                    "wired": {
                        "enabled": args[1],
                        "dhcp": args[2],
                        "ipAddress": args[6],
                        "netmask": args[7],
                        "gateway": args[8],
                        "dns1": args[9],
                        "dns2": args[10],
                    },
                    "wifi": {
                        "enabled": args[3],
                        "dhcp": args[4]
                    }
                };
            } else {
                // wired on / wifi on / wired-manual setup / wifi-manual setup
                param = {
                    "wired": {
                        "enabled": args[1],
                        "dhcp": args[2],
                        "ipAddress": args[6],
                        "netmask": args[7],
                        "gateway": args[8],
                        "dns1": args[9],
                        "dns2": args[10],
                    },
                    "wifi": {
                        "enabled": args[3],
                        "dhcp": args[4],
                        "ipAddress": args[11],
                        "netmask": args[12],
                        "gateway": args[13],
                        "dns1": args[14],
                        "dns2": args[15],
                    }
                };
            }
        } else if (args[1] === true && args[3] === false) {
            // wired on / wifi false / both DHCP on
            if (args[2] === true){
                // wired on / wifi false / wired DHCP on
                param = {
                    "wired": {
                        "enabled": args[1],
                        "dhcp": args[2]
                    },
                    "wifi": {
                        "enabled": args[3]
                    }
                };
            } else {
                // wired on / wifi false / wired-manual setup
                param = {
                    "wired": {
                        "enabled": args[1],
                        "dhcp": args[2],
                        "ipAddress": args[6],
                        "netmask": args[7],
                        "gateway": args[8],
                        "dns1": args[9],
                        "dns2": args[10],
                    },
                    "wifi": {
                        "enabled": args[3]
                    }
                };
            }
        } else if (args[1] === false && args[3] === true) {
            // wired false / wifi on /
            if (args[4] === true){
                // wired false / wifi on / wifi DHCP on
                param = {
                    "wired": {
                        "enabled": args[1],
                    },
                    "wifi": {
                        "enabled": args[3],
                        "dhcp": args[4]
                    }
                };
            } else {
                // wired false / wifi on / wifi-manual setup
                param = {
                    "wired": {
                        "enabled": args[1]
                    },
                    "wifi": {
                        "enabled": args[3],
                        "dhcp": args[4],
                        "ipAddress": args[11],
                        "netmask": args[12],
                        "gateway": args[13],
                        "dns1": args[14],
                        "dns2": args[15],
                    }
                };
            }
        } else {
            // wired false / wifi false /
            param = {
                "wired": {
                    "enabled": args[1]
                },
                "wifi": {
                    "enabled": args[3]
                }
            };
        }

        var expected_result = args[5];
        var _params = {
            "parameters" : param,
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        }

        htaf_log(make_htaf_log("[Test Args] - config/set", args));
        idcap.request( "idcap://network/configuration/set" , _params);
    }
);


HDSTL.Command("@get_network_config(result, wired-enabled, wired-dhcp, wifi-enable, wifi-dhcp)",
    function(args) {
        var expected_result = args[1];
        var expected_wired_enabled = args[2];
        var expected_wired_dhcp = args[3];
        var expected_wifi_enabled = args[4];
        var expected_wifi_dhcp = args[5];
/*
                event_name = "idcap::network_event_received",
                event_listener = function eventListener(param) {
                    //HDSTL.removeEvent(event_name, event_listener)();
                    htaf_log(make_htaf_log(event_name, param));
                    //var command_result = util.is_equal("?", param.event, "network event");
                    //HDSTL.setResult(command_result.result, command_result.fail_reason);
                    //HDSTL.finish();
                };
*/      var isEnabled = (object) => {

            var wifi_result = false;
            var wired_result = false;
            console.log ("----------222222222---------");
            console.log (object);
            console.log ("----------222222222------------");
            if (object.hasOwnProperty("wifi")) {
                if (expected_wifi_enabled === true && object.wifi.dhcp !== undefined && object.wifi.dhcp !== null){
                    console.log ("-1-");
                    if (object.wifi.dhcp === expected_wifi_dhcp) {
                        console.log ("-0-");
                        wifi_result = true;
                    }
                } else if (expected_wifi_enabled === false && (object.wifi.dhcp === undefined || object.wifi.dhcp === null)) {
                    console.log ("-2-");
                    wifi_result = true;
                }
            }

            if (object.hasOwnProperty("wired")) {
                if (expected_wired_enabled === true && object.wired.dhcp !== undefined && object.wired.dhcp !== null){
                    console.log ("-4-");
                    if (object.wired.dhcp === expected_wired_dhcp) {
                        console.log ("-3-");
                        wired_result = true;
                    }
                    console.log ("-5-");
                } else if (expected_wired_enabled === false && (object.wired.dhcp === undefined || object.wired.dhcp === null)) {
                    console.log ("-6-");
                    wired_result = true;
                }
            }

            if ( wifi_result && wired_result ){
                console.log ("-7-");
                return true;
            } else {
                console.log ("-8-");
                return false;
            }
        };
        // console.log ("--------------------------------");
        // console.log (args[2]);
        // console.log (args[3]);
        // console.log (args[4]);
        // console.log (args[5]);
        // console.log ("--------------------------------");
        var _params = null;
        if ( args[2] !== undefined && args[3] !== undefined && args[4] !== undefined && args[5] !== undefined ){
            // console.log('check--------------');
            _params = {
                "parameters": {},
                "onSuccess": function (param) {
                    var command_result = isEnabled(param);
                    // console.log("-0- -- expected_result ", expected_result);
                    // console.log("-0- -- command_result ", command_result);
                    if (expected_result === command_result){
                        HDSTL.setResult(true, "onSuccess is Called.");
                    } else {
                        HDSTL.setResult(false, "Return exists but, value is diff.");
                    }
                    HDSTL.finish();
                },
                "onFailure": HDSTL.checkFailure(expected_result)
            };
        } else {
            // console.log('NONE - check--------------');
            _params = {
                "parameters": {},
                "onSuccess": HDSTL.checkSuccess(expected_result,null),
                "onFailure": HDSTL.checkFailure(expected_result)
            };
        }

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request( "idcap://network/configuration/get" , _params);
    }
);

HDSTL.Command("@ping(hostname, result, round_trip_time_in_ms )",
    function(args) {
        var hostname = args[1], expected_result = args[2], expected_round_trip_time = args[3];

        var _params = {
            "parameters": {
                "hostname": hostname
            },
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_round_trip_time, param.roundTripTimeInMs, "roundTripTimeInMs");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request( "idcap://network/ping" , _params);
    }
);


HDSTL.Command("@get_blocked_port_list(result:number)",
    function(args) {
        var expected_result = args[1];
        var _params = {
            "parameters" : {},
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(prefix.DONT_CARE, param.blockedPortList, "blockedPortList");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request( "idcap://network/portblocklist/get" , _params);
    }
);

HDSTL.Command("@set_blocked_port_list(port:number, result:number)",
    function(args) {
        var expected_result = args[2];
        var num = args[1];

        if(num == "0") {
            var _params = {
                "parameters" : {
                    "blockedPortList":[]
                },
                "onSuccess": HDSTL.checkSuccess(expected_result, null),
                "onFailure": HDSTL.checkFailure(expected_result)
            };

            htaf_log(make_htaf_log("[Test Args]", args));
            idcap.request( "idcap://network/portblocklist/set" , _params);
        }
        else {
            var _params = {
                "parameters" : {
                    "blockedPortList":[{"blockedPort":"33252", "protocol":"tcp", "direction":"all"},{"blockedPort":"33322", "protocol":"tcp", "direction":"in"},{"blockedPort":"53422", "protocol":"udp", "direction":"out"}],
                },
                "onSuccess": HDSTL.checkSuccess(expected_result, null),
                "onFailure": HDSTL.checkFailure(expected_result)
            };

            htaf_log(make_htaf_log("[Test Args]", args));
            idcap.request( "idcap://network/portblocklist/set" , _params);
        }
    }
);

HDSTL.Command("@set_proxy_server(enabled:bool, ipAddress:string, port:number, userName, password, result:number)",
    function(args) {
        var expected_result = args[6];
        var _params = {
            "parameters" : {
                "enabled":args[1],
                "ipAddress":args[2],
                "port":args[3],
                "userName":args[4],
                "password":args[5],
            },
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request( "idcap://network/proxy/set" , _params);
    }
);

HDSTL.Command("@get_proxy_server(result:number, enabled:bool, ip:string, port:number)",
    function(args) {
        var expected_result = args[1];
        var expected_enabled = args[2] !== '?' ? Boolean(args[2]) : "?";
        var expected_ip = args[3] !== '?' ? args[3] : "?";
        var expected_port = args[4] !== '?' ? args[4] : "?";
        console.log(" expected_result type - " + typeof(expected_result));
        console.log(" expected_enabled type - " + typeof(expected_enabled));
        console.log(" expected_ip type - " + typeof(expected_ip));
        console.log(" expected_port type - " + typeof(expected_port));
        htaf_log(make_htaf_log("[Test Args]", args));
        var _params = {
            "parameters" : {},
            "onSuccess": (param) => {
                console.log("--------------onSuccess type - " + JSON.stringify(param));
                var command_result;
                console.log("--------------onSuccess expected_enabled " + JSON.stringify(expected_enabled));
                if (expected_enabled === "?") {
                    // console.log('expected_enable  =  ? -->' , expected_enabled);
                    // var _results = HDSTL.checkSuccess(expected_result,null);
                    // console.log('_results : ', JSON.stringify(_results));
                    HDSTL.setResult(true, "onSuccess is Called.");
                } else {
                    console.log('expected_enable --> ' , expected_enabled);
                    // util.is_equal(expected_enabled, param.enabled, "enabled");
                    if (expected_enabled === param.enabled){
                        if (expected_enabled) {
                            if (expected_ip === param.ipAddress && expected_port === param.port){
                                HDSTL.setResult(true, "onSuccess is Called.");
                            } else {
                                HDSTL.setResult(false, "Returned is differ from expected.");
                            }
                        } else {
                            HDSTL.setResult(true, "onSuccess is Called.");
                        }
                    } else {
                        HDSTL.setResult(false, "Enabled is different.");
                    }
                    // HDSTL.checkSuccess(expected_result,command_result);
                }
                HDSTL.finish();
            },
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        idcap.request( "idcap://network/proxy/get" , _params);
    }
);

HDSTL.Command("@get_checkupinfo(result, mode:string, url:string)",
    function(args) {
        var expected_result = args[1];
        var expected_mode = args[2];
        var expected_url = args[3];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": function result(param) {
                if (args[2] === undefined && args[3] === undefined){
                    HDSTL.checkSuccess(expected_result, null);
                } else if (args[2] !== undefined && args[3] === undefined) {
                    if (param.mode === expected_mode){
                        HDSTL.setResult(true, "onSuccess is Called.");
                    } else {
                        HDSTL.setResult(false, "expected Result is different.");
                    }
                } else {
                    if (param.mode === expected_mode && param.url === expected_url){
                        HDSTL.setResult(true, "onSuccess is Called.");
                    } else {
                        HDSTL.setResult(false, "expected Result is different.");
                    }
                }
                HDSTL.finish();
            },
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://network/checkupinfo/get",param);
    }
);


HDSTL.Command("@set_checkupinfo(result , mode:string, url:string)",
    function(args) {
        var expected_result = args[1];
        var _mode = args[2];
        var _url = args[3];
        var _params = {
            "parameters" : {
                "mode":_mode,
                "url":_url
            },
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request( "idcap://network/checkupinfo/set" , _params);
    }
);

HDSTL.Command("@set_idcap_property(key, value, result, expected_key, expected_value)",
    function(args) {
        var expected_result = args[3],
            expected_key = args[4],
            event_name = "property_changed",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));
                var command_result = util.is_equal(expected_key, param.key, "key ");
                HDSTL.setResult(command_result.result, command_result.fail_reason);
                HDSTL.finish();
            };

        var _params = {
            "parameters" :{
            "key": args[1],
            "value": args[2]
            },
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))

        };

        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request( "idcap://configuration/property/set" , _params);
    }
);


HDSTL.Command("@get_idcap_property(key, result, expected_value)",
    function(args) {
        var key = args[1], expected_result = args[2], expected_value = args[3];
        var _params = {
            "parameters" :{
            "key": key
            },
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_value, param.value, "value");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request( "idcap://configuration/property/get" , _params);
    }
);


HDSTL.Command("@get_idcap_application_list(result:number, list_length:number, id_0:string, title_0:string, icon_file_path_0:string)",
    function(args) {
        var expected_result = args[1],
        		expected_list_length = args[2],
        		expected_id_0 = args[3],
        		expected_title_0 = args[4],
        		expected_icon_file_path_0 = args[5];

        var param = {
            "parameters" :{},
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    if (param.list) {
                        for (var i = 0; i < param.list.length; i++) {
                            print_msg("list[" + i + "] id = " + param.list[i].appId + ", title = " + param.list[i].title + ", iconFilePath = " + param.list[i].iconFilePath + " <img src='" + param.list[i].iconFilePath + "' height=32 width=32/>");
                        }
                    }
                	var command_result = util.is_equal(expected_list_length, param.list.length, "list length");
                	command_result.add(util.is_equal(expected_id_0, param.list[0].appId, "list[0].id"));
                	command_result.add(util.is_equal(expected_title_0, param.list[0].title, "list[0].title"));
                	command_result.add(util.is_equal(expected_icon_file_path_0, param.list[0].iconFilePath, "list[0].iconFilePath"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request( "idcap://application/applist/get" , param);
    }
);


HDSTL.Command("@launch_idcap_application(id:string, result:number)",
    function(args) {
        var expected_result = args[2];

        var param = {
            "parameters" :{
                "id":args[1]
            },
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://application/htv/launch" , param);
    }
);

HDSTL.Command("@launch_idcap_application_with_parameters(id:string, parameters:string, result:number)",
    function(args) {
        var expected_result = args[3];

        var param = {
            "parameters" :{
            "id":args[1],
            "parameters":args[2]
            },
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://application/htv/launch" , param);
    }
);


HDSTL.Command("@destroy_idcap_application(id:string, result:number)",
    function(args) {
        var expected_result = args[2];

        var param = {
            "parameters":{
            "id":args[1]
            },
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        //hcap.preloadedApplication.destroyPreloadedApplication(param);
        idcap.request("idcap://application/destroy" , param);
    }
);

HDSTL.Command("@get_idcap_service_xml(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "parameters " : {},
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(prefix.DONT_CARE, param.contents, "contents");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://application/servicexml/get" , param);
    }
);

HDSTL.Command("@get_idcap_defaultservice_xml(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "parameters " : {},
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(prefix.DONT_CARE, param.contents, "contents");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://application/defaultservicexml/get" , param);
    }
);

HDSTL.Command("@launch_idcap_html_application(expected_result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "parameters " : {},
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://application/htmlapplication/launch" , param);
    }
);


HDSTL.Command("@set_idcap_video_mute(mute, result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "parameters" : {
                "videoMute": args[1],
            },
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://video/mute/set" , param);
    }
);

HDSTL.Command("@get_idcap_video_mute( result, mute)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "parameters" : { },
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://video/mute/get" , param);
    }
);



HDSTL.Command("@get_idcap_video_size(result, x, y, width, height)",
    function(args) {
        var expected_result = args[1], x = args[2], y = args[3], width = args[4], height =args[5];
        var param = {
            "parameters" : { },
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(x, param.x, "x");
                    command_result.add(util.is_equal(y, param.y, "y"));
                    command_result.add(util.is_equal(width, param.width, "width"));
                    command_result.add(util.is_equal(height, param.height, "height"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://video/size/get" , param);
    }
);


HDSTL.Command("@set_idcap_video_size(x:number, y:number, width:number, height:number, result)",
    function(args) {
        var expected_result = args[5];
        var param = {
            "parameters" : {
                "x": args[1],
                "y": args[2],
                "width": args[3],
                "height": args[4],
            },
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://video/size/set" , param);
    }
);


HDSTL.Command("@get_idcap_external_input_list(result)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "parameters" : { },
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(prefix.DONT_CARE, param.inputSourceList.length, "list");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://externalinput/inputlist/get" , param);
    }
);

HDSTL.Command("@set_idcap_external_input(input_type, input_index, result)",
    function(args) {
        var expected_result = args[3],
            event_name = "idcap::external_input_changed",
            event_listener = function eventListener(param) {
                HDSTL.removeEvent(event_name, event_listener)();
                htaf_log(make_htaf_log(event_name, param));
                HDSTL.setResult(true, event_name + " event received");
                HDSTL.finish();
            },
            media_hub_event_name = "idcap::media_hub_event_received",
            media_hub_event_listener = function mediaHubEventListener(param) {
                HDSTL.removeEvent(media_hub_event_name, media_hub_event_listener)();
                htaf_log(make_htaf_log(media_hub_event_name, param));
                HDSTL.setResult(true, media_hub_event_name + " event received");
                HDSTL.finish();
            };

        var param = {
            "parameters" : {
            "type": args[1],
            "index": args[2],
            },
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };

        HDSTL.addEvent(event_name, event_listener)();
        HDSTL.addEvent(media_hub_event_name, media_hub_event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://externalinput/set" , param);
    }
);

HDSTL.Command("@get_idcap_external_input(result, input_type, input_index)",
    function(args) {
        var expected_result = args[1], expected_source_type = args[2], expected_source_index = args[3];
        var param = {
            "parameters" : { },
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_source_type, param.type , "type");
                    command_result.add(util.is_equal(expected_source_index, param.index, "index"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://externalinput/get" , param);
    }
);


HDSTL.Command("@idcap_show_toast_message(message:string, result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "parameters" : {
            "msg":args[1],
            },
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://utility/toastmsg/create" , param);
    }
);


HDSTL.Command("@idcap_screen_capture",
    function(args) {
        var expected_result = args[1];
        var parameters = {};
        var param = {
            "parameters" : parameters,
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://utility/screen/capture",param);
    }
);

HDSTL.Command("@set_idcap_usb_power_control(port_number:number, status:bool, result:number)",
    function(args) {
        var expected_result = args[3];
        var param = {
            "parameters" : {
            "portNumber":args[1],
            "status":args[2],},
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://utility/usbpowercontrol/set" , param);
    }
);

HDSTL.Command("@get_idcap_usb_power_control(port_number:number, result:number, status:bool)",
    function(args) {
        var port_number = args[1],
            expected_result = args[2],
            expected_status = args[3];

        var param = {
            "parameters" : {
            "portNumber":port_number,
            },
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_status, param.status, "status");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://utility/usbpowercontrol/get" , param);
    }
);



HDSTL.Command("@get_idcap_hotel_mode(result:number)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "parameters" : {},
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(prefix.DONT_CARE, param.hotelMode, "hotelMode");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://configuration/hotelmode/get" , param);
    }
);


HDSTL.Command("@set_idcap_hotel_mode(hotelMode, result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "parameters" : {
            "hotelMode":args[1],
            },
            "onSuccess": HDSTL.checkSuccess(expected_result,null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://configuration/hotelmode/set" , param);
    }
);


HDSTL.Command("@set_idcap_mw_mode(idcap_mode:number, result)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "parameters" : {
            "mode": args[1],
            },
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://configuration/idcapmode/set" , param);
    }
);

HDSTL.Command("@get_idcap_mw_mode(result,idcap_mode:number)",
    function(args) {
        var expected_result = args[1], expected_mw_mode = args[2];
        var param = {
            "parameters" : {},
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_mw_mode, param.mode, "mw_mode");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://configuration/idcapmode/get" , param);
    }
);



HDSTL.Command("@set_idcap_installer_menu_item(key, value:number, expected_result:number)",
    function(args) {
        var property_key = args[1],
            property_value = args[2],
            expected_result = args[3];

        var param = {
            "parameters" : {
            "key":property_key,
            "value":property_value,
            },
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://configuration/installermenuitem/set" , param);
    }
);


HDSTL.Command("@get_idcap_installer_menu_item(key , result, expected_value:number)",
    function(args) {
        var property_key = args[1],
            expected_result = args[2],
            expected_value = args[3];
        var params = {
            "parameters" : {
            "key": property_key,
            },
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_value, param.value, "property_value");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://configuration/installermenuitem/get" , params);
    }
);

HDSTL.Command("@get_idcap_locale_list(result:number, specifier:string, language:string, country:string)",
    function(args) {
        var expected_result = args[1],
        		expected_specifier = args[2],
        		expected_language = args[3],
        		expected_country = args[4];

        var param = {
            "parameters" : {},
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
            		if (param.list.length > 0) {
            			htaf_log("list[0] : specifier = " + param.list[0].specifier + ", language = " + param.list[0].language + ", country = " + param.list[0].country);
            		}
                	var command_result = util.is_equal(expected_specifier, param.list[0].specifier, "list[0].specifier");
                	command_result.add(util.is_equal(expected_language, param.list[0].language, "list[0].language"));
                	command_result.add(util.is_equal(expected_country, param.list[0].country, "list[0].country"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://configuration/locale/list" , param);
    });

HDSTL.Command("@request_idcap_locale_change(specifier:string, result:number, event_specifier:string, event_result:number)",
    function(args) {
		var command_result = true;
        var expected_result = args[2],
        		event_specifier = args[3],
        		event_result = args[4],
	            event_name = "idcap::locale_changed",
	            event_listener = function eventListener(param) {
	                HDSTL.removeEvent(event_name, event_listener)();
	                htaf_log(make_htaf_log(event_name, param));
	                command_result.add(util.is_equal(event_specifier, param.specifier, "specifier"));
                	command_result.add(util.is_equal(event_result, param.result, "change_result"));
	                HDSTL.setResult(command_result.result, command_result.fail_reason);
	                HDSTL.finish();
	            };
        var param = {
            "parameters" : {
            "specifier": args[1],
            },
            "onSuccess": HDSTL.checkSuccess2(expected_result, null, HDSTL.removeEvent(event_name, event_listener)),
            "onFailure": HDSTL.checkFailure2(expected_result, null, HDSTL.removeEvent(event_name, event_listener))
        };

        HDSTL.addEvent(event_name, event_listener)();
        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://configuration/locale/set" , param);
    }
);

HDSTL.Command("@get_idcap_locale(result:number, specifier:string, language:string, country:string)",
    function(args) {
        var expected_result = args[1],
        		expected_specifier = args[2],
        		expected_language = args[3],
        		expected_country = args[4];
        var param = {
            "parameters" : {},
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(expected_specifier, param.specifier, "specifier");
                	command_result.add(util.is_equal(expected_language, param.language, "language"));
                	command_result.add(util.is_equal(expected_country, param.country, "country"));
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://configuration/locale/get" , param);
    }
);

HDSTL.Command("@get_idcap_picture_mode(result:number,picture_mode:string)",
    function(args) {
        var expected_result = args[1];
        var param = {
            "parameters" : {},
            "onSuccess": HDSTL.checkSuccess(expected_result,
                function(param) {
                    var command_result = util.is_equal(args[2], param.mode, "pictureMode");
                    return command_result;
                }),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://configuration/picturemode/get" , param);
    }
);

HDSTL.Command("@set_idcap_picture_mode(picture_mode:string,result:number)",
    function(args) {
        var expected_result = args[2];
        var param = {
            "parameters" : {
            "mode": args[1],
            },
            "onSuccess": HDSTL.checkSuccess(expected_result, null),
            "onFailure": HDSTL.checkFailure(expected_result)
        };

        htaf_log(make_htaf_log("[Test Args]", args));
        idcap.request("idcap://configuration/picturemode/set" , param);
    }
);
//-----------------------------------//
