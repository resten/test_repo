var	current_selection = 1;
$("document").ready(function() {
	$(document).keydown(function(e) {
		console.log('dsfsdfsdf33333333333333');
		var ul_menu = document.getElementById('ul_menu');
		var l = ul_menu.getElementsByTagName('li').length;

		document.getElementById('li_' + current_selection).style.background =
		    "url(images/list-bg.png) repeat-x";
		switch (e.keyCode) {
			case 38: // keyup
				if(current_selection === 1){
					current_selection = l;
				}else{
					current_selection = current_selection - 1;
				}
				break;
			case 40: //keydown
				if(current_selection === l){
					current_selection = 1;
				}else{
					current_selection = current_selection + 1;
				}
				break;
			case 13: //enter
				{
					console.log('--------------1-----model_array[current_selection-1] : '+model_array[current_selection-1]);
					if( model_array[current_selection-1] === "16. IDCAP_Manual_test"){
						window.location = "http://10.186.118.208:4005/pbt/idcap/index.html";
					} else {
						window.location = "testcase_list.html#" +
						model_list_parser_.get_testcase_file_path(
							   model_array[current_selection-1]) ;
					}

				}
		}
		document.getElementById('li_' + current_selection).style.background=
		    "url(images/list-bg-hover.png) repeat-x";
	});
});
var lines;
function read_model_list_file(){
	console.log('sdfsdfsdf');
	var xmlhttp;

	if (window.XMLHttpRequest) {//code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	} else {// code for IE6, IE5
		try {
			xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try {
				xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e) {
			xmlhttp = false;
			}
		}
		//xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function(){
		if (xmlhttp.readyState === 4 ){ //&& xmlhttp.status==200
			var raw_text = xmlhttp.responseText;
			process_model_list(raw_text);
			//lines = raw_text.split("\n");
		}
	}
	xmlhttp.open("GET","model_list.txt",true);
	xmlhttp.send();
}
var util = new utils();
var model_array = new Array();
var model_list_parser_;
function process_model_list(raw_text){
	console.log('sdfsdfsaaaaaaaaaaadf');
	model_list_parser_ = new model_list_parser();
	model_list_parser_.parse_model_list_file(raw_text);
	model_array = model_list_parser_.get_model_list();
	console.log('--model-list = ' + JSON.stringify(model_array));
	display_model_list();
}
function display_model_list(){
	for(var i = 1; i <= model_array.length; i++){
		console.log('--model-list 11= ' + JSON.stringify(model_array));
		console.log('--model-list [i]= ' + JSON.stringify(model_array[i-1]));
		var ul_elm = document.getElementById("ul_menu");
		var li_elm = document.createElement("li");
		li_elm.setAttribute("id", "li_" + i);
		ul_elm.appendChild(li_elm);

		var link = document.createElement('a');
		if ( model_array[i-1] === "16. IDCAP_Manual_test" ){
			console.log('--model-list 22= ' + JSON.stringify(model_array));
			console.log('--------------2-----model_array[current_selection-1] : '+model_array[current_selection-1]);
			link.setAttribute("href", "http://10.186.118.208:4005/pbt/idcap/index.html" );
	  		link.setAttribute("id", "a_" + i);
		} else {
			console.log('--model-list 33= ' + JSON.stringify(model_array));
			link.setAttribute("href", "testcase_list.html#"+ model_list_parser_.
			get_testcase_file_path(model_array[i-1]) );
	  		link.setAttribute("id", "a_" + i);
		}


		li_elm.appendChild(link);
		var strong = document.createElement("strong");
		strong.innerHTML = "&nbsp;&nbsp;&nbsp;&nbsp;" + model_array[i-1];
		link.appendChild(strong);

	}

	document.getElementById("li_" + current_selection).style.background =
	    "url(images/list-bg-hover.png) repeat-x";
	show_htaf_version();
}
function show_htaf_version(){

	$("#version").html("<b>HTAF Version : " + VERSION + ", SDK Version : " + hcap.API_VERSION + "</b>");
}


restartTimer();