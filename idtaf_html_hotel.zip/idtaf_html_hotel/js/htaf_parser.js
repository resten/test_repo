function prefixes () {}
prefixes.prototype.CELL_DELIMITER = ',';
prefixes.prototype.PREFIX_DEFINE = "$";
prefixes.prototype.PREFIX_COMMENT = "//";
prefixes.prototype.PREFIX_TESTCASE = ">";
prefixes.prototype.PREFIX_COMMAND = "@";
prefixes.prototype.DONT_CARE = "?";

function testcase() {
    this.title = "";
    this.list_of_command_string = new Array();
    this.list_of_command_element_list = new Array();

    this.set_title = function(title) {
        this.title = title;
    };

    this.get_title = function() {
        return this.title;
    };

    this.add_command = function(commandString, commandElementList) {
        var commandIndex = this.list_of_command_string.length;
        this.list_of_command_string[commandIndex] = commandString;
        this.list_of_command_element_list[commandIndex] = commandElementList;
    };

    this.get_list_of_command_string = function() {
        return this.list_of_command_string;
    };

    this.get_list_of_command_element_list = function() {
        return this.list_of_command_element_list;
    };

    this.to_string = function() {
        var outputString = "";
        outputString += "title : " +
        title + "\n";
        for ( var i = 0; i < list_of_command_string.length; i++) {
            outputString += "[" +
            i + "]" + list_of_command_string[i] + "\n";
            outputString += "==> " +
            list_of_command_element_list[i] + "\n";
        }
        return outputString;
    };
}

function model_list_parser() {

	this.model_list = new Array();
	this.testcase_file_path_list = new Array();
	
	this.parse_model_list_file = function(raw_data){
		var row_delimiter = 
		    (raw_data.indexOf('\r\n') > -1) ? '\r\n' :
		    (raw_data.indexOf('\r') > -1) ? '\r' : '\n';
        var lines = raw_data.split(row_delimiter);
        for (var i = 0; i < lines.length; i++) {
        	var line = util.trims(lines[i]);
        	if (line === "") {
        		continue;
        	}
        	var item = line.split("=");
        	var model_name = item[0];
        	var testcase_file_path = item[1];
        	this.model_list[this.model_list.length] = model_name;
        	this.testcase_file_path_list[model_name] = testcase_file_path;
        }
	}
	
	this.get_model_list = function(){
		return this.model_list;
	}
	
	this.get_testcase_file_path = function(model_name){
		return this.testcase_file_path_list[model_name];
	}
}

function testcase_parser() {
    this.processing_file_lines = 0;
    this.processing_line = 0;
    this.get_testcase_list = function() {
        return testcase_list;
    };

    this.parse_testcase =
        function(all_text) {
        processing_file_lines = all_text.split("\n");
        var testcase_parsing_count = 0;
        var j = 0;
        processing_line = 0;
        for ( var i = processing_line; i < processing_file_lines.length; i++) {
            var line = util.trims(processing_file_lines[i]);

            if (util.starts_with(
                    line, '>')) { // prefix.PREFIX_TESTCASE)) {
                var columns = util.parse_csv_column(line);
                var columns_length = columns.length;
                var testcase_title = util.trims(columns[0]);
                var testcase_list_index = testcase_list.length;
                var test_case = new testcase();
                test_case.set_title(testcase_title);
                for (i++; i < processing_file_lines.length; i++) {

                    var command_line =
                        util.trims(processing_file_lines[i]);

                    if (util.starts_with(
                            command_line, prefix.PREFIX_TESTCASE)) {
                        i--;
                        break;
                    }

                    if (!util.starts_with(
                            command_line, prefix.PREFIX_COMMAND)) {
                        continue;
                    }

                    // testcase commands
                    var command_element_list =
                        this.parse_command_line(command_line);
                    if (command_element_list === undefined) {
                        continue;
                    }
                    test_case.add_command(
                            command_line, command_element_list);
                } // for
                testcase_list[testcase_list_index] = test_case;
                processing_line = i + 1;
                testcase_parsing_count++;
            }
        }
    };

    this.parse_command_line = function(command_line) {
        var command_element_list = util.parse_csv_column(command_line);
        var resultList = new Array();
        var number_of_command_element = command_element_list.length;

        if (number_of_command_element < 1) {
            hcap_log.log("\n[HCAP_LOG]" + "[ testcase_parser ] " + 
                    "number_of_command_element = " + 
                    number_of_command_element + " < 1 : " + command_line +
                    "\n");
            return undefined;
        }

        resultList[0] = command_element_list[0];
        for ( var i = 1; i < number_of_command_element; i++) {
            resultList[i] = util.evaluate(command_element_list[i]);
        }
        ////alert("neew //alert"+ resultList[1]);
        return resultList;
    };
}

function variable_parser() {

    this.global_config = new Array();
    this.on_load_complete;
    this.processing_file_lines;
    this.processing_line;

    this.processing_task = function(raw_data) {
        processing_file_lines = raw_data.split("\n");
        processing_line = 0;
        var testcase_parsing_count = 0;
        for ( var i = processing_line; i < processing_file_lines.length; i++) {
            this.add_define(processing_file_lines[i]);
            processing_line = i + 1;
            testcase_parsing_count++;
        }
    };

    this.add_define = function(line) {
        line = util.trims(line);
        if (!util.starts_with(line, prefix.PREFIX_DEFINE)) {
            return;
        }

        var columns = util.parse_csv_column(line);
        var columns_length = columns.length;
        if (columns_length < 1) {
            return;
        }

        var key = util.trims(columns[0]);
        var value_list = new Array();
        for ( var i = 1; i < columns_length; i++) {
            value_list[i - 1] = util.evaluate(columns[i]);
        }

        this.put_global_config_value(key, value_list);
    };

    this.get_global_config_value = function(key) {
        var config_value = this.global_config[key];
        if (config_value instanceof Array) {
            if (config_value.length === 1) {
                return config_value[0];
            } else {
                return config_value;
            }
        } else if (config_value === undefined) {
            return undefined;
        }
    };

    this.put_global_config_value = function(key, value) {
        if (this.global_config[key] != undefined) {
        }
        this.global_config[key] = value;
    };
}