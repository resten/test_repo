var prev_hcap_mode;

function register_event_listener(event_name, listener) {
    print_msg("addEventListener(" + event_name + ")");
    document.addEventListener(event_name, listener, false);
}

function idcap_keydown_listener(e) {

    if (!e) {
        e = event;
    }
    var code = (e.keyCode ? e.keyCode : e.which);
    print_msg("[key.Code] keycode : " + code);
    switch(code) {
  /*      
    case hcap.key.Code.NUM_0: print_msg("[hcap.key.Code.NUM_0] keycode = " + code); break;
    case hcap.key.Code.NUM_1: print_msg("[hcap.key.Code.NUM_1] keycode = " + code); break;
    case hcap.key.Code.NUM_2: print_msg("[hcap.key.Code.NUM_2] keycode = " + code); break;
    case hcap.key.Code.NUM_3: print_msg("[hcap.key.Code.NUM_3] keycode = " + code); break;
    case hcap.key.Code.NUM_4: print_msg("[hcap.key.Code.NUM_4] keycode = " + code); break;
    case hcap.key.Code.NUM_5: print_msg("[hcap.key.Code.NUM_5] keycode = " + code); break;
    case hcap.key.Code.NUM_6: print_msg("[hcap.key.Code.NUM_6] keycode = " + code); break;
    case hcap.key.Code.NUM_7: print_msg("[hcap.key.Code.NUM_7] keycode = " + code); break;
    case hcap.key.Code.NUM_8: print_msg("[hcap.key.Code.NUM_8] keycode = " + code); break;
    case hcap.key.Code.NUM_9: print_msg("[hcap.key.Code.NUM_9] keycode = " + code); break;
    case hcap.key.Code.CH_UP: print_msg("[hcap.key.Code.CH_UP] keycode = " + code); break;
    case hcap.key.Code.CH_DOWN: print_msg("[hcap.key.Code.CH_DOWN] keycode = " + code); break;
    case hcap.key.Code.GUIDE: {
        print_msg("[hcap.key.Code.GUIDE] keycode = " + code);
        console.log("window.location.reload(true)");
        window.location.reload(true);
        break;
    }
    case hcap.key.Code.INFO: {
        print_msg("[hcap.key.Code.INFO] keycode = " + code);
        console.log("hcap.system.launchHcapHtmlApplication({})");
        hcap.system.launchHcapHtmlApplication({});
        break;
    }
    case hcap.key.Code.LEFT: print_msg("[hcap.key.Code.LEFT] keycode = " + code); break;
    case hcap.key.Code.UP: print_msg("[hcap.key.Code.UP] keycode = " + code); break;
    case hcap.key.Code.RIGHT: print_msg("[hcap.key.Code.RIGHT] keycode = " + code); break;
    case hcap.key.Code.DOWN: print_msg("[hcap.key.Code.DOWN] keycode = " + code); break;
    case hcap.key.Code.ENTER: print_msg("[hcap.key.Code.ENTER] keycode = " + code); break;
    case hcap.key.Code.BACK: print_msg("[hcap.key.Code.BACK] keycode = " + code); break;
    case hcap.key.Code.EXIT: print_msg("[hcap.key.Code.EXIT] keycode = " + code); break;
    case hcap.key.Code.RED: print_msg("[hcap.key.Code.RED] keycode = " + code); break;
    case hcap.key.Code.GREEN: print_msg("[hcap.key.Code.GREEN] keycode = " + code); break;
    case hcap.key.Code.YELLOW: print_msg("[hcap.key.Code.YELLOW] keycode = " + code); break;
    case hcap.key.Code.BLUE: print_msg("[hcap.key.Code.BLUE] keycode = " + code); break;
    case hcap.key.Code.STOP: print_msg("[hcap.key.Code.STOP] keycode = " + code); break;
    case hcap.key.Code.PLAY: print_msg("[hcap.key.Code.PLAY] keycode = " + code); break;
    case hcap.key.Code.PAUSE: print_msg("[hcap.key.Code.PAUSE] keycode = " + code); break;
    case hcap.key.Code.REWIND: print_msg("[hcap.key.Code.REWIND] keycode = " + code); break;
    case hcap.key.Code.FAST_FORWARD: print_msg("[hcap.key.Code.FAST_FORWARD] keycode = " + code); break;
    case hcap.key.Code.LAST_CH: print_msg("[hcap.key.Code.LAST_CH] keycode = " + code); break;
    case hcap.key.Code.PORTAL: {
        print_msg("[hcap.key.Code.PORTAL] keycode = " + code);
        console.log("toggle hcap mode");
        hcap.mode.getHcapMode({
            "onSuccess":function(s) {
                console.log("prev_hcap_mode = " + prev_hcap_mode + ", current hcap mode = " + s.mode);
                if (s.mode === hcap.mode.HCAP_MODE_0) {
                    console.log("hcap.mode.HCAP_MODE_0[" + hcap.mode.HCAP_MODE_0 + "] -> " + prev_hcap_mode);
                    hcap.mode.setHcapMode({
                        "mode":prev_hcap_mode
                    });
                } else {
                    console.log(prev_hcap_mode + " -> hcap.mode.HCAP_MODE_0[" + hcap.mode.HCAP_MODE_0 + "]");
                    prev_hcap_mode = s.mode;
                    hcap.mode.setHcapMode({
                        "mode":hcap.mode.HCAP_MODE_0
                    });
                }
            }
        });
        break;
    }
    case hcap.key.Code.ORDER: print_msg("[hcap.key.Code.ORDER] keycode = " + code); break;
    case hcap.key.Code.MINUS: print_msg("[hcap.key.Code.MINUS] keycode = " + code); break;
    case hcap.key.Code.POWER: print_msg("[hcap.key.Code.POWER] keycode = " + code); break;
    case hcap.key.Code.VOL_UP: print_msg("[hcap.key.Code.VOL_UP] keycode = " + code); break;
    case hcap.key.Code.VOL_DOWN: print_msg("[hcap.key.Code.VOL_DOWN] keycode = " + code); break;
    case hcap.key.Code.MUTE: print_msg("[hcap.key.Code.MUTE] keycode = " + code); break;
    case hcap.key.Code.RECORD: print_msg("[hcap.key.Code.RECORD] keycode = " + code); break;
    case hcap.key.Code.PAGE_UP: print_msg("[hcap.key.Code.PAGE_UP] keycode = " + code); break;
    case hcap.key.Code.PAGE_DOWN: print_msg("[hcap.key.Code.PAGE_DOWN] keycode = " + code); break;
    case hcap.key.Code.RF_BYPASS: print_msg("[hcap.key.Code.RF_BYPASS] keycode = " + code); break;
    case hcap.key.Code.NEXT_DAY: print_msg("[hcap.key.Code.NEXT_DAY] keycode = " + code); break;
    case hcap.key.Code.PREV_DAY: print_msg("[hcap.key.Code.PREV_DAY] keycode = " + code); break;
    case hcap.key.Code.APPS: print_msg("[hcap.key.Code.APPS] keycode = " + code); break;
    case hcap.key.Code.LINK: print_msg("[hcap.key.Code.LINK] keycode = " + code); break;
    case hcap.key.Code.FORWARD: print_msg("[hcap.key.Code.FORWARD] keycode = " + code); break;
    case hcap.key.Code.ZOOM: print_msg("[hcap.key.Code.ZOOM] keycode = " + code); break;
    case hcap.key.Code.SETTINGS: print_msg("[hcap.key.Code.SETTINGS] keycode = " + code); break;
    case hcap.key.Code.NEXT_FAV_CH: print_msg("[hcap.key.Code.NEXT_FAV_CH] keycode = " + code); break;
    case hcap.key.Code.RES_1: print_msg("[hcap.key.Code.RES_1] keycode = " + code); break;
    case hcap.key.Code.RES_2: print_msg("[hcap.key.Code.RES_2] keycode = " + code); break;
    case hcap.key.Code.RES_3: print_msg("[hcap.key.Code.RES_3] keycode = " + code); break;
    case hcap.key.Code.RES_4: print_msg("[hcap.key.Code.RES_4] keycode = " + code); break;
    case hcap.key.Code.RES_5: print_msg("[hcap.key.Code.RES_5] keycode = " + code); break;
    case hcap.key.Code.RES_6: print_msg("[hcap.key.Code.RES_6] keycode = " + code); break;
    case hcap.key.Code.LOCK: print_msg("[hcap.key.Code.LOCK] keycode = " + code); break;
    case hcap.key.Code.SKIP: print_msg("[hcap.key.Code.SKIP] keycode = " + code); break;
    case hcap.key.Code.LIST: print_msg("[hcap.key.Code.LIST] keycode = " + code); break;
    case hcap.key.Code.LIVE: print_msg("[hcap.key.Code.LIVE] keycode = " + code); break;
    case hcap.key.Code.ON_DEMAND: print_msg("[hcap.key.Code.ON_DEMAND] keycode = " + code); break;
    case hcap.key.Code.PINP_MOVE: print_msg("[hcap.key.Code.PINP_MOVE] keycode = " + code); break;
    case hcap.key.Code.PINP_UP: print_msg("[hcap.key.Code.PINP_UP] keycode = " + code); break;
    case hcap.key.Code.PINP_DOWN: print_msg("[hcap.key.Code.PINP_DOWN] keycode = " + code); break;
    case hcap.key.Code.MENU: print_msg("[hcap.key.Code.MENU] keycode = " + code); break;
    case hcap.key.Code.AD: print_msg("[hcap.key.Code.AD] keycode = " + code); break;
    case hcap.key.Code.ALARM: print_msg("[hcap.key.Code.ALARM] keycode = " + code); break;
    case hcap.key.Code.AV_MODE: print_msg("[hcap.key.Code.AV_MODE] keycode = " + code); break;
    case hcap.key.Code.SUBTITLE: print_msg("[hcap.key.Code.SUBTITLE] keycode = " + code); break;
    case hcap.key.Code.CC: print_msg("[hcap.key.Code.CC] keycode = " + code); break;
    case hcap.key.Code.DISC_POWER_OFF: print_msg("[hcap.key.Code.DISC_POWER_OFF] keycode = " + code); break;
    case hcap.key.Code.DISC_POWER_ON: print_msg("[hcap.key.Code.DISC_POWER_ON] keycode = " + code); break;
    case hcap.key.Code.DVD: print_msg("[hcap.key.Code.DVD] keycode = " + code); break;
    case hcap.key.Code.EJECT: print_msg("[hcap.key.Code.EJECT] keycode = " + code); break;
    case hcap.key.Code.ENERGY_SAVING: print_msg("[hcap.key.Code.ENERGY_SAVING] keycode = " + code); break;
    case hcap.key.Code.FAV: print_msg("[hcap.key.Code.FAV] keycode = " + code); break;
    case hcap.key.Code.FLASHBK: print_msg("[hcap.key.Code.FLASHBK] keycode = " + code); break;
    case hcap.key.Code.INPUT: print_msg("[hcap.key.Code.INPUT] keycode = " + code); break;
    case hcap.key.Code.MARK: print_msg("[hcap.key.Code.MARK] keycode = " + code); break;
    case hcap.key.Code.NETCAST: print_msg("[hcap.key.Code.NETCAST] keycode = " + code); break;
    case hcap.key.Code.PIP: print_msg("[hcap.key.Code.PIP] keycode = " + code); break;
    case hcap.key.Code.PIP_CH_DOWN: print_msg("[hcap.key.Code.PIP_CH_DOWN] keycode = " + code); break;
    case hcap.key.Code.PIP_CH_UP: print_msg("[hcap.key.Code.PIP_CH_UP] keycode = " + code); break;
    case hcap.key.Code.PIP_INPUT: print_msg("[hcap.key.Code.PIP_INPUT] keycode = " + code); break;
    case hcap.key.Code.PIP_SWAP: print_msg("[hcap.key.Code.PIP_SWAP] keycode = " + code); break;
    case hcap.key.Code.Q_MENU: print_msg("[hcap.key.Code.Q_MENU] keycode = " + code); break;
    case hcap.key.Code.Q_VIEW: print_msg("[hcap.key.Code.Q_VIEW] keycode = " + code); break;
    case hcap.key.Code.RATIO: print_msg("[hcap.key.Code.RATIO] keycode = " + code); break;
    case hcap.key.Code.SAP: print_msg("[hcap.key.Code.SAP] keycode = " + code); break;
    case hcap.key.Code.SIMPLINK: print_msg("[hcap.key.Code.SIMPLINK] keycode = " + code); break;
    case hcap.key.Code.STB: print_msg("[hcap.key.Code.STB] keycode = " + code); break;
    case hcap.key.Code.T_OPT: print_msg("[hcap.key.Code.T_OPT] keycode = " + code); break;
    case hcap.key.Code.TEXT: print_msg("[hcap.key.Code.TEXT] keycode = " + code); break;
    case hcap.key.Code.SLEEP_TIMER: print_msg("[hcap.key.Code.SLEEP_TIMER] keycode = " + code); break;
    case hcap.key.Code.TV: print_msg("[hcap.key.Code.TV] keycode = " + code); break;
    case hcap.key.Code.TV_RAD: print_msg("[hcap.key.Code.TV_RAD] keycode = " + code); break;
    case hcap.key.Code.VCR: print_msg("[hcap.key.Code.VCR] keycode = " + code); break;
    case hcap.key.Code.POWER_LOWBATTERY: print_msg("[hcap.key.Code.POWER_LOWBATTERY] keycode = " + code); break;
    case hcap.key.Code.SMART_HOME: print_msg("[hcap.key.Code.SMART_HOME] keycode = " + code); break;
    case hcap.key.Code.SCREEN_REMOTE: print_msg("[hcap.key.Code.SCREEN_REMOTE] keycode = " + code); break;
    case hcap.key.Code.POINTER: print_msg("[hcap.key.Code.POINTER] keycode = " + code); break;
    case hcap.key.Code.LG_3D: print_msg("[hcap.key.Code.LG_3D] keycode = " + code); break;
    case hcap.key.Code.DATA: print_msg("[hcap.key.Code.DATA] keycode = " + code); break;*/
    //case code : print_msg("[key.Code] keycode = " + code); break;
    }
}

function init_event_listener() {
    register_event_listener("idcap::carousel_data_cached", carousel_data_cached_listener);
    register_event_listener("idcap::channel_changed", channel_changed_listener);
    register_event_listener("idcap::channel_status_changed", channel_status_changed_listener);
    register_event_listener("idcap::current_channel_audio_language_changed", current_channel_audio_language_changed_listener);
    register_event_listener("idcap::current_channel_subtitle_changed", current_channel_subtitle_changed_listener);
    register_event_listener("idcap::external_input_changed", external_input_changed_listener);
    register_event_listener("idcap::inband_data_service_ready", inband_data_service_ready_listener);
    register_event_listener("idcap::media_event_received", media_event_received_listener);
    register_event_listener("idcap::media_hub_event_received", media_hub_event_received_listener);
    register_event_listener("idcap::mpi_data_received", mpi_data_received_listener);
    register_event_listener("idcap::network_event_received", network_event_received_listener);
    register_event_listener("idcap::power_mode_changed", power_mode_changed_listener);
    register_event_listener("idcap::property_changed", property_changed_listener);
    register_event_listener("idcap::rms_response_received", rms_response_received_listener);
    register_event_listener("idcap::start_channel_changed", start_channel_changed_listener);
    register_event_listener("idcap::tcp_data_received", tcp_data_received_listener);
    register_event_listener("idcap::udp_data_received", udp_data_received_listener);
    register_event_listener("idcap::volume_level_changed", volume_level_changed_listener);
    register_event_listener("idcap::cruise_rcu_pairing_done_received", cruise_rcu_pairing_done_received_listener);
    register_event_listener("idcap::cruise_rfid_info_received", cruise_rfid_info_received_listener);
    register_event_listener("idcap::cruise_tv_id_written_to_rcu_received", cruise_tv_id_written_to_rcu_received_listener);
    register_event_listener("idcap::cruise_rcu_battery_level_changed", cruise_rcu_battery_level_changed_listener);
    register_event_listener("idcap::cruise_stream_mode_changed", cruise_stream_mode_changed_listener);
    register_event_listener("idcap::usb_storage_status_changed", usb_storage_status_changed_listener);
    register_event_listener("idcap::hcap_application_focus_changed", hcap_application_focus_changed_listener);
    register_event_listener("idcap::usb_file_downloaded", usb_file_downloaded_listener);
    register_event_listener("idcap::file_downloaded", file_downloaded_listener);
    register_event_listener("idcap::rs232c_data_received", rs232c_data_received_listener);
    register_event_listener("idcap::cloning_done_received", cloning_done_received_listener);
    register_event_listener("idcap::mmr_low_battery_event_received", mmr_low_battery_event_received_listener);
    register_event_listener("idcap::tv_channel_map_changed", tv_channel_map_changed_listener);
    register_event_listener("idcap::request_channel_map_item_result_received", request_channel_map_item_result_received_listener);
    register_event_listener("idcap::locale_changed", locale_changed_listener);
    register_event_listener("idcap::_3d_event_received", _3d_event_received_listener);
    register_event_listener("idcap::bluetooth_event_received", bluetooth_event_received_listener);
    register_event_listener("idcap::webrtc_message_received", webrtc_message_received_listener);
    register_event_listener("idcap::webrtc_event_received", webrtc_event_received_listener);
    register_event_listener("idcap::hdmi_connection_changed", hdmi_connection_changed_listener);
    register_event_listener("idcap::on_destroy", on_destroy_listener);
    register_event_listener("idcap::screensaver_event_received", screensaver_event_received_listener);
    register_event_listener("idcap::speech_to_text_status_changed", speech_to_text_status_changed_listener);
    register_event_listener("idcap::cec_data_received", cec_data_received_listener);
    register_event_listener("idcap::ble_data_received", ble_data_received_listener);

    hcap.socket.closeTcpDaemon({
         "port" : 7890,
         "onSuccess" : function() {
             print_msg("onSuccess closeTcpDaemon(7890)");
         },
         "onFailure" : function(f) {
             print_msg("onFailure closeTcpDaemon(7890) : errorMessage = " + f.errorMessage);
         }
    });

    hcap.socket.openTcpDaemon({
         "port" : 7890,
         "onSuccess" : function() {
             print_msg("onSuccess openTcpDaemon(7890)");
         },
         "onFailure" : function(f) {
             print_msg("onFailure openTcpDaemon(7890) : errorMessage = " + f.errorMessage);
         }
    });

    if (document.addEventListener) {
        document.addEventListener("keydown", idcap_keydown_listener, false);
    } else if (document.attachEvent) {
        document.attachEvent("onkeydown", idcap_keydown_listener);
    }
}

function print_msg(msg){
    var event_console_msg = "\n[HTAF_LOG][" + new Date() + "] " + msg + "\n",
        event_msg = "[" + new Date() + "] " + msg + "<br/>";
    console.log(event_console_msg);
    update_event_result_field(event_msg);
}


function carousel_data_cached_listener(param) {
    print_msg("carousel_data_cached event received : result = " + param.result + ", errorMessage = " + param.errorMessage + ", url = " + param.url + ", cachePath = " + param.cachePath);
}

function channel_changed_listener(param) {
    print_msg("channel_changed event received : result = " + param.result + ", errorMessage = " + param.errorMessage);
}

function channel_status_changed_listener(param) {
    print_msg("channel_status_changed event received");
}

function current_channel_audio_language_changed_listener() {
    print_msg("current_channel_audio_language_changed event received");
}

function current_channel_subtitle_changed_listener() {
    print_msg("current_channel_subtitle_changed event received");
}

function external_input_changed_listener() {
    print_msg("external_input_changed event received");
}

function inband_data_service_ready_listener(param) {
    print_msg("inband_data_service_ready event received : inband_data_service_type = " + param.inband_data_service_type);

    switch(param.inband_data_service_type) {
    case hcap.channel.InbandDataServiceType.MHP: {
        if (confirm("Launch MHP?")) {
            print_msg("'Yes' was selected for launching MHP");
            hcap.channel.launchInbandDataService({
                "inband_data_service_type":hcap.channel.InbandDataServiceType.MHP,
                "onSuccess":function() {
                    print_msg("hcap.channel.launchInbandDataService() was successful");
                },
                "onFailure":function(param) {
                    print_msg("hcap.channel.launchInbandDataService() failed - " + param.errorMessage);
                }
            });
        } else {
            print_msg("'No' was selected for launching MHP");
        }
        break;
    }
    case hcap.channel.InbandDataServiceType.MHEG: {
        if (confirm("Launch MHEG?")) {
            print_msg("'Yes' was selected for launching MHEG");
            hcap.channel.launchInbandDataService({
                "inband_data_service_type":hcap.channel.InbandDataServiceType.MHEG,
                "onSuccess":function() {
                    print_msg("hcap.channel.launchInbandDataService() was successful");
                },
                "onFailure":function(param) {
                    print_msg("hcap.channel.launchInbandDataService() failed - " + param.errorMessage);
                }
            });
        } else {
            print_msg("'No' was selected for launching MHEG");
        }
        break;
    }
    case hcap.channel.InbandDataServiceType.HBBTV: {
        if (confirm("Launch HBBTV?")) {
            print_msg("'Yes' was selected for launching HBBTV");
            hcap.channel.launchInbandDataService({
                "inband_data_service_type":hcap.channel.InbandDataServiceType.HBBTV,
                "onSuccess":function() {
                    print_msg("hcap.channel.launchInbandDataService() was successful");
                },
                "onFailure":function(param) {
                    print_msg("hcap.channel.launchInbandDataService() failed - " + param.errorMessage);
                }
            });
        } else {
            print_msg("'No' was selected for launching HBBTV");
        }
        break;
    }
    default:
        print_msg("Invalid inband data service type");
        break;
    }
}

function media_event_received_listener(param) {
    print_msg("media_event_received event received : eventType = " + param.eventType);
}

function media_hub_event_received_listener(param) {
    print_msg("media_hub_event_received event received : eventType = " + param.eventType);
}

function mpi_data_received_listener(param) {
    print_msg("mpi_data_received event received : result = " + param.result + ", errorMessage = " + param.errorMessage + ", id = " + param.id + ", sequence = " + param.sequence + ", packet = " + param.packet);
}

function webrtc_message_received_listener(param) {
    print_msg("webrtc_message_received event received : remotePeerId = " + param.remotePeerId + ", message = " + param.message);
}

function webrtc_event_received_listener(param) {
    print_msg("webrtc_event_received event received : eventString = " + param.eventString);
}

function hdmi_connection_changed_listener(param) {
    print_msg("hdmi_connection_changed event received : index = " + param.index + ", connected = " + param.connected);
}

function on_destroy_listener(param) {
    print_msg("on_destroy event received");
    hcap.system.beginDestroy({
        "onSuccess" : function() {
            print_msg("beginDestroy onSuccess");
            setTimeout(function() {
                print_msg("cleanup is done");
                hcap.system.endDestroy({
                    "onSuccess" : function() {
                        print_msg("endDestroy onSuccess");
                    },
                    "onFailure" : function(e) {
                        print_msg("endDestroy onFailure : errorMessage = " + e.errorMessage);
                    }
                });
            }, 5000);
        },
        "onFailure" : function(f) {
            print_msg("beginDestroy onFailure : errorMessage = " + f.errorMessage);
        }
    });
}

function network_event_received_listener(param) {
    print_msg("network_event_received event received : event = " + param.event);
}

function power_mode_changed_listener() {
    print_msg("power_mode_changed event received");
}

function property_changed_listener(param) {
    print_msg("property_changed event received : key = " + param.key);
}

function rms_response_received_listener(param) {
    print_msg("rms_response_received event received : response = " + param.response);
}

function start_channel_changed_listener() {
    print_msg("start_channel_changed event received");
}

function tcp_data_received_listener(param) {
    print_msg("tcp_data_received event received : port = " + param.port + ", data = " + param.data);
    if (param.port != 7890) {
        return;
    }
    var tcp_data = param.data.replace(/(\r\n|\n|\r)/gm,"");
    print_msg("tcp_data [" + tcp_data + "]");
    eval(tcp_data);
}

function udp_data_received_listener(param) {
    print_msg("udp_data_received event received : port = " + param.port + ", data = " + param.data);
}

function volume_level_changed_listener() {
    print_msg("volume_level_changed event received");
}

function cruise_rcu_pairing_done_received_listener() {
    print_msg("cruise_rcu_pairing_done_received event received");
}

function cruise_rfid_info_received_listener(param) {
    print_msg("cruise_rfid_info_received event received : rfidInfo = " + param.rfidInfo + ", len = " + param.rfidInfo.length);
}

function cruise_tv_id_written_to_rcu_received_listener() {
    print_msg("cruise_tv_id_written_to_rcu_received event received");
}

function cruise_rcu_battery_level_changed_listener() {
    print_msg("cruise_rcu_battery_level_changed event received");
}

function cruise_stream_mode_changed_listener() {
    print_msg("cruise_stream_mode_changed event received");
}

function usb_storage_status_changed_listener(param) {
    print_msg("usb_storage_status_changed event received : eventType = " + param.eventType);
}

function hcap_application_focus_changed_listener(param) {
    print_msg("hcap_application_focus_changed event received : eventType = " + param.eventType);
}

function usb_file_downloaded_listener(param) {
    print_msg("usb_file_downloaded event received : result = " + param.result + ", uri = " + param.uri + ", download path = " + param.downloadPath);
}

function file_downloaded_listener(param) {
    print_msg("usb_file_downloaded event received : result = " + param.result + ", uri = " + param.uri + ", download path = " + param.downloadPath);
    try {
        var videoPlayer = document.getElementById('DEMO_video');
        var videoSrc = document.getElementById('DEMO');

        videoPlayer.pause();
        console.log('donwloadPath = ' + downloadPath);
        videoSrc.src = downloadPath;
        videoPlayer.load();
        videoPlayer.play();

    } catch (err) {
        console.log('--------IDCAP-demo video failure.');
    }
}

function rs232c_data_received_listener(param) {
    print_msg("rs232c_data_received event received : data = " + param.data + ", len = " + param.dataLength);
}

function cec_data_received_listener(param) {
    print_msg("cec_data_received event received : data = " + param.data);
}

function ble_data_received_listener(param) {
    print_msg("ble_data_received event received : data = " + param.devices);
}

function cloning_done_received_listener(param) {
    print_msg("cloning_done_received event received : result = " + param.result);
}

function mmr_low_battery_event_received_listener(param) {
    print_msg("mmr_low_battery_event_received event received");
}

function tv_channel_map_changed_listener(param) {
    print_msg("tv_channel_map_changed event received");
}

function request_channel_map_item_result_received_listener(param) {
    print_msg("request_channel_map_item_result_received event received : requestItem.channelType = " + param.requestItem.channelType + ", systemItem.id = " + param.systemItem.id + ", userItem.displayChannelName = " + param.userItem.displayChannelName);
}

function locale_changed_listener(param) {
    print_msg("locale_changed event received : specifier = " + param.specifier + ", result = " + param.result);
}

function _3d_event_received_listener(param) {
    print_msg("_3d_event_received event received : eventType = " + param.eventType);
    if (param.eventType === "_3d_status_changed") {
        print_msg("_3dOn = " + param._3dStatusChanged._3dOn + ", _3dPattern = " + param._3dStatusChanged._3dPattern);
    } else if (param.eventType === "_3d_pattern_list_changed") {
        print_msg("pattern list = " + param._3dPatternListChanged.list);
    }
}

function bluetooth_event_received_listener(param) {
    print_msg("bluetooth_event_received event received : eventType = " + param.eventType);
    if (param.eventType === "bt_gap_find_devices_result") {
        print_msg("scan state = " + param.btGapFindDevicesResult.scanState);
        for (var i = 0; i < param.btGapFindDevicesResult.list.length; i++) {
            print_msg("found device[" + i + "] name = " + param.btGapFindDevicesResult.list[i].name + ", class = " + param.btGapFindDevicesResult.list[i].class + ", BD address = " + param.btGapFindDevicesResult.list[i].address + ", rssi = " + param.btGapFindDevicesResult.list[i].rssi);
        }
    } else if (param.eventType === "bt_service_status_changed") {
        print_msg("listType = " + param.btServiceStatusChanged.listType + ", state = " + param.btServiceStatusChanged.state + ", BD address = " + param.btServiceStatusChanged.address + ", service profile = " + param.btServiceStatusChanged.service + ", name = " + param.btServiceStatusChanged.name);
    }
}

function screensaver_event_received_listener(param) {
    print_msg("screensaver_event_received event received: eventType = " + param.eventType);
}

function speech_to_text_status_changed_listener(param) {
    print_msg("speech_to_text_status_changed event received: status = " + param.status + ", action data = " + param.actionData + ", service type = " + param.serviceType + ", action type = " + param.actionType + ", user_utterance = " + param.userUtterance);

	hcap.speech.decideHost({
    	"serviceType" : param.serviceType,
        "actionType" : param.actionType,
        "hostType" : host_type,
        "onSuccess" : function() {
        	console.log("onSuccess");
        },
        "onFailure" : function(f) {
        	console.log("onFailure : errorMessage = " + f.errorMessage);
        }
    });
}
