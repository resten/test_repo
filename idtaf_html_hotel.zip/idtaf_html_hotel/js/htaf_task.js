var TASK_STOPPED = 0;
var TASK_RUNNING = 1;
var TASK_TERMINATED = 2;

var CALL_INTERVAL = 10; // 10ms;
var MONITOR_INTERVAL = 5;  // 5ms

﻿var MAX_TIME_OUT_COUNT = 6000;
var have_to_check_timeout = true;

var command_task_interval_id = -1;
function command_task(command_elements) {
    var task_list = new Array();
    var status = TASK_STOPPED;
    var current_task_index = 0;
//    var interval_id = 0;

    var command_arguments = command_elements;
    var cmd_result;
    var expected_callback_result_array = new Array();

    var time_out_count = 0;

    var get_status = function() {
        return status;
    }

    this.get_status = function() {
        return status;
    }

    var set_status = function(status_to_be_set) {
        if (status != status_to_be_set) {
            status = status_to_be_set;
        }
    }

    this.set_status = function(status_to_be_set) {
        if (status != status_to_be_set) {
            status = status_to_be_set;
        }
    }

    this.get_current_task_index = function() {
        return current_task_index;
    }

    this.get_number_of_tasks = function() {
        return task_list.length;
    }

    var call_task_0 = function(object, fn, time) {
        end_task();
        set_status(TASK_RUNNING);
        command_task_interval_id = htaf_setInterval("command_task call_task_0", fn, time);
    }

    var end_task = function() {
		if (command_task_interval_id !== -1) {
			htaf_clearInterval("command_task.end_task", command_task_interval_id);
			command_task_interval_id = -1;
        }
    }

    this.command = function() {
        return command_arguments;
    }

    this.command_result = function() {
        return cmd_result;
    }

    this.get_expected_callback_result = function(hcap) {
        return expected_callback_result_array[hcap];
    }

    this.set_command_result = function(result, fail_reason) {
        var command = command_arguments[0];

        for ( var i = 1; i < command_arguments.length; i++) {
            command += prefix.CELL_DELIMITER + command_arguments[i];
        }
        cmd_result = new command_result(command, result, fail_reason);
    }

    this.run = function() {
        time_out_count = 0;
        call_task_0(this, this.call_command, CALL_INTERVAL);
    }

    this.call_command = function() {
        end_task();
        call_task_0(this, command_monitor, CALL_INTERVAL);
        var command_name = command_arguments[0].substring(1, command_arguments[0].length);
        var command = HDSTL.getCommand(command_name);
        command.execute(command_arguments);
    }

    var command_monitor = function() {
        time_out_count++;
        if (get_status() != TASK_RUNNING) {
            end_task();
        } else if (have_to_check_timeout && time_out_count >= MAX_TIME_OUT_COUNT) {
            monitor_task_instance.get_current_testcase_task().get_current_command().set_command_result(false, "time out");
            set_status(TASK_TERMINATED);
            end_task();
        }
    }
}
enable_timeout_check = function() {
	have_to_check_timeout = true;
}

disable_timeout_check = function() {
	have_to_check_timeout = false;
}

﻿var monitor_task_instance = new monitor_task();
var testcase_start_time;
var testcase_end_time;
var moinitor_task_interval_id = -1;
function monitor_task() {
    var task_list = new Array();
    var status = TASK_STOPPED;
    var current_task_index = 0;

    this.get_status = function() {
        return status;
    }

    this.set_status = function(status_to_be_set) {
        if (status != status_to_be_set) {
            status = status_to_be_set;
        }
    }

    var set_status = function(status_to_be_set) {
        if (status != status_to_be_set) {
            status = status_to_be_set;
        }
    }

    this.get_current_task_index = function() {
        return current_task_index;
    }

    this.get_number_of_tasks = function() {
        return task_list.length;
    }

    var end_task = function() {
    	if (moinitor_task_interval_id != -1) {
       		htaf_clearInterval("monitor_task.end_task", moinitor_task_interval_id);
        	moinitor_task_interval_id = -1;
        }
    }

    this.get_testcase_task_list = function() {
        return task_list;
    }

    this.get_current_testcase_task = function() {
        return task_list[current_task_index];
    }

    this.name = function() {
        return "monitor_task";
    }

    this.testcase_start_time = function() {
        return testcase_start_time;
    }

    this.run_all_testcases = function() {
        testcase_start_time = new Date();
        current_task_index = 0;
        delete task_list;
        task_list = new Array();

        var testcase_list = testcase_parser.get_testcase_list();
        if (testcase_list.length <= 0) {
            console.log("WARNING: There is no testcase! \n");
            return;
        }

        for ( var i = 0; i < testcase_list.length; i++) {
            var testcase = testcase_list[i];
            task_list[i] = new test_case_task(testcase);
        }

        this.set_status(TASK_RUNNING);
        show_description(current_task_index + 1);
        task_list[current_task_index].run();
        monitor_task_func_ptr = this.monitor;
        if (moinitor_task_interval_id != -1) {
        	htaf_clearInterval("monitor_task.run_all_testcases", moinitor_task_interval_id);
        	moinitor_task_interval_id = -1;
        }
        moinitor_task_interval_id = htaf_setInterval("monitor_task.run_all_testcases" , monitor_task_func_ptr, MONITOR_INTERVAL);
        return true;
    }

    this.run_testcase = function(testcase) {
        testcase_start_time = new Date();
        delete task_list;
        task_list = new Array();
        current_task_index = 0;
        task_list[current_task_index] = new test_case_task(testcase);

        set_status(TASK_RUNNING);
        task_list[current_task_index].run();
        this.start_monitor();
        return true;
    }

    this.start_monitor = function() {
        if (moinitor_task_interval_id !== -1) {
            htaf_clearInterval("monitor_task.start_monitor", moinitor_task_interval_id);
            moinitor_task_interval_id = -1;
        }
        moinitor_task_interval_id = htaf_setInterval("monitor_task.start_monitor", this.monitor_testcase, MONITOR_INTERVAL);
    }

    this.monitor_testcase = function() {
        if (task_list[current_task_index].get_status() === TASK_TERMINATED) {
            end_task();
            set_status(TASK_TERMINATED);
            number_of_horizontal_tabs = 6;
            document.getElementById('print').style.display = '';
            if(is_run_all)
                current_task_index++;
			is_running = false;
            show_result_field("total_result");
            return;
        }
    }

    this.monitor = function() {
        if (task_list[current_task_index].get_status() != TASK_TERMINATED) {
            return;
        } 
        if (current_task_index >= testcase_parser.get_testcase_list().length - 1) {
            end_task();
            number_of_horizontal_tabs = 6;
            document.getElementById('print').style.display = '';
            set_status(TASK_TERMINATED);
            show_message("END OF TESTCASE");
            is_run_all = false;
			show_result_field('total_result');
            return;
        } else {
            current_task_index++;
            show_description(current_task_index + 1);
            task_list[current_task_index].run();
			return;
        }
    }

    this.print_report = function() {
        var buffer = [ '\n' ];
        buffer.push("********************************************************\n");
        buffer.push("***                  Result Report                   ***\n");
        buffer.push("********************************************************\n");        
        for( var i = 0; i < task_list.length; i++) {
            var tc_result = task_list[i].testcase_result();
            if(tc_result.is_passed()) {
                buffer.push((i + 1) + tc_result.get_name() + ": Passed \n");
            } else {
                buffer.push((i + 1) + tc_result.get_name() + ": Failed " + 
                        tc_result.get_fail_reason() + "\n");
            }
        }
        buffer.push("\n");
        buffer.push("********************************************************\n");
        buffer.push("Failed Result\n");
        buffer.push("********************************************************\n");
        for( var i = 0; i < task_list.length; i++) {
            var tc_result = task_list[i].testcase_result();
            if(!tc_result.is_passed()) {
                buffer.push((i + 1) + tc_result.get_name() + " [Fail Reason] " + 
                        tc_result.get_fail_reason() + "\n");
            }
        }
        buffer.push("********************************************************\n");
        buffer.push("Total = " + total_count + "   Passed = " + passed_count + 
                "   Failed = " + failed_count + "\n");
        buffer.push("********************************************************\n");
        buffer.push("***                  End of Report                   ***\n");
        buffer.push("********************************************************\n");
        console.log(buffer.join(""));
    }
}

function test_case_task(testcase) {
    var task_list = new Array();
    var status = TASK_STOPPED;
    var current_task_index = 0;
    var interval_id = 0;

    var testcase_description = testcase.get_title();
    var command_task_list = new Array();
    var command_string_list = [];
    var current_command_index = 0;

    var testcase_result = new TestcaseResult(testcase_description);

    var list_of_command_element_list = testcase.get_list_of_command_element_list();
    for ( var i = 0; i < list_of_command_element_list.length; i++) {
        command_task_list[i] = new command_task(list_of_command_element_list[i]);
    }

    var list_of_command_string_list = testcase.get_list_of_command_string();
    for ( var i = 0; i < list_of_command_string_list.length; i++) {
        command_string_list[i] = list_of_command_string_list[i];
    }

    this.name = function() {
        return "test_case_task";
    }

    this.get_status = function() {
        return status;
    }

    this.set_status = function(status_to_be_set) {
        if (status != status_to_be_set) {
            status = status_to_be_set;
        }
    }

    var set_status = function(status_to_be_set) {
        if (status != status_to_be_set) {
            status = status_to_be_set;
        }
    }

    this.get_current_task_index = function() {
        return current_task_index;
    }

    this.get_number_of_tasks = function() {
        return task_list.length;
    }

    this.call_task_0 = function(object, fn, time) {
        end_task();
        set_status(TASK_RUNNING);
        interval_id = htaf_setInterval("test_case_task.call_task_0", fn, time);
    }

    this.end_task = function() {
        htaf_clearInterval("test_case_task.end_task", interval_id);
        interval_id = 0;
    }

    this.get_testcase_description = function() {
        return testcase_description;
    }
    this.get_testcase_command_string_list = function() {
        return command_string_list.join("\n");
    }

    this.get_current_command = function() {
        return command_task_list[current_command_index];
    }

    this.testcase_result = function() {
        return testcase_result;
    }

    var do_terminate = function() {
        set_status(TASK_TERMINATED);
    }

    this.monitor1 = function() {
        if (command_task_list === undefined || command_task_list.length === undefined) {
            htaf_clearInterval("test_case_task.monitor1-0", interval_id);
            this.do_terminate();
            return;
        } else if (current_command_index === command_task_list.length) {
            htaf_clearInterval("test_case_task.monitor1-1", interval_id);
            change_img(current_testcase_index, true);
			
            if (is_run_all && current_testcase_index %
                    ELEMENTS_PER_PAGE === 0 &&
                    current_page === current_testcase_index /
                    ELEMENTS_PER_PAGE)
                display(++page_number);
			var command_results = testcase_result.command_result_list();
			update_testcase_name("TEST: " + testcase_description, true);
			for(var i = 0; i < command_results.length; i++){
				update_command_name(command_results[i].command(), true);
				update_result_field(" Passed " , true);
			}
	        current_testcase_index++;
	        update_result_field("All commands for testcase (" +
	                testcase_description + ") were completed  <br/><b>>>" +
	                		"RESULT: PASSED</b>", true);
			update_result_field("===========================================" +
					"================================================<br/>",
					true);
	        do_terminate();         
            return;
        } else if (current_command_index > command_task_list.length) {
            htaf_clearInterval("test_case_task.monitor1-2", interval_id);
            this.do_terminate();
            return;
        }

        if (command_task_list[current_command_index].get_status() === TASK_TERMINATED) {
            testcase_result
                .add_command_result(command_task_list[current_command_index]
                .command_result());
            if (command_task_list[current_command_index]
                    .command_result().is_passed()) {
                ++current_command_index;
                if (command_task_list[current_command_index] != undefined) {
                    command_task_list[current_command_index].run();
                }

            } else {
                htaf_clearInterval("test_case_task.monitor1-3",interval_id);
                change_img(
                        current_testcase_index, false);

                if (is_run_all && current_testcase_index %
                        ELEMENTS_PER_PAGE === 0 &&
                        current_page === current_testcase_index /
                        ELEMENTS_PER_PAGE)
                    display(++page_number);
				var command_results = testcase_result.command_result_list();
				update_testcase_name("TEST: " + testcase_description, false);
                
				for(var i = 0; i < command_results.length; i++){
					update_command_name(command_results[i].command(), false);
					if(command_results[i].is_passed()){
					    update_result_field(" Passed" , false);
					} else {
					    update_result_field(" Failed, Fail Reason: " + 
					            command_results[i].fail_reason(), false);
					}    
				}
	            current_testcase_index++;
				update_result_field("testcase => (" + testcase_description + 
				        ") failed  <br/><b>>>RESULT: FAILED</b>" , false);
				update_result_field("=======================================" +
						"===================================================" +
						"=<br/>", false);
	            do_terminate();             
            }
        } else {
            //alert("command (" + current_command_index + ") is running");
        }
    }

    this.run = function() {
        console.log("\n== TESTCASE =============================\n " + 
                        this.get_testcase_description() + "\n" + 
                    "-----------------------------------------\n" +
//                        this.get_testcase_command_string_list() + "\n" + 
                    "=========================================");
        current_command_index = 0;
        interval_id = htaf_setInterval("test_case_task.run", this.monitor1, MONITOR_INTERVAL); 
        command_task_list[current_command_index].run();
    }
}
